var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/databases/route.js")
R.c("server/chunks/[root-of-the-server]__1ld1kl9._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/044u_dashboard__next-internal_server_app_api_auth_databases_route_actions_0av6fcv.js")
R.m(57475)
module.exports=R.m(57475).exports
