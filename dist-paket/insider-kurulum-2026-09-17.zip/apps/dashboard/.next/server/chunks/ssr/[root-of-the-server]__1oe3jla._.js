module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},71306,(a,b,c)=>{b.exports=a.r(18622)},79847,a=>{a.n(a.i(3343))},9185,a=>{a.n(a.i(29432))},72842,a=>{a.n(a.i(75164))},54897,a=>{a.n(a.i(30106))},56157,a=>{a.n(a.i(18970))},94331,a=>{a.n(a.i(60644))},15988,a=>{a.n(a.i(56952))},25766,a=>{a.n(a.i(77341))},29725,a=>{a.n(a.i(94290))},90833,a=>{a.n(a.i(46994))},5785,a=>{a.n(a.i(90588))},74793,a=>{a.n(a.i(33169))},85826,a=>{a.n(a.i(37111))},21565,a=>{a.n(a.i(41763))},65911,a=>{a.n(a.i(8950))},25128,a=>{a.n(a.i(91562))},40781,a=>{a.n(a.i(49670))},69411,a=>{a.n(a.i(75700))},63081,a=>{a.n(a.i(276))},62837,a=>{a.n(a.i(67361))},34607,a=>{a.n(a.i(11614))},96338,a=>{a.n(a.i(21751))},50642,a=>{a.n(a.i(12213))},32242,a=>{a.n(a.i(22693))},88530,a=>{a.n(a.i(10531))},8583,a=>{a.n(a.i(1082))},38534,a=>{a.n(a.i(98175))},70408,a=>{a.n(a.i(9095))},22922,a=>{a.n(a.i(96772))},78294,a=>{a.n(a.i(71717))},16625,a=>{a.n(a.i(85034))},88648,a=>{a.n(a.i(68113))},51914,a=>{a.n(a.i(66482))},25466,a=>{a.n(a.i(91505))},17239,a=>{"use strict";let b=process.env.ENROUTE_API_URL??"http://localhost:8080";async function c(){try{let{cookies:b}=await a.A(23804),c=await b();return c.get("enroute_auth")?.value??null}catch{return null}}async function d(a,d){let e=(d?.method??"GET").toUpperCase(),f=a.includes("refresh=1"),g=await c(),h="GET"!==e&&"HEAD"!==e||f||g?{cache:"no-store"}:{next:{revalidate:300,tags:[a.startsWith("/api/map")?"map":a.startsWith("/api/komuta")?"komuta":a.startsWith("/api/wietnauer")?"wietnauer":a.startsWith("/api/reports")?"reports":a.startsWith("/api/radars")?"radar":a.startsWith("/api/retrieve")?"schema":"default"]}},i=await fetch(`${b}${a}`,{...d,headers:{"Content-Type":"application/json",...g?{Authorization:`Bearer ${g}`}:{},...d?.headers??{}},...h});if(!i.ok){let a=await i.text(),b=a;try{let c=JSON.parse(a);b=[c.error,c.stack].filter(Boolean).join("\n")}catch{}throw Error(`API ${i.status}: ${b}`)}return i.json()}async function e(a,b){return d(`/api/radars/${encodeURIComponent(a)}/explain`,{method:"POST",body:JSON.stringify({question:b})})}async function f(a={}){let b=new URLSearchParams;return a.sehir&&b.set("sehir",a.sehir),"number"==typeof a.distKod&&b.set("distKod",String(a.distKod)),a.bolge&&b.set("bolge",a.bolge),a.region&&b.set("region",a.region),a.salesFilter&&b.set("salesFilter",a.salesFilter),a.riskTier&&b.set("riskTier",a.riskTier),a.tier&&b.set("tier",a.tier),"number"==typeof a.minDaysSinceVisit&&b.set("minDaysSinceVisit",String(a.minDaysSinceVisit)),"number"==typeof a.activityDays&&b.set("activityDays",String(a.activityDays)),"number"==typeof a.limit&&b.set("limit",String(a.limit)),d(`/api/map/customers?${b.toString()}`)}async function g(a={}){let b=new URLSearchParams;a.region&&b.set("region",a.region);let c=b.toString();return d(`/api/map/cities${c?`?${c}`:""}`)}async function h(a={}){let b=new URLSearchParams;return a.sehir&&b.set("sehir",a.sehir),"number"==typeof a.distKod&&b.set("distKod",String(a.distKod)),a.salesFilter&&b.set("salesFilter",a.salesFilter),a.riskTier&&b.set("riskTier",a.riskTier),a.tier&&b.set("tier",a.tier),"number"==typeof a.minDaysSinceVisit&&b.set("minDaysSinceVisit",String(a.minDaysSinceVisit)),d(`/api/map/regions?${b.toString()}`)}async function i(a,b,c=30,e={}){let f=new URLSearchParams;return"number"==typeof b&&f.set("distKod",String(b)),f.set("days",String(c)),e.refresh&&f.set("refresh","1"),d(`/api/map/customers/${a}/sales?${f.toString()}`)}async function j(a={}){let b=new URLSearchParams;a.refresh&&b.set("refresh","1"),a.reelTL&&b.set("reel","1"),"9le"===a.unit&&b.set("unit","9le"),a.bolge&&b.set("bolge",a.bolge),a.kanal&&b.set("kanal",a.kanal),a.urunGrup&&b.set("urunGrup",a.urunGrup);let c=b.toString()?`?${b.toString()}`:"";return d(`/api/komuta${c}`)}async function k(){return d("/api/komuta/facets")}async function l(a,b,c=14,e={}){let f=e.refresh?"?refresh=1":"";return d(`/api/map/customers/${a}/foresight${f}`,{method:"POST",body:JSON.stringify({label:b,windowDays:c,refresh:e.refresh??!1})})}async function m(){return d("/api/map/facets")}async function n(){return(await d("/api/auth/distributors")).distributors??[]}async function o(){return d("/api/map/sync-status")}async function p(){return d("/api/map/sync",{method:"POST"})}async function q(a,b={},c={}){let e=c.refresh?"?refresh=1":"";return d(`/api/radars/${encodeURIComponent(a)}/run${e}`,{method:"POST",body:JSON.stringify(b)})}function r(a){let b=new URLSearchParams;a.refresh&&b.set("refresh","1"),a.dateFrom&&a.dateTo?(b.set("from",a.dateFrom),b.set("to",a.dateTo)):a.donem&&"son30g"!==a.donem&&b.set("donem",a.donem);let c=b.toString();return c?`?${c}`:""}async function s(a={}){return d(`/api/wietnauer/yonetim${r(a)}`)}async function t(a,b={}){return d(`/api/wietnauer/${a}${r(b)}`)}async function u(a={}){return d(`/api/wietnauer/saha${r(a)}`)}a.s(["explainOnRadar",0,e,"getAllowedDistributors",0,n,"getCustomerForesight",0,l,"getCustomerSales",0,i,"getKomutaFacets",0,k,"getKomutaSnapshot",0,j,"getMapFacets",0,m,"getMapSyncStatus",0,o,"getWietnauerAktivasyon",0,(a={})=>{let b=new URLSearchParams;a.refresh&&b.set("refresh","1"),null!=a.distId&&b.set("distId",String(a.distId));let c=b.toString();return d(`/api/wietnauer/aktivasyon${c?`?${c}`:""}`)},"getWietnauerIskonto",0,(a={})=>{let b=new URLSearchParams;a.refresh&&b.set("refresh","1"),null!=a.distId&&b.set("distId",String(a.distId)),a.dateFrom&&b.set("from",a.dateFrom),a.dateTo?b.set("to",a.dateTo):a.donem&&"son30g"!==a.donem&&b.set("donem",a.donem);let c=b.toString();return d(`/api/wietnauer/iskonto${c?`?${c}`:""}`)},"getWietnauerMarka",0,(a={})=>t("marka",a),"getWietnauerSaha",0,u,"getWietnauerSegment",0,(a={})=>t("segment",a),"getWietnauerStok",0,(a={})=>{let b=new URLSearchParams;a.refresh&&b.set("refresh","1"),null!=a.distId&&b.set("distId",String(a.distId)),a.dateFrom&&b.set("from",a.dateFrom),a.dateTo?b.set("to",a.dateTo):a.donem&&"son30g"!==a.donem&&b.set("donem",a.donem);let c=b.toString();return d(`/api/wietnauer/stok${c?`?${c}`:""}`)},"getWietnauerYonetim",0,s,"listMapCityYoY",0,g,"listMapCustomers",0,f,"listMapRegions",0,h,"runRadarApi",0,q,"triggerMapSync",0,p])},24580,a=>{"use strict";var b=a.i(7997),c=a.i(93105);a.s(["V3PageHeader",0,function({eyebrow:a,title:d,description:e,dataNote:f,generatedAt:g,contentKey:h,descKey:i}){let j=(0,c.getContentMap)(),k=h?(0,c.t)(j,h,d):d,l=i?(0,c.t)(j,i,e):e,m=g?new Date(g).toLocaleString("tr-TR",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}):null;return(0,b.jsxs)("header",{className:"v3-head",children:[(0,b.jsxs)("div",{className:"v3-head-main",children:[(0,b.jsxs)("div",{className:"v3-eyebrow",children:[(0,b.jsx)("span",{className:"v3-eyebrow-dot"}),a]}),(0,b.jsx)("h1",{className:"v3-title",children:k}),(0,b.jsx)("p",{className:"v3-desc",children:l})]}),(f||m)&&(0,b.jsxs)("aside",{className:"v3-meta",children:[f&&(0,b.jsx)("div",{className:"v3-meta-note",children:f}),m&&(0,b.jsxs)("div",{className:"v3-meta-ts",children:["son güncelleme · ",m]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 24px; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--color-border); flex-wrap: wrap; }
        .v3-head-main { min-width: 280px; flex: 1; }
        .v3-eyebrow { display: inline-flex; align-items: center; gap: 6px; font-size: 10.5px; font-weight: 600; color: var(--color-accent); letter-spacing: 0.06em; text-transform: uppercase; }
        .v3-eyebrow-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--color-accent); }
        .v3-title { font-size: 28px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.025em; margin: 4px 0 6px; line-height: 1.15; }
        .v3-desc { font-size: 13.5px; color: var(--color-muted); margin: 0; max-width: 720px; line-height: 1.55; }
        .v3-meta { font-size: 11px; color: var(--color-muted-2); text-align: right; max-width: 280px; }
        .v3-meta-note { line-height: 1.5; }
        .v3-meta-ts { margin-top: 6px; opacity: 0.8; font-variant-numeric: tabular-nums; }
      `}})]})}])},1381,a=>{"use strict";a.i(7997),a.s(["formatCompact",0,function(a){return Number.isFinite(a)?Math.abs(a)>=1e9?(a/1e9).toFixed(1)+"Mr":Math.abs(a)>=1e6?(a/1e6).toFixed(1)+"M":Math.abs(a)>=1e3?(a/1e3).toFixed(1)+"K":Math.round(a).toString():"0"}])},60577,a=>{"use strict";a.s(["GlobalDonemFilter",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call GlobalDonemFilter() from the server but GlobalDonemFilter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/GlobalDonemFilter.tsx <module evaluation>","GlobalDonemFilter")},38627,a=>{"use strict";a.s(["GlobalDonemFilter",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call GlobalDonemFilter() from the server but GlobalDonemFilter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/GlobalDonemFilter.tsx","GlobalDonemFilter")},1980,a=>{"use strict";a.i(60577);var b=a.i(38627);a.n(b)},51370,a=>{"use strict";a.s(["StokDistSelect",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call StokDistSelect() from the server but StokDistSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/stok/StokDistSelect.tsx <module evaluation>","StokDistSelect")},18749,a=>{"use strict";a.s(["StokDistSelect",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call StokDistSelect() from the server but StokDistSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/stok/StokDistSelect.tsx","StokDistSelect")},74310,a=>{"use strict";a.i(51370);var b=a.i(18749);a.n(b)},59638,a=>{"use strict";a.s(["StokSkuTable",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call StokSkuTable() from the server but StokSkuTable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/stok/StokSkuTable.tsx <module evaluation>","StokSkuTable")},54233,a=>{"use strict";a.s(["StokSkuTable",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call StokSkuTable() from the server but StokSkuTable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/stok/StokSkuTable.tsx","StokSkuTable")},46326,a=>{"use strict";a.i(59638);var b=a.i(54233);a.n(b)},34526,a=>{"use strict";var b=a.i(7997),c=a.i(17239),d=a.i(93105),e=a.i(24580);a.i(2614);var f=a.i(12261),g=a.i(1381),h=a.i(74310),i=a.i(46326),j=a.i(1980);let k=/^\d{4}-\d{2}-\d{2}$/;async function l({searchParams:a}){let g=(0,f.getTenantConfig)(),i=await a,q=null!=i.distId?Number(i.distId):null,r=null!=q&&Number.isFinite(q)?q:null,t=i.from&&k.test(i.from)?i.from:null,u=i.to&&k.test(i.to)?i.to:null,v=(i.donem??"").toLowerCase(),w=null,x=null;try{w=await (0,c.getWietnauerStok)({distId:r,dateFrom:t,dateTo:u,donem:t&&u?null:v||null})}catch(a){x=a.message}let y=w?w.totals.criticalSkuCount+w.totals.riskSkuCount:0,z=w&&w.totals.activeSkuCount>0?y/w.totals.activeSkuCount*100:0,A=w?.critical.length?w.critical:w?.items??[],B=A.find(a=>a.estimatedStockoutDate)?.estimatedStockoutDate??null;return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(e.V3PageHeader,{eyebrow:"Dashboard 08",title:"Stok Tükenme",contentKey:"page.stok.title",descKey:"page.stok.desc",description:(w?.distFilter?`${w.distFilter.distName}${w.distFilter.region?` (${w.distFilter.region})`:""} — SKU stoklarının ka\xe7 g\xfcn yeteceğini, tahmini t\xfckenme tarihini ve miktar bazlı 90 g\xfcnl\xfck devir hızını g\xf6sterir.`:`${g.displayName} t\xfcm distrib\xfct\xf6rler — SKU stoklarının ka\xe7 g\xfcn yeteceğini, tahmini t\xfckenme tarihini ve miktar bazlı 90 g\xfcnl\xfck devir hızını g\xf6sterir. Belirli bir distrib\xfct\xf6re odaklanmak i\xe7in dropdown'dan se\xe7.`)+(w?.demandRange.custom?` Talep/satış hızı penceresi: ${s(w.demandRange.from)} – ${s(w.demandRange.to)} (${w.demandRange.days} g\xfcn). Stok bakiyesi bu aralıktan bağımsız, anlıktır.`:""),dataNote:"TBLMSDBELGEDETAY · TBLMSDFATURA · TBLMSDDEPOHAREKET · TBLURUN · TBLDIST × TBLDISTEKGRUP · LNGSTOKTIP · DBLMIKTAR",generatedAt:w?.generatedAt}),x&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",x,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula."})]}),w&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(h.StokDistSelect,{distributors:w.distributors,selectedDistId:w.distFilter?.distId??null}),(0,b.jsx)(j.GlobalDonemFilter,{}),(0,b.jsxs)("div",{className:"stok-kpi-grid",children:[!(0,d.panelHidden)("kpi.stok.kritik")&&(0,b.jsx)(m,{label:(0,d.cs)("kpi.stok.kritik","Kritik + Risk"),value:y.toLocaleString("tr-TR"),sub:w.totals.lowConfidenceSkuCount>0?`%${z.toFixed(1)} \xb7 ${w.totals.lowConfidenceSkuCount} d\xfcş\xfck g\xfcven`:`%${z.toFixed(1)} \xb7 0-14 g\xfcn`,tone:y>0?"bad":"good"}),!(0,d.panelHidden)("kpi.stok.tukenme")&&(0,b.jsx)(m,{label:(0,d.cs)("kpi.stok.tukenme","İlk Tükenme"),value:B?s(B):"-",sub:"tahmini tarih",tone:B?"bad":"neutral"}),!(0,d.panelHidden)("kpi.stok.pozitif")&&(0,b.jsx)(m,{label:(0,d.cs)("kpi.stok.pozitif","Pozitif Stok SKU"),value:w.totals.positiveStockSkuCount.toLocaleString("tr-TR"),sub:w.distFilter?`${w.totals.activeSkuCount.toLocaleString("tr-TR")} SKU i\xe7inde`:`${w.totals.activeSkuCount.toLocaleString("tr-TR")} SKU\xd7dist i\xe7inde`}),!(0,d.panelHidden)("kpi.stok.devir")&&(0,b.jsx)(m,{label:(0,d.cs)("kpi.stok.devir","Devir Hesaplanan"),value:w.totals.turnoverComputableSkuCount.toLocaleString("tr-TR"),sub:`${w.windowDays}g devir \xb7 ${w.totals.lowConfidenceRatePct.toFixed(1)}% d\xfcş\xfck g\xfcven`,tone:"accent"})]}),(0,b.jsxs)("div",{className:"stok-split",children:[(0,b.jsx)(n,{rows:w.items},w.distFilter?.distId??"all"),(0,b.jsx)(p,{snap:w})]}),(0,b.jsx)(o,{rows:w.brandSummary})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .stok-kpi-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
          gap: 12px;
          margin-bottom: 16px;
        }
        .stok-split {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
          align-items: start;
          margin-bottom: 16px;
        }
        @media (min-width: 1200px) {
          .stok-split { grid-template-columns: minmax(0, 1.7fr) minmax(300px, 0.8fr); }
        }
        .stok-panel {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          overflow: hidden;
        }
        .stok-panel-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 12px;
          padding: 14px 16px 10px;
          border-bottom: 1px solid var(--color-border);
        }
        .stok-panel-title {
          font-size: 14px;
          font-weight: 650;
          color: var(--color-fg);
          line-height: 1.25;
        }
        .stok-panel-meta {
          font-size: 11px;
          color: var(--color-muted);
          margin-top: 3px;
          line-height: 1.45;
        }
        .stok-table-wrap { overflow-x: auto; }
        .stok-table {
          width: 100%;
          border-collapse: collapse;
          min-width: 1260px;
          font-size: 12px;
        }
        .stok-table th {
          text-align: left;
          color: var(--color-muted);
          font-size: 10.5px;
          font-weight: 650;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 9px 12px;
          border-bottom: 1px solid var(--color-border);
          background: var(--color-surface-2);
          white-space: nowrap;
        }
        .stok-table td {
          padding: 10px 12px;
          border-bottom: 1px solid var(--color-border);
          vertical-align: middle;
          color: var(--color-fg);
        }
        .stok-table tr:last-child td { border-bottom: 0; }
        .stok-sku {
          display: flex;
          flex-direction: column;
          gap: 2px;
          min-width: 240px;
        }
        .stok-sku-name {
          font-weight: 600;
          line-height: 1.25;
          color: var(--color-fg);
        }
        .stok-risk-cell {
          display: flex;
          flex-direction: column;
          gap: 4px;
          align-items: flex-start;
        }
        .stok-lowconf {
          display: inline-flex;
          align-items: center;
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.02em;
          color: #92400e;
          background: rgba(245, 158, 11, 0.14);
          border: 1px solid rgba(245, 158, 11, 0.4);
          border-radius: 4px;
          padding: 1px 5px;
          white-space: nowrap;
          cursor: help;
        }
        .confidence {
          display: inline-flex;
          align-items: center;
          height: 18px;
          padding: 0 5px;
          border-radius: 4px;
          font-size: 10px;
          font-weight: 650;
          white-space: nowrap;
          border: 1px solid var(--color-border);
          background: var(--color-surface-2);
          color: var(--color-muted);
        }
        .confidence-high {
          color: #15803d;
          background: rgba(22, 163, 74, 0.09);
          border-color: rgba(22, 163, 74, 0.22);
        }
        .confidence-medium {
          color: #0e7490;
          background: rgba(14, 116, 144, 0.10);
          border-color: rgba(14, 116, 144, 0.24);
        }
        .confidence-low {
          color: #b45309;
          background: rgba(217, 119, 6, 0.11);
          border-color: rgba(217, 119, 6, 0.28);
        }
        :root[data-theme="dark"] .stok-lowconf {
          color: #fcd34d;
          background: rgba(245, 158, 11, 0.12);
          border-color: rgba(245, 158, 11, 0.35);
        }
        .stok-sku-code {
          color: var(--color-muted);
          font-size: 11px;
          line-height: 1.25;
        }
        .num {
          text-align: right;
          font-variant-numeric: tabular-nums;
          white-space: nowrap;
        }
        .risk-badge {
          display: inline-flex;
          align-items: center;
          height: 22px;
          padding: 0 7px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 650;
          white-space: nowrap;
        }
        .risk-critical { background: rgba(220, 38, 38, 0.10); color: #dc2626; }
        .risk-risk { background: rgba(217, 119, 6, 0.12); color: #b45309; }
        .risk-watch { background: rgba(14, 116, 144, 0.12); color: #0e7490; }
        .risk-healthy { background: rgba(22, 163, 74, 0.11); color: #15803d; }
        .risk-unknown { background: var(--color-surface-2); color: var(--color-muted); border: 1px solid var(--color-border); }
        .quality-grid {
          display: grid;
          gap: 10px;
          padding: 14px 16px 16px;
        }
        .quality-row {
          display: flex;
          align-items: baseline;
          justify-content: space-between;
          gap: 12px;
          padding-bottom: 9px;
          border-bottom: 1px solid var(--color-border);
        }
        .quality-row:last-child { border-bottom: 0; padding-bottom: 0; }
        .quality-label {
          font-size: 11.5px;
          color: var(--color-muted);
          line-height: 1.35;
        }
        .quality-value {
          font-size: 15px;
          font-weight: 700;
          color: var(--color-fg);
          font-variant-numeric: tabular-nums;
          white-space: nowrap;
        }
        .v3-error {
          background: var(--color-bad-bg, rgba(220, 38, 38, 0.05));
          border: 1px solid var(--color-bad, #dc2626);
          border-radius: 8px;
          padding: 14px 16px;
          margin-bottom: 20px;
          font-size: 13px;
          color: var(--color-fg);
        }
        .v3-error-hint {
          margin-top: 4px;
          font-size: 12px;
          color: var(--color-muted);
        }
      `}})]})}function m({label:a,value:c,sub:d,tone:e="neutral"}){return(0,b.jsxs)("div",{style:{background:"var(--color-surface)",border:"1px solid var(--color-border)",borderRadius:8,padding:"14px 16px",display:"flex",flexDirection:"column",gap:4,minWidth:0},children:[(0,b.jsx)("div",{style:{fontSize:10.5,color:"var(--color-muted)",textTransform:"uppercase",letterSpacing:"0.05em",fontWeight:650},children:a}),(0,b.jsx)("div",{style:{fontSize:24,fontWeight:750,color:{neutral:"var(--color-fg)",bad:"#dc2626",good:"#15803d",accent:"var(--color-accent)"}[e],fontVariantNumeric:"tabular-nums",lineHeight:1.1},children:c}),(0,b.jsx)("div",{style:{fontSize:11,color:"var(--color-muted-2)",lineHeight:1.35},children:d})]})}function n({rows:a}){return(0,d.panelHidden)("panel.stok.stockout")?null:(0,b.jsxs)("section",{className:"stok-panel",children:[(0,b.jsx)("div",{className:"stok-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"stok-panel-title",children:(0,d.panelTitle)("panel.stok.stockout","İlk Bitecek SKU'lar")}),(0,b.jsxs)("div",{className:"stok-panel-meta",children:["Risk sırası · kalan gün · tahmini tükenme · ",a.length.toLocaleString("tr-TR")," SKU (tümü, sayfalanmış)"]})]})}),(0,b.jsx)(i.StokSkuTable,{rows:a})]})}function o({rows:a}){if((0,d.panelHidden)("panel.stok.brandrisk"))return null;let c=a.reduce((a,b)=>a+b.criticalCount+b.riskCount,0);return(0,b.jsxs)("section",{className:"stok-panel",children:[(0,b.jsx)("div",{className:"stok-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"stok-panel-title",children:(0,d.panelTitle)("panel.stok.brandrisk","Marka Bazında Stok Riski")}),(0,b.jsxs)("div",{className:"stok-panel-meta",children:[a.length.toLocaleString("tr-TR")," marka · ",c.toLocaleString("tr-TR")," kritik+risk SKU"]})]})}),(0,b.jsx)("div",{className:"stok-table-wrap",children:(0,b.jsxs)("table",{className:"stok-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{children:"Marka"}),(0,b.jsx)("th",{className:"num",children:"SKU"}),(0,b.jsx)("th",{className:"num",children:"Kritik"}),(0,b.jsx)("th",{className:"num",children:"Risk"}),(0,b.jsx)("th",{className:"num",children:"İzle"}),(0,b.jsx)("th",{className:"num",children:"Sağlıklı"}),(0,b.jsx)("th",{className:"num",children:"Stok"}),(0,b.jsx)("th",{className:"num",children:"90g Satış"}),(0,b.jsx)("th",{className:"num",children:"Ort. Kalan"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>{var c;return(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{children:(0,b.jsx)("strong",{children:a.brand})}),(0,b.jsx)("td",{className:"num",children:a.skuCount.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:a.criticalCount.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:a.riskCount.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:a.watchCount.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:a.healthyCount.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:r(a.totalOnHandQty)}),(0,b.jsx)("td",{className:"num",children:r(a.totalSoldQty90d)}),(0,b.jsx)("td",{className:"num",children:null!=(c=a.avgDaysLeft)&&Number.isFinite(c)?c<1?"<1 gün":`${c<10?c.toFixed(1):Math.round(c).toLocaleString("tr-TR")} g\xfcn`:"-"})]},a.brand)})})]})})]})}function p({snap:a}){if((0,d.panelHidden)("panel.stok.quality"))return null;let c=a.totals.activeSkuCount,e=c>0?a.quality.stockSignalSkuCount/c*100:0,f=c>0?a.quality.leadTimeConfiguredSkuCount/c*100:0;return(0,b.jsxs)("aside",{className:"stok-panel",children:[(0,b.jsx)("div",{className:"stok-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"stok-panel-title",children:(0,d.panelTitle)("panel.stok.quality","Veri Güveni")}),(0,b.jsx)("div",{className:"stok-panel-meta",children:c>0?`%${e.toFixed(0)} sinyal taşıyan \xb7 %${f.toFixed(0)} lead time tanımlı (${c.toLocaleString("tr-TR")} SKU)`:"Stok türetimi ve devir hesap kalitesi"})]})}),(0,b.jsxs)("div",{className:"quality-grid",children:[(0,b.jsx)(q,{label:"Stok hareket sinyali olan SKU",value:a.quality.stockSignalSkuCount}),(0,b.jsx)(q,{label:"Sıfır stok görünen SKU",value:a.quality.zeroStockSkuCount}),(0,b.jsx)(q,{label:"Negatif stok görünen SKU",value:a.quality.negativeStockSkuCount}),(0,b.jsx)(q,{label:"Devir için güvenilmez SKU",value:a.quality.turnoverUnreliableSkuCount}),(0,b.jsx)(q,{label:"Açık sipariş sinyali olan SKU",value:a.quality.incomingOrderSkuCount}),(0,b.jsx)(q,{label:"Lead time tanımlı SKU",value:a.quality.leadTimeConfiguredSkuCount}),(0,b.jsx)(q,{label:"90g satış görmeyen SKU",value:a.totals.noDemandSkuCount})]})]})}function q({label:a,value:c}){return(0,b.jsxs)("div",{className:"quality-row",children:[(0,b.jsx)("span",{className:"quality-label",children:a}),(0,b.jsx)("span",{className:"quality-value",children:c.toLocaleString("tr-TR")})]})}function r(a){return Math.abs(a)>=1e4?(0,g.formatCompact)(a):a.toLocaleString("tr-TR",{maximumFractionDigits:+(a!==Math.trunc(a))})}function s(a){return new Date(`${a}T12:00:00`).toLocaleDateString("tr-TR",{day:"2-digit",month:"short"})}a.s(["default",0,l,"metadata",0,{title:"Stok Tükenme · V3 · Insider"}])},33543,a=>{a.n(a.i(34526))},23804,a=>{a.v(a=>Promise.resolve().then(()=>a(5246)))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1oe3jla._.js.map