(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,68703,e=>{"use strict";var a=e.i(43476),t=e.i(71645),r=e.i(18566),o=e.i(87194),l=e.i(12362);function n(){let[e,n]=(0,t.useState)(""),[i,s]=(0,t.useState)(""),[c,d]=(0,t.useState)([]),[u,p]=(0,t.useState)(""),[g,x]=(0,t.useState)(null),[h,b]=(0,t.useState)(!1),{login:f}=(0,o.useAuth)(),m=(0,r.useRouter)(),v=(0,r.useSearchParams)(),j=(0,l.useTenant)();async function y(a){if(a.preventDefault(),!e.trim()||!i.trim()||c.length>0&&!u)return;b(!0),x(null);let t=await f(e,i,c.length>0?u:void 0);if(t)x(t),b(!1);else{let e=v?.get("next"),a=j.ui?.defaultLanding??"/";m.push(e&&e.startsWith("/")?e:a),m.refresh()}}(0,t.useEffect)(()=>{let e=!0;return fetch("/api/auth/databases",{cache:"no-store"}).then(e=>e.json()).then(a=>{if(!e)return;let t=Array.isArray(a?.databases)?a.databases:[];d(t),t.length>0&&p(t[0].id)}).catch(()=>{}),()=>{e=!1}},[]);let w=j?.displayName??"Insider";return(0,a.jsxs)("div",{className:"login-wrap",children:[(0,a.jsxs)("form",{className:"login-card",onSubmit:y,children:[(0,a.jsx)("div",{className:"login-badge",children:(w[0]??"E").toUpperCase()}),(0,a.jsx)("h1",{className:"login-title",children:w}),(0,a.jsx)("p",{className:"login-sub",children:"Hesabınıza giriş yapın"}),(0,a.jsx)("label",{className:"login-label",htmlFor:"username",children:"Kullanıcı Adı"}),(0,a.jsx)("input",{id:"username",className:"login-input",type:"text",value:e,onChange:e=>n(e.target.value),placeholder:"Kullanıcı adınız",autoComplete:"username",autoFocus:!0}),(0,a.jsx)("label",{className:"login-label",htmlFor:"password",children:"Şifre"}),(0,a.jsx)("input",{id:"password",className:"login-input",type:"password",value:i,onChange:e=>s(e.target.value),placeholder:"Şifreniz",autoComplete:"current-password"}),c.length>0&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("label",{className:"login-label",htmlFor:"dbId",children:"Veritabanı"}),(0,a.jsx)("select",{id:"dbId",className:"login-input",value:u,onChange:e=>p(e.target.value),children:c.map(e=>(0,a.jsx)("option",{value:e.id,children:e.label},e.id))})]}),g&&(0,a.jsx)("p",{className:"login-error",children:g}),(0,a.jsx)("button",{className:"login-btn",type:"submit",disabled:h||!e.trim()||!i.trim()||c.length>0&&!u,children:h?"Giriş yapılıyor…":"Giriş Yap"})]}),(0,a.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .login-wrap { min-height: 70dvh; display: flex; align-items: center; justify-content: center; padding: 24px; }
        .login-card {
          width: 100%; max-width: 360px;
          display: flex; flex-direction: column;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 14px;
          padding: 32px 28px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.06);
        }
        .login-badge {
          width: 52px; height: 52px; border-radius: 14px;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          display: flex; align-items: center; justify-content: center;
          font-size: 22px; font-weight: 700; margin: 0 auto 16px;
        }
        .login-title { font-size: 20px; font-weight: 700; text-align: center; color: var(--color-fg); letter-spacing: -0.01em; }
        .login-sub { font-size: 13px; color: var(--color-muted); text-align: center; margin: 4px 0 22px; }
        .login-label { font-size: 12px; font-weight: 600; color: var(--color-fg); margin-bottom: 6px; }
        .login-input {
          width: 100%; box-sizing: border-box;
          padding: 10px 12px; margin-bottom: 16px;
          font-size: 14px; color: var(--color-fg);
          background: var(--color-bg, var(--color-surface));
          border: 1px solid var(--color-border); border-radius: 8px;
          font-family: inherit;
        }
        .login-input:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; border-color: transparent; }
        .login-error { font-size: 13px; color: var(--color-bad, #dc2626); margin: 0 0 14px; }
        .login-btn {
          width: 100%; padding: 11px 16px;
          font-size: 14px; font-weight: 600;
          color: var(--color-accent-fg, #fff); background: var(--color-accent);
          border: none; border-radius: 8px; cursor: pointer;
          transition: opacity 0.15s;
        }
        .login-btn:hover:not(:disabled) { opacity: 0.9; }
        .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      `}})]})}e.s(["default",0,function(){return(0,a.jsx)(t.Suspense,{fallback:null,children:(0,a.jsx)(n,{})})}])}]);