module.exports=[56548,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_api_auth_logout_route_actions_0zt-q41.js.map