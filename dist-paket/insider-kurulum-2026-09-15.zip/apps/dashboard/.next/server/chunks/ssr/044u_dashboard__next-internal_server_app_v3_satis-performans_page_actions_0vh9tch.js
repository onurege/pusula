module.exports=[39782,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_dashboard__next-internal_server_app_v3_satis-performans_page_actions_0vh9tch.js.map