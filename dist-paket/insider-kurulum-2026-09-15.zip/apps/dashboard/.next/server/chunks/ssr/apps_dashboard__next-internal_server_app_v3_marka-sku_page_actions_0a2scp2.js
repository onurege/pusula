module.exports=[32227,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_marka-sku_page_actions_0a2scp2.js.map