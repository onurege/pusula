module.exports=[11219,a=>{"use strict";a.s(["AktivasyonDistSelect",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call AktivasyonDistSelect() from the server but AktivasyonDistSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/aktivasyon/AktivasyonDistSelect.tsx <module evaluation>","AktivasyonDistSelect")},71683,a=>{"use strict";a.s(["AktivasyonDistSelect",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call AktivasyonDistSelect() from the server but AktivasyonDistSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/aktivasyon/AktivasyonDistSelect.tsx","AktivasyonDistSelect")},98537,a=>{"use strict";a.i(11219);var b=a.i(71683);a.n(b)},98720,a=>{"use strict";var b=a.i(7997),c=a.i(17239);a.i(2614);var d=a.i(12261),e=a.i(24580),f=a.i(1381),g=a.i(93105);function h({data:a}){if((0,g.panelHidden)("panel.risk.active"))return null;let c=a.degisimPct,d=c>2?"good":c<-2?"bad":"neutral",e=c>0?"+":"",i=a.segments.slice(0,8),j=Math.max(1,...i.map(a=>a.musteriSayi));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,g.panelTitle)("panel.risk.active","90 Gün Aktif Müşteri")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Son 90 gün içinde en az 1 fatura kesilmiş distinct müşteri · önceki 90 güne göre ","",(0,b.jsxs)("strong",{style:{color:"good"===d?"#16a34a":"bad"===d?"#dc2626":"var(--color-muted)"},children:[e,c.toFixed(1),"%"]})]})]})}),(0,b.jsxs)("div",{className:"act-hero",children:[(0,b.jsx)("div",{className:"act-hero-val",children:a.toplam.toLocaleString("tr-TR")}),(0,b.jsxs)("div",{className:"act-hero-sub",children:["aktif müşteri (önceki dönem:"," ",a.oncekiToplam.toLocaleString("tr-TR"),")"]})]}),(0,b.jsxs)("div",{className:"seg-list",children:[(0,b.jsx)("div",{className:"seg-title",children:"Müşteri Grup Kırılımı"}),0===i.length&&(0,b.jsx)("div",{className:"seg-empty",children:"Grup kırılımı verisi bulunamadı."}),i.map(a=>(0,b.jsxs)("div",{className:"seg-row",children:[(0,b.jsx)("div",{className:"seg-label",title:a.segment,children:a.segment}),(0,b.jsx)("div",{className:"seg-track",children:(0,b.jsx)("div",{className:"seg-fill",style:{width:`${a.musteriSayi/j*100}%`}})}),(0,b.jsxs)("div",{className:"seg-meta",children:[(0,b.jsx)("span",{className:"seg-val",children:(0,f.formatCompact)(a.musteriSayi)}),(0,b.jsxs)("span",{className:"seg-pct",children:["%",a.payPct.toFixed(1)]})]})]},a.segment))]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .act-hero {
          background: var(--color-surface-2, rgba(0,0,0,0.02));
          border-radius: 10px;
          padding: 16px 18px;
          margin-bottom: 14px;
        }
        .act-hero-val {
          font-size: 36px;
          font-weight: 700;
          color: var(--color-fg);
          letter-spacing: -0.025em;
          font-variant-numeric: tabular-nums;
          line-height: 1.05;
        }
        .act-hero-sub {
          font-size: 12px;
          color: var(--color-muted);
          margin-top: 4px;
        }
        .seg-list { display: flex; flex-direction: column; gap: 6px; }
        .seg-title {
          font-size: 10.5px; font-weight: 600; color: var(--color-muted);
          letter-spacing: 0.05em; text-transform: uppercase;
          margin-bottom: 4px;
        }
        .seg-empty {
          font-size: 12px; color: var(--color-muted-2); padding: 8px 0;
        }
        .seg-row {
          display: grid;
          grid-template-columns: minmax(120px, 1fr) 2fr auto;
          align-items: center;
          gap: 12px;
          font-size: 12.5px;
        }
        .seg-label {
          color: var(--color-fg);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .seg-track {
          height: 8px;
          background: var(--color-border);
          border-radius: 4px;
          overflow: hidden;
        }
        .seg-fill {
          height: 100%;
          background: var(--color-accent);
          border-radius: 4px;
        }
        .seg-meta {
          display: flex;
          gap: 8px;
          font-variant-numeric: tabular-nums;
          color: var(--color-muted);
        }
        .seg-val { color: var(--color-fg); font-weight: 600; }
      `}})]})}function i({items:a}){return(0,g.panelHidden)("panel.risk.silent")?null:(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,g.panelTitle)("panel.risk.silent","Sessizleşen Müşteriler")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Önceki 90g aktif ama son 90g sıfır · ",a.length," müşteri"]})]})}),(0,b.jsx)("div",{className:"v3-table-wrap",children:(0,b.jsxs)("table",{className:"v3-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{children:"Müşteri"}),(0,b.jsx)("th",{children:"Şehir"}),(0,b.jsx)("th",{children:"Son Satış"}),(0,b.jsx)("th",{className:"num",children:"Sessiz Gün"}),(0,b.jsx)("th",{className:"num",children:"Önceki 90g Ciro"}),(0,b.jsx)("th",{children:"Son Marka"})]})}),(0,b.jsxs)("tbody",{children:[0===a.length&&(0,b.jsx)("tr",{children:(0,b.jsx)("td",{colSpan:6,className:"empty",children:"Bu dönem için sessizleşen müşteri yok."})}),a.map(a=>(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"unvan",title:a.unvan,children:a.unvan.length>48?a.unvan.slice(0,45)+"…":a.unvan}),(0,b.jsx)("td",{children:a.sehir||"—"}),(0,b.jsx)("td",{className:"num",children:function(a){if(!a)return"—";try{return new Date(a).toLocaleDateString("tr-TR",{day:"2-digit",month:"short",year:"2-digit"})}catch{return"—"}}(a.sonSatisTarihi)}),(0,b.jsx)("td",{className:"num",children:(0,b.jsxs)("span",{className:"silent-days",style:{color:a.sessizGun>150?"#dc2626":a.sessizGun>120?"#d97706":"var(--color-fg)"},children:[a.sessizGun,"g"]})}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,f.formatCompact)(a.oncekiCiro)]}),(0,b.jsx)("td",{className:"marka",children:a.sonMarka||"—"})]},a.id))]})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .silent-days {
          font-variant-numeric: tabular-nums;
          font-weight: 600;
        }
        .marka {
          font-size: 12px;
          color: var(--color-muted);
        }
        .empty {
          text-align: center;
          color: var(--color-muted);
          padding: 20px 0;
          font-size: 12.5px;
        }
      `}})]})}function j({items:a}){if((0,g.panelHidden)("panel.risk.strategic"))return null;let c=[...a].sort((a,b)=>b.sessizMusteri-a.sessizMusteri),d=Math.max(1,...c.map(a=>a.sessizMusteri));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,g.panelTitle)("panel.risk.strategic","Stratejik Marka Sessizliği")}),(0,b.jsx)("div",{className:"v3-panel-sub",children:"Önceden alan ama son 90 gün sessiz · stratejik markalar için saha aksiyon listesi"})]})}),0===c.length&&(0,b.jsx)("div",{className:"ss-empty",children:"Stratejik marka tanımı yok veya bu dönem için veri bulunamadı."}),(0,b.jsx)("div",{className:"ss-bars",children:c.map(a=>(0,b.jsxs)("div",{className:"ss-row",children:[(0,b.jsxs)("div",{className:"ss-label",title:a.marka,children:[(0,b.jsx)("span",{className:"strat-dot"}),a.marka]}),(0,b.jsx)("div",{className:"ss-track",children:(0,b.jsx)("div",{className:"ss-fill",style:{width:`${a.sessizMusteri/d*100}%`}})}),(0,b.jsxs)("div",{className:"ss-meta",children:[(0,b.jsx)("span",{className:"ss-sessiz",children:a.sessizMusteri}),(0,b.jsxs)("span",{className:"ss-toplam",children:["/ ",a.toplamMusteri]}),(0,b.jsxs)("span",{className:"ss-pct",children:["%",a.sessizPct.toFixed(0)]})]})]},a.marka))}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .ss-empty {
          font-size: 12.5px;
          color: var(--color-muted);
          padding: 12px 0;
        }
        .ss-bars { display: flex; flex-direction: column; gap: 8px; }
        .ss-row {
          display: grid;
          grid-template-columns: minmax(120px, 1.2fr) 2fr auto;
          align-items: center;
          gap: 12px;
          font-size: 12.5px;
        }
        .ss-label {
          display: flex; align-items: center; gap: 6px;
          color: var(--color-fg);
          font-weight: 500;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .strat-dot {
          width: 8px; height: 8px; border-radius: 50%;
          background: var(--color-accent);
          flex-shrink: 0;
        }
        .ss-track {
          height: 10px;
          background: var(--color-border);
          border-radius: 4px;
          overflow: hidden;
        }
        .ss-fill {
          height: 100%;
          background: #FAC775;
          border-radius: 4px;
        }
        .ss-meta {
          display: flex;
          gap: 4px;
          align-items: baseline;
          font-variant-numeric: tabular-nums;
        }
        .ss-sessiz { font-weight: 700; color: var(--color-fg); font-size: 13.5px; }
        .ss-toplam { color: var(--color-muted-2); font-size: 11.5px; }
        .ss-pct {
          margin-left: 6px;
          padding: 1px 6px;
          background: var(--color-border);
          border-radius: 3px;
          color: var(--color-muted);
          font-size: 11px;
          font-weight: 600;
        }
      `}})]})}let k={critical:"#F7C1C1",risk:"#FAC775",watch:"#D3D1C7",healthy:"#9FE1CB",unknown:"#E6E4DC"},l={critical:"Kritik",risk:"Risk",watch:"Takip",healthy:"Sağlıklı",unknown:"Bilinmiyor"};function m({buckets:a}){if((0,g.panelHidden)("panel.risk.tier"))return null;let c=["critical","risk","watch","healthy","unknown"],d=[...a].sort((a,b)=>c.indexOf(a.tier)-c.indexOf(b.tier)),e=d.reduce((a,b)=>a+b.musteriSayi,0),f=2*Math.PI*44,h=0,i=d.map(a=>{let b=e>0?a.musteriSayi/e*f:0,c=f-h;return h+=b,{...a,dasharray:`${b} ${f-b}`,dashoffset:c}});return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,g.panelTitle)("panel.risk.tier","Risk Tier Dağılımı")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["map_customers.risk_tier_v2 · ",e.toLocaleString("tr-TR")," müşteri"]})]})}),0===e?(0,b.jsx)("div",{className:"rt-empty",children:"Risk skorları henüz hesaplanmamış. SQLite mirror'ın senkronize edilmesi gerekiyor."}):(0,b.jsxs)("div",{className:"rt-wrap",children:[(0,b.jsx)("div",{className:"rt-donut",children:(0,b.jsxs)("svg",{viewBox:"0 0 120 120",width:"160",height:"160",children:[(0,b.jsx)("circle",{cx:"60",cy:"60",r:44,fill:"none",stroke:"var(--color-border)",strokeWidth:"16"}),i.map(a=>(0,b.jsx)("circle",{cx:"60",cy:"60",r:44,fill:"none",stroke:k[a.tier]??"#ccc",strokeWidth:"16",strokeDasharray:a.dasharray,strokeDashoffset:a.dashoffset,transform:"rotate(-90 60 60)"},a.tier)),(0,b.jsx)("text",{x:"60",y:"58",textAnchor:"middle",fontSize:"18",fontWeight:"700",fill:"var(--color-fg)",children:e.toLocaleString("tr-TR")}),(0,b.jsx)("text",{x:"60",y:"74",textAnchor:"middle",fontSize:"9",fill:"var(--color-muted)",children:"müşteri"})]})}),(0,b.jsx)("div",{className:"rt-legend",children:d.map(a=>(0,b.jsxs)("div",{className:"rt-row",children:[(0,b.jsx)("span",{className:"rt-dot",style:{background:k[a.tier]??"#ccc"}}),(0,b.jsx)("span",{className:"rt-label",children:l[a.tier]??a.tier}),(0,b.jsx)("span",{className:"rt-sayi",children:a.musteriSayi.toLocaleString("tr-TR")}),(0,b.jsxs)("span",{className:"rt-pct",children:["%",a.payPct.toFixed(1)]})]},a.tier))})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .rt-empty {
          font-size: 12.5px; color: var(--color-muted); padding: 16px 0;
        }
        .rt-wrap {
          display: flex; gap: 20px; align-items: center; flex-wrap: wrap;
        }
        .rt-donut { flex-shrink: 0; }
        .rt-legend {
          display: flex; flex-direction: column; gap: 8px;
          flex: 1; min-width: 180px;
        }
        .rt-row {
          display: grid;
          grid-template-columns: 12px 1fr auto auto;
          align-items: center;
          gap: 10px;
          font-size: 12.5px;
          padding: 4px 0;
          border-bottom: 1px dashed var(--color-border);
        }
        .rt-row:last-child { border-bottom: none; }
        .rt-dot { width: 10px; height: 10px; border-radius: 50%; }
        .rt-label { color: var(--color-fg); }
        .rt-sayi {
          color: var(--color-fg); font-weight: 600;
          font-variant-numeric: tabular-nums;
        }
        .rt-pct {
          color: var(--color-muted); font-size: 11px;
          font-variant-numeric: tabular-nums;
          min-width: 42px; text-align: right;
        }
      `}})]})}function n({items:a}){return(0,g.panelHidden)("panel.risk.recovery")?null:(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,g.panelTitle)("panel.risk.recovery","Yeniden Kazanım Fırsatları")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Yüksek geçmiş cirosu + 60g+ sessizlik · Top ",a.length," müşteri"]})]})}),(0,b.jsx)("div",{className:"v3-table-wrap",children:(0,b.jsxs)("table",{className:"v3-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"Müşteri"}),(0,b.jsx)("th",{children:"Şehir"}),(0,b.jsx)("th",{className:"num",children:"Ciro (90g)"}),(0,b.jsx)("th",{className:"num",children:"Sessiz"}),(0,b.jsx)("th",{children:"Risk"})]})}),(0,b.jsxs)("tbody",{children:[0===a.length&&(0,b.jsx)("tr",{children:(0,b.jsx)("td",{colSpan:6,className:"empty",children:"Mirror henüz hesaplanmamış veya bu kriterlere uyan müşteri yok."})}),a.map((a,c)=>{let d=a.riskTier||"unknown",e=k[d]??"#E6E4DC",g=l[d]??d;return(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:c+1}),(0,b.jsx)("td",{className:"unvan",title:a.unvan,children:a.unvan.length>42?a.unvan.slice(0,39)+"…":a.unvan}),(0,b.jsx)("td",{children:a.sehir||"—"}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,f.formatCompact)(a.cirot90)]}),(0,b.jsxs)("td",{className:"num",children:[a.sessizGun,"g"]}),(0,b.jsx)("td",{children:(0,b.jsx)("span",{className:"risk-chip",style:{background:e,color:"#1c1c1c"},children:g})})]},a.id)})]})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .risk-chip {
          display: inline-block;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.02em;
        }
        .empty {
          text-align: center;
          color: var(--color-muted);
          padding: 20px 0;
          font-size: 12.5px;
        }
      `}})]})}var o=a.i(98537);async function p({searchParams:a}){let f=(0,d.getTenantConfig)(),g=await a,k=null!=g.distId?Number(g.distId):null,l=null!=k&&Number.isFinite(k)?k:null,q=null,r=null;try{q=await (0,c.getWietnauerAktivasyon)({distId:l})}catch(a){r=a.message}let s=[];try{s=await (0,c.getAllowedDistributors)()}catch{s=[]}let t=null!=l?s.find(a=>a.id===l)??null:null;return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(e.V3PageHeader,{eyebrow:"Dashboard 06",title:"Müşteri Aktivasyon & Risk",contentKey:"page.risk.title",descKey:"page.risk.desc",description:t?`${t.ad} — son 90 g\xfcnde aktif/sessiz ayrımı, stratejik marka sessizliği ve risk skoru bazlı yeniden kazanım hedefleri. Saha ekibi i\xe7in aksiyon listesi.`:`${f.displayName} t\xfcm portf\xf6yde son 90 g\xfcnde aktif/sessiz ayrımı, stratejik marka sessizliği ve risk skoru bazlı yeniden kazanım hedefleri. Belirli bir distrib\xfct\xf6re odaklanmak i\xe7in dropdown'dan se\xe7.`,dataNote:"TBLMSDFATURA · 90/180g pencere · TBLMUSTERIGRUPKIRILIM müşteri grup kırılımı · map_customers risk_tier_v2",generatedAt:q?.generatedAt}),r&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",r,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula."})]}),q&&(0,b.jsx)(o.AktivasyonDistSelect,{distributors:s,selectedDistId:l}),q&&(0,b.jsxs)("div",{className:"v3-content-grid",children:[(0,b.jsxs)("div",{className:"col-left",children:[(0,b.jsx)(h,{data:q.active}),(0,b.jsx)(i,{items:q.silent})]}),(0,b.jsxs)("div",{className:"col-right",children:[(0,b.jsx)(m,{buckets:q.riskTiers}),(0,b.jsx)(j,{items:q.strategicSilence}),(0,b.jsx)(n,{items:q.recovery})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .v3-content-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
        }
        @media (min-width: 1080px) {
          .v3-content-grid {
            grid-template-columns: 1.4fr 1fr;
            align-items: start;
          }
        }
        .col-left, .col-right {
          display: flex; flex-direction: column; gap: 16px; min-width: 0;
        }
        .v3-error {
          background: var(--color-bad-bg, rgba(220, 38, 38, 0.05));
          border: 1px solid var(--color-bad, #dc2626);
          border-radius: 8px;
          padding: 14px 16px;
          margin-bottom: 20px;
          font-size: 13px;
          color: var(--color-fg);
        }
        .v3-error-hint {
          margin-top: 4px;
          font-size: 12px;
          color: var(--color-muted);
        }

        /* --- Ortak v3-panel iskeleti --- */
        .v3-panel {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 10px;
          padding: 18px 20px;
        }
        .v3-panel-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 16px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }
        .v3-panel-title {
          font-size: 15px;
          font-weight: 600;
          color: var(--color-fg);
          letter-spacing: -0.01em;
        }
        .v3-panel-sub {
          font-size: 12px;
          color: var(--color-muted);
          margin-top: 2px;
        }

        /* --- Ortak v3-table iskeleti --- */
        .v3-table-wrap {
          overflow-x: auto;
          margin: 0 -4px;
        }
        .v3-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 12.5px;
        }
        .v3-table thead th {
          text-align: left;
          padding: 8px 10px;
          font-size: 10.5px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
          border-bottom: 1px solid var(--color-border);
          white-space: nowrap;
        }
        .v3-table thead th.num {
          text-align: right;
        }
        .v3-table tbody tr {
          border-bottom: 1px solid var(--color-border);
        }
        .v3-table tbody tr:hover {
          background: var(--color-surface-2, rgba(0,0,0,0.02));
        }
        .v3-table td {
          padding: 9px 10px;
          color: var(--color-fg);
          vertical-align: middle;
        }
        .v3-table td.rank {
          font-weight: 600;
          color: var(--color-muted);
          font-variant-numeric: tabular-nums;
          width: 30px;
        }
        .v3-table td.unvan {
          font-weight: 500;
          max-width: 320px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .v3-table td.num {
          text-align: right;
          font-variant-numeric: tabular-nums;
        }
      `}})]})}a.s(["default",0,p,"metadata",0,{title:"Müşteri Aktivasyon & Risk · V3 · Insider"}],98720)},259,a=>{a.n(a.i(98720))}];

//# sourceMappingURL=apps_dashboard_11s1p5_._.js.map