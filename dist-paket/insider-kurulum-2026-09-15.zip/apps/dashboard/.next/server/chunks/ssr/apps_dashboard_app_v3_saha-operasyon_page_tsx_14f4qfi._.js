module.exports=[20602,a=>{"use strict";var b=a.i(7997),c=a.i(17239),d=a.i(93105);a.i(2614);var e=a.i(12261),f=a.i(24580),g=a.i(1980),h=a.i(30590);function i({rows:a,kpi:c}){if((0,d.panelHidden)("panel.saha.daily"))return null;let e=Math.max(1,...a.map(a=>a.toplam)),f=a=>new Date(`${a}T00:00:00`).toLocaleDateString("tr-TR",{day:"2-digit",month:"short"}),g=a.reduce((a,b)=>a+b.rutIci,0),h=a.reduce((a,b)=>a+b.rutDisi,0),k=g+h,l=k>0?h/k*100:0;return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsxs)("div",{className:"v3-panel-head",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.saha.daily","Günlük Ziyaret Trendi")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Son 30 gün · ",k.toLocaleString("tr-TR")," ziyaret · Rut dışı payı ",(0,b.jsxs)("strong",{children:["%",l.toFixed(1)]})]})]}),(0,b.jsxs)("div",{className:"v3-panel-legend",children:[(0,b.jsxs)("span",{className:"lg lg-rut",children:[(0,b.jsx)("span",{className:"dot",style:{background:"#9FE1CB"}})," Rut içi"]}),(0,b.jsxs)("span",{className:"lg lg-rd",children:[(0,b.jsx)("span",{className:"dot",style:{background:"#FAC775"}})," Rut dışı"]})]})]}),(0,b.jsxs)("div",{className:"saha-kpi-row",children:[(0,b.jsx)(j,{label:"Son 7g ziyaret",value:c.son7gZiyaret.toLocaleString("tr-TR")}),(0,b.jsx)(j,{label:"Son 7g müşteri",value:c.son7gUniqueMusteri.toLocaleString("tr-TR")}),(0,b.jsx)(j,{label:"Aktif temsilci",value:c.son7gAktifTemsilci.toLocaleString("tr-TR")}),(0,b.jsx)(j,{label:"Sipariş dönüşüm",value:`%${c.son7gDonusumPct.toFixed(1)}`,accent:!0})]}),(0,b.jsx)("div",{className:"saha-bars",children:a.map(a=>{var c;let d,g=a.toplam/e*100,h=a.toplam>0?a.rutIci/a.toplam*g:0,i=a.toplam>0?a.rutDisi/a.toplam*g:0,j=(c=a.gun,0===(d=new Date(`${c}T00:00:00`).getDay())||6===d);return(0,b.jsxs)("div",{className:`saha-bar-col ${j?"weekend":""}`,title:`${f(a.gun)} — ${a.toplam} ziyaret (rut i\xe7i: ${a.rutIci}, rut dışı: ${a.rutDisi})`,children:[(0,b.jsxs)("div",{className:"saha-bar-stack",children:[(0,b.jsx)("div",{className:"saha-bar-rd",style:{height:`${i}%`,background:"#FAC775"}}),(0,b.jsx)("div",{className:"saha-bar-ri",style:{height:`${h}%`,background:"#9FE1CB"}})]}),(0,b.jsx)("div",{className:"saha-bar-label",children:f(a.gun).replace(/\s/g," ")})]},a.gun)})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 12px;
          padding: 18px 20px;
        }
        .v3-panel-head {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 14px;
          flex-wrap: wrap;
        }
        .v3-panel-title {
          font-size: 15px;
          font-weight: 600;
          color: var(--color-fg);
        }
        .v3-panel-sub {
          font-size: 12px;
          color: var(--color-muted);
          margin-top: 2px;
          line-height: 1.45;
        }
        .v3-panel-legend {
          display: flex;
          gap: 12px;
          font-size: 11px;
          color: var(--color-muted);
        }
        .v3-panel-legend .lg { display: inline-flex; align-items: center; gap: 5px; }
        .v3-panel-legend .dot {
          display: inline-block;
          width: 10px;
          height: 10px;
          border-radius: 2px;
        }
        .saha-kpi-row {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
          margin-bottom: 16px;
        }
        @media (max-width: 720px) {
          .saha-kpi-row { grid-template-columns: repeat(2, 1fr); }
        }
        .saha-kpi-mini {
          background: var(--color-surface-2);
          border-radius: 8px;
          padding: 10px 12px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .saha-kpi-mini.accent {
          background: var(--color-accent-soft, rgba(159, 225, 203, 0.18));
        }
        .saha-kpi-mini .lbl {
          font-size: 10px;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.05em;
          font-weight: 600;
        }
        .saha-kpi-mini .val {
          font-size: 18px;
          font-weight: 700;
          color: var(--color-fg);
          font-variant-numeric: tabular-nums;
          letter-spacing: -0.02em;
        }
        .saha-kpi-mini.accent .val { color: var(--color-accent); }
        .saha-bars {
          display: grid;
          grid-template-columns: repeat(${a.length||1}, 1fr);
          gap: 3px;
          height: 220px;
          align-items: end;
        }
        .saha-bar-col {
          display: flex;
          flex-direction: column;
          align-items: stretch;
          gap: 4px;
          height: 100%;
          min-width: 0;
          cursor: default;
        }
        .saha-bar-stack {
          flex: 1;
          display: flex;
          flex-direction: column-reverse;
          justify-content: flex-start;
          min-height: 0;
          background: var(--color-surface-2);
          border-radius: 3px 3px 0 0;
          overflow: hidden;
          transition: opacity 0.15s;
        }
        .saha-bar-col:hover .saha-bar-stack { opacity: 0.82; }
        .saha-bar-ri, .saha-bar-rd { width: 100%; }
        .saha-bar-rd { border-radius: 3px 3px 0 0; }
        .saha-bar-label {
          font-size: 9px;
          color: var(--color-muted-2);
          text-align: center;
          line-height: 1.2;
          font-variant-numeric: tabular-nums;
          letter-spacing: -0.02em;
          overflow: hidden;
          white-space: nowrap;
        }
        .saha-bar-col.weekend .saha-bar-label {
          color: var(--color-bad, #dc2626);
          opacity: 0.75;
        }
      `}})]})}function j({label:a,value:c,accent:d}){return(0,b.jsxs)("div",{className:`saha-kpi-mini ${d?"accent":""}`,children:[(0,b.jsx)("div",{className:"lbl",children:a}),(0,b.jsx)("div",{className:"val",children:c})]})}function k({coverage:a}){if((0,d.panelHidden)("panel.saha.coverage"))return null;let c=Math.max(0,Math.min(100,a.kapsamaPct)),e=2*Math.PI*40,f=c/100*e,g=c>=60?"var(--color-good, #16a34a)":c>=35?"var(--color-accent, #9FE1CB)":"var(--color-bad, #dc2626)",h=Math.max(1,...a.segments.map(a=>a.aktif));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.saha.coverage","Aktif Müşteri Kapsama")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Son 30g'de ziyaret edilen / son 90g'de aktif (fatura kesilmiş) müşteri · müşteri grup kırılımına göre"," ",a.segments.length>0?`(${a.segments.length} kırılım)`:""]})]})}),(0,b.jsxs)("div",{className:"cov-grid",children:[(0,b.jsxs)("div",{className:"cov-donut-wrap",children:[(0,b.jsxs)("svg",{viewBox:"0 0 100 100",className:"cov-donut",children:[(0,b.jsx)("circle",{cx:"50",cy:"50",r:40,fill:"none",stroke:"var(--color-surface-2)",strokeWidth:"14"}),(0,b.jsx)("circle",{cx:"50",cy:"50",r:40,fill:"none",stroke:g,strokeWidth:"14",strokeDasharray:`${f} ${e}`,strokeDashoffset:e/4,strokeLinecap:"round",transform:"rotate(-90 50 50)"}),(0,b.jsxs)("text",{x:"50",y:"48",textAnchor:"middle",className:"cov-donut-pct",style:{fill:"var(--color-fg)"},children:["%",c.toFixed(1)]}),(0,b.jsx)("text",{x:"50",y:"60",textAnchor:"middle",className:"cov-donut-sub",style:{fill:"var(--color-muted)"},children:"kapsama"})]}),(0,b.jsxs)("div",{className:"cov-totals",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("span",{className:"num",children:a.totalZiyaretEdilen.toLocaleString("tr-TR")}),(0,b.jsx)("span",{className:"lbl",children:"ziyaret edilen (30g)"})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("span",{className:"num",children:a.totalAktif.toLocaleString("tr-TR")}),(0,b.jsx)("span",{className:"lbl",children:"aktif portföy (90g)"})]})]})]}),(0,b.jsxs)("div",{className:"cov-segments",children:[(0,b.jsxs)("div",{className:"cov-seg-head",children:[(0,b.jsx)("span",{children:"Müşteri Grup Kırılımı"}),(0,b.jsx)("span",{className:"num",children:"Aktif"}),(0,b.jsx)("span",{className:"num",children:"Ziyaret"}),(0,b.jsx)("span",{className:"num",children:"Kapsama"})]}),a.segments.map(a=>(0,b.jsxs)("div",{className:"cov-seg-row",children:[(0,b.jsx)("div",{className:"cov-seg-label",title:a.segment,children:a.segment}),(0,b.jsx)("div",{className:"num",children:a.aktif.toLocaleString("tr-TR")}),(0,b.jsx)("div",{className:"num",children:a.ziyaretEdilen.toLocaleString("tr-TR")}),(0,b.jsxs)("div",{className:"cov-seg-bar-wrap",children:[(0,b.jsx)("span",{className:"cov-seg-bar",style:{width:`${Math.min(a.kapsamaPct,100)}%`,background:a.kapsamaPct>=60?"var(--color-good, #16a34a)":a.kapsamaPct>=35?"#9FE1CB":"#FAC775"}}),(0,b.jsxs)("span",{className:"cov-seg-pct",children:["%",a.kapsamaPct.toFixed(1)]})]}),(0,b.jsx)("div",{className:"cov-seg-track",children:(0,b.jsx)("div",{className:"cov-seg-track-aktif",style:{width:`${a.aktif/h*100}%`}})})]},a.segment)),0===a.segments.length&&(0,b.jsx)("div",{className:"cov-empty",children:"Grup kırılımı verisi yok."})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .cov-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 18px;
        }
        @media (min-width: 720px) {
          .cov-grid { grid-template-columns: 220px 1fr; align-items: start; }
        }
        .cov-donut-wrap {
          display: flex;
          flex-direction: column;
          gap: 12px;
          align-items: center;
        }
        .cov-donut {
          width: 180px;
          height: 180px;
        }
        .cov-donut-pct {
          font-size: 13px;
          font-weight: 700;
          font-variant-numeric: tabular-nums;
        }
        .cov-donut-sub {
          font-size: 5.5px;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 0.08em;
        }
        .cov-totals {
          display: flex;
          flex-direction: column;
          gap: 6px;
          text-align: center;
        }
        .cov-totals .num {
          font-size: 16px;
          font-weight: 700;
          color: var(--color-fg);
          font-variant-numeric: tabular-nums;
          letter-spacing: -0.02em;
          margin-right: 6px;
        }
        .cov-totals .lbl {
          font-size: 11px;
          color: var(--color-muted);
        }
        .cov-segments {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .cov-seg-head, .cov-seg-row {
          display: grid;
          grid-template-columns: 1.5fr 0.7fr 0.7fr 1.2fr;
          gap: 10px;
          padding: 6px 8px;
          align-items: center;
        }
        .cov-seg-head {
          font-size: 10px;
          color: var(--color-muted-2);
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          border-bottom: 1px solid var(--color-border);
        }
        .cov-seg-row {
          font-size: 12px;
          color: var(--color-fg);
          border-bottom: 1px solid var(--color-border);
        }
        .cov-seg-row:last-child { border-bottom: none; }
        .cov-seg-label {
          font-weight: 500;
          color: var(--color-fg);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .num {
          text-align: right;
          font-variant-numeric: tabular-nums;
        }
        .cov-seg-bar-wrap {
          position: relative;
          height: 16px;
          background: var(--color-surface-2);
          border-radius: 3px;
          overflow: hidden;
        }
        .cov-seg-bar {
          display: block;
          height: 100%;
          border-radius: 3px;
        }
        .cov-seg-pct {
          position: absolute;
          top: 0;
          left: 6px;
          line-height: 16px;
          font-size: 10px;
          font-weight: 600;
          color: var(--color-fg-2, var(--color-fg));
          font-variant-numeric: tabular-nums;
        }
        .cov-seg-track { display: none; }
        .cov-empty {
          padding: 16px 8px;
          font-size: 12px;
          color: var(--color-muted);
          text-align: center;
        }
      `}})]})}var l=a.i(1381);function m({rows:a}){return(0,d.panelHidden)("panel.saha.rep")?null:(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.saha.rep","Temsilci Performansı")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Son 30g · Top ",a.length," temsilci · ziyaret + dönüşüm + rut dışı payı"]})]})}),0===a.length?(0,b.jsx)("div",{className:"empty",children:"Bu pencerede ziyaret kaydı yok."}):(0,b.jsx)("div",{className:"v3-table-wrap",children:(0,b.jsxs)("table",{className:"v3-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"Temsilci"}),(0,b.jsx)("th",{children:"Distribütör"}),(0,b.jsx)("th",{className:"num",children:"Ziyaret"}),(0,b.jsx)("th",{className:"num",children:"Aktif Müşteri"}),(0,b.jsx)("th",{className:"num",children:"Sipariş"}),(0,b.jsx)("th",{className:"num",children:"Dönüşüm"}),(0,b.jsx)("th",{className:"num",children:"Rut Dışı"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:a.rank}),(0,b.jsx)("td",{className:"unvan",title:a.ad,children:a.ad.length>40?a.ad.slice(0,37)+"…":a.ad}),(0,b.jsx)("td",{children:a.distributor||"—"}),(0,b.jsx)("td",{className:"num",children:(0,l.formatCompact)(a.ziyaret)}),(0,b.jsx)("td",{className:"num",title:"Son 30g fatura kesilen distinct müşteri",children:a.aktifMusteri.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:a.siparisliZiyaret.toLocaleString("tr-TR")}),(0,b.jsxs)("td",{className:"num",style:{color:a.donusumPct>=70?"var(--color-good, #16a34a)":a.donusumPct>=40?"var(--color-fg)":"var(--color-bad, #dc2626)"},children:["%",a.donusumPct.toFixed(0)]}),(0,b.jsxs)("td",{className:"num",style:{color:a.rutDisiPct>30?"var(--color-warn, #d97706)":"var(--color-muted-2)"},children:["%",a.rutDisiPct.toFixed(0)]})]},a.repId))})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .empty { padding: 24px; color: var(--color-muted); font-size: 13px; text-align: center; }
      `}})]})}function n({rows:a}){return(0,d.panelHidden)("panel.saha.conversion")?null:(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.saha.conversion","Ziyaret → Sipariş Dönüşümü")}),(0,b.jsx)("div",{className:"v3-panel-sub",children:"Son 30g · Rut içi vs Rut dışı · sipariş, fatura, irsaliye kırılımıyla"})]})}),(0,b.jsx)("div",{className:"conv-grid",children:a.map(a=>{let c="Rut İçi"===a.tip?"#9FE1CB":"#FAC775",d=a.donusumPct>=70?"#16a34a":a.donusumPct>=40?"#78716c":"#dc2626";return(0,b.jsxs)("div",{className:"conv-card",children:[(0,b.jsxs)("div",{className:"conv-head",children:[(0,b.jsx)("span",{className:"conv-dot",style:{background:c}}),(0,b.jsx)("span",{className:"conv-title",children:a.tip})]}),(0,b.jsxs)("div",{className:"conv-hero",style:{color:d},children:["%",a.donusumPct.toFixed(1)]}),(0,b.jsx)("div",{className:"conv-sub",children:"dönüşüm oranı"}),(0,b.jsx)("table",{className:"conv-table",children:(0,b.jsxs)("tbody",{children:[(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{children:"Ziyaret"}),(0,b.jsx)("td",{className:"num",children:a.ziyaret.toLocaleString("tr-TR")})]}),(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{children:"Siparişli"}),(0,b.jsx)("td",{className:"num",children:a.siparisli.toLocaleString("tr-TR")})]}),(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{children:"Faturalı"}),(0,b.jsx)("td",{className:"num",children:a.faturali.toLocaleString("tr-TR")})]}),(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{children:"İrsaliyeli"}),(0,b.jsx)("td",{className:"num",children:a.irsaliyeli.toLocaleString("tr-TR")})]})]})})]},a.tip)})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .conv-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        @media (max-width: 600px) { .conv-grid { grid-template-columns: 1fr; } }
        .conv-card { background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: 8px; padding: 14px 16px; }
        .conv-head { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
        .conv-dot { width: 10px; height: 10px; border-radius: 50%; }
        .conv-title { font-size: 13px; font-weight: 600; color: var(--color-fg); }
        .conv-hero { font-size: 30px; font-weight: 700; letter-spacing: -0.02em; font-variant-numeric: tabular-nums; line-height: 1; }
        .conv-sub { font-size: 11px; color: var(--color-muted); margin: 2px 0 10px; }
        .conv-table { width: 100%; font-size: 12px; border-collapse: collapse; }
        .conv-table td { padding: 4px 0; color: var(--color-fg-2); border-bottom: 1px dashed var(--color-border); }
        .conv-table td.num { text-align: right; font-variant-numeric: tabular-nums; color: var(--color-fg); font-weight: 500; }
      `}})]})}function o({rows:a}){return(0,d.panelHidden)("panel.saha.distcompare")?null:(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.saha.distcompare","Distribütör Karşılaştırma")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Son 30g · Top ",a.length," distribütör operasyonel performansı"]})]})}),0===a.length?(0,b.jsx)("div",{className:"empty",children:"Bu pencerede ziyaret kaydı yok."}):(0,b.jsx)("div",{className:"v3-table-wrap",children:(0,b.jsxs)("table",{className:"v3-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"Distribütör"}),(0,b.jsx)("th",{children:"Bölge"}),(0,b.jsx)("th",{className:"num",children:"Aktif Tem."}),(0,b.jsx)("th",{className:"num",children:"Ziyaret"}),(0,b.jsx)("th",{className:"num",children:"Kapsanan M."}),(0,b.jsx)("th",{className:"num",children:"Dönüşüm"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:a.rank}),(0,b.jsx)("td",{className:"unvan",title:a.distributor,children:a.distributor.length>40?a.distributor.slice(0,37)+"…":a.distributor}),(0,b.jsx)("td",{children:a.bolge||"—"}),(0,b.jsx)("td",{className:"num",children:a.aktifTemsilci.toLocaleString("tr-TR")}),(0,b.jsx)("td",{className:"num",children:(0,l.formatCompact)(a.ziyaret)}),(0,b.jsx)("td",{className:"num",children:a.kapsananMusteri.toLocaleString("tr-TR")}),(0,b.jsxs)("td",{className:"num",style:{color:a.donusumPct>=70?"var(--color-good, #16a34a)":a.donusumPct>=40?"var(--color-fg)":"var(--color-bad, #dc2626)"},children:["%",a.donusumPct.toFixed(0)]})]},a.distKod))})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .empty { padding: 24px; color: var(--color-muted); font-size: 13px; text-align: center; }
      `}})]})}let p=/^\d{4}-\d{2}-\d{2}$/;async function q({searchParams:a}){let j=(0,e.getTenantConfig)(),s=await a,t=s.from&&p.test(s.from)?s.from:null,u=s.to&&p.test(s.to)?s.to:null,v=t&&u?null:(s.donem??"").toLowerCase()||null,w=null,x=null;try{w=await (0,c.getWietnauerSaha)({dateFrom:t,dateTo:u,donem:v})}catch(a){x=a.message}return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(f.V3PageHeader,{eyebrow:"Dashboard 05",title:"Distribütör & Saha Operasyon",contentKey:"page.saha.title",descKey:"page.saha.desc",description:`${j.displayName} sahasının g\xfcnl\xfck ziyaret temposu, m\xfcşteri kapsama oranı, temsilci performansı ve sipariş d\xf6n\xfcş\xfcm verimliliği — operasyonel ekiplerin tek g\xf6r\xfcn\xfcm\xfc.`,dataNote:`TBLPMPZIYARETBASLIK + TBLPMPZIYARETOZET + TBLPMPZIYARETDETAY \xb7 TBLKULLANICI \xb7 TBLMUSTERIGRUPKIRILIM m\xfcşteri grup kırılımı \xb7 ${(0,h.donemLabel)(v,t,u)}`,generatedAt:w?.generatedAt}),(0,b.jsx)(g.GlobalDonemFilter,{}),x&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",x,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula."})]}),w&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)("div",{className:"v3-kpi-grid",children:[!(0,d.panelHidden)("kpi.saha.ziyaret")&&(0,b.jsx)(r,{label:(0,d.cs)("kpi.saha.ziyaret","Son 7g Ziyaret"),value:(0,l.formatCompact)(w.kpi.son7gZiyaret),sub:"toplam (rut içi + rut dışı)"}),!(0,d.panelHidden)("kpi.saha.unique")&&(0,b.jsx)(r,{label:(0,d.cs)("kpi.saha.unique","Unique Müşteri"),value:w.kpi.son7gUniqueMusteri.toLocaleString("tr-TR"),sub:"son 7g'de en az 1 ziyaret"}),!(0,d.panelHidden)("kpi.saha.aktiftemsilci")&&(0,b.jsx)(r,{label:(0,d.cs)("kpi.saha.aktiftemsilci","Aktif Temsilci"),value:w.kpi.son7gAktifTemsilci.toLocaleString("tr-TR"),sub:"son 7g'de en az 1 ziyaret yapan"}),!(0,d.panelHidden)("kpi.saha.donusum")&&(0,b.jsx)(r,{label:(0,d.cs)("kpi.saha.donusum","Dönüşüm Oranı"),value:`%${w.kpi.son7gDonusumPct.toFixed(1)}`,sub:"son 7g · sipariş / ziyaret",tone:w.kpi.son7gDonusumPct>=70?"good":w.kpi.son7gDonusumPct<40?"warn":"neutral"})]}),(0,b.jsxs)("div",{className:"v3-content-grid",children:[(0,b.jsxs)("div",{className:"col-main",children:[(0,b.jsx)(i,{rows:w.visitDaily,kpi:w.kpi}),(0,b.jsx)(m,{rows:w.reps}),(0,b.jsx)(o,{rows:w.distributors})]}),(0,b.jsxs)("div",{className:"col-side",children:[(0,b.jsx)(k,{coverage:w.coverage}),(0,b.jsx)(n,{rows:w.conversion})]})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .v3-kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .v3-content-grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
        @media (min-width: 1080px) { .v3-content-grid { grid-template-columns: 1.6fr 1fr; align-items: start; } }
        .col-main, .col-side { display: flex; flex-direction: column; gap: 16px; min-width: 0; }
        .v3-error { background: var(--color-bad-bg, rgba(220,38,38,0.05)); border: 1px solid var(--color-bad, #dc2626); border-radius: 8px; padding: 14px 16px; margin-bottom: 20px; font-size: 13px; color: var(--color-fg); }
        .v3-error-hint { margin-top: 4px; font-size: 12px; color: var(--color-muted); }
        /* Ortak v3-panel/v3-table iskeleti — saha alt panelleri buradan miras alır */
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .v3-table-wrap { overflow-x: auto; margin: 0 -4px; }
        .v3-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
        .v3-table thead th { text-align: left; padding: 8px 10px; font-size: 10.5px; font-weight: 600; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.04em; border-bottom: 1px solid var(--color-border); white-space: nowrap; }
        .v3-table thead th.num { text-align: right; }
        .v3-table tbody tr { border-bottom: 1px solid var(--color-border); }
        .v3-table tbody tr:hover { background: var(--color-surface-2, rgba(0,0,0,0.02)); }
        .v3-table td { padding: 9px 10px; color: var(--color-fg); vertical-align: middle; }
        .v3-table td.rank { font-weight: 600; color: var(--color-muted); font-variant-numeric: tabular-nums; width: 30px; }
        .v3-table td.unvan { font-weight: 500; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .v3-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
      `}})]})}function r({label:a,value:c,sub:d,tone:e}){return(0,b.jsxs)("div",{style:{background:"var(--color-surface)",border:"1px solid var(--color-border)",borderRadius:10,padding:"14px 16px",display:"flex",flexDirection:"column",gap:4},children:[(0,b.jsx)("div",{style:{fontSize:10.5,color:"var(--color-muted)",textTransform:"uppercase",letterSpacing:"0.05em",fontWeight:600},children:a}),(0,b.jsx)("div",{style:{fontSize:24,fontWeight:700,color:"warn"===e?"var(--color-bad, #dc2626)":"accent"===e?"var(--color-accent)":"good"===e?"var(--color-good, #16a34a)":"var(--color-fg)",letterSpacing:"-0.02em",fontVariantNumeric:"tabular-nums",lineHeight:1.1},children:c}),(0,b.jsx)("div",{style:{fontSize:11,color:"var(--color-muted-2)"},children:d})]})}a.s(["default",0,q,"metadata",0,{title:"Saha Operasyon · V3 · Insider"}],20602)},85381,a=>{a.n(a.i(20602))}];

//# sourceMappingURL=apps_dashboard_app_v3_saha-operasyon_page_tsx_14f4qfi._.js.map