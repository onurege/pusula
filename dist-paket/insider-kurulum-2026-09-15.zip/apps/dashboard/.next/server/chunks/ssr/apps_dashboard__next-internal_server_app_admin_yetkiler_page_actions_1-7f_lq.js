module.exports=[1891,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_admin_yetkiler_page_actions_1-7f_lq.js.map