module.exports=[33874,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1vk4__next-internal_server_app_v3_musteri-segmentasyon_page_actions_0ufvr3n.js.map