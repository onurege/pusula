module.exports=[94633,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_stok-tukenme_page_actions_16fel3p.js.map