module.exports=[31300,a=>{"use strict";var b=a.i(7997),c=a.i(17239),d=a.i(24580),e=a.i(1980),f=a.i(30590),g=a.i(1381),h=a.i(93105);function i({rows:a}){if((0,h.panelHidden)("panel.segment.musterigrubu"))return null;let c=Math.max(1,...a.map(a=>a.ciro)),d=a.reduce((a,b)=>a+b.musteriSayi,0);return(0,b.jsxs)("div",{className:"v3-panel seg-panel",children:[(0,b.jsxs)("div",{className:"seg-head",children:[(0,b.jsx)("div",{className:"seg-title",children:(0,h.panelTitle)("panel.segment.musterigrubu","Müşteri Grubu")}),(0,b.jsxs)("div",{className:"seg-sub",children:["Müşteri Grup Kırılımı (TBLMUSTERIGRUPKIRILIM) · ",a.length," kırılım · ",d.toLocaleString("tr-TR")," müşteri"]})]}),(0,b.jsxs)("div",{className:"seg-list",children:[0===a.length&&(0,b.jsx)("div",{className:"seg-empty",children:"Henüz veri yok"}),a.map(a=>(0,b.jsxs)("div",{className:"seg-row",children:[(0,b.jsx)("div",{className:"seg-row-label",title:a.ad,children:a.ad}),(0,b.jsxs)("div",{className:"seg-row-track",children:[(0,b.jsx)("div",{className:"seg-row-fill",style:{width:`${a.ciro/c*100}%`}}),(0,b.jsxs)("div",{className:"seg-row-meta",children:[(0,b.jsxs)("span",{className:"num",children:[a.musteriSayi.toLocaleString("tr-TR")," müşteri"]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"num",children:["₺",(0,g.formatCompact)(a.ciro)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"pay",children:["%",a.payPct.toFixed(1)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"disc",children:["isk. %",a.ortIskontoOraniPct.toFixed(1)]})]})]})]},a.kod))]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .seg-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; display: flex; flex-direction: column; gap: 12px; min-width: 0; }
        .seg-head { display: flex; flex-direction: column; gap: 2px; }
        .seg-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .seg-sub { font-size: 11.5px; color: var(--color-muted); }
        .seg-list { display: flex; flex-direction: column; gap: 10px; }
        .seg-row { display: grid; grid-template-columns: 130px 1fr; gap: 12px; align-items: center; }
        .seg-row-label { font-size: 12.5px; font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .seg-row-track { position: relative; height: 30px; background: var(--color-surface-2); border-radius: 5px; overflow: hidden; }
        .seg-row-fill { position: absolute; inset: 0 auto 0 0; background: var(--color-accent-soft, rgba(59, 130, 246, 0.18)); border-radius: 5px; transition: width 0.3s ease-out; }
        .seg-row-meta { position: relative; display: flex; align-items: center; gap: 6px; height: 100%; padding: 0 10px; font-size: 11.5px; color: var(--color-fg); font-variant-numeric: tabular-nums; }
        .seg-row-meta .sep { opacity: 0.35; }
        .seg-row-meta .pay { font-weight: 600; }
        .seg-row-meta .disc { color: var(--color-muted); }
        .seg-empty { font-size: 12px; color: var(--color-muted); padding: 12px 0; text-align: center; }
      `}})]})}function j({rows:a}){if((0,h.panelHidden)("panel.segment.eksaha"))return null;let c=Math.max(1,...a.map(a=>a.ciro)),d=a.reduce((a,b)=>a+b.musteriSayi,0);return(0,b.jsxs)("div",{className:"v3-panel seg-panel",children:[(0,b.jsxs)("div",{className:"seg-head",children:[(0,b.jsx)("div",{className:"seg-title",children:(0,h.panelTitle)("panel.segment.eksaha","Müşteri Tipi")}),(0,b.jsxs)("div",{className:"seg-sub",children:["Müşteri grubu (TBLMUSTERIGRUP) · ",a.length," tip · ",d.toLocaleString("tr-TR")," müşteri"]})]}),(0,b.jsxs)("div",{className:"seg-list",children:[0===a.length&&(0,b.jsx)("div",{className:"seg-empty",children:"Henüz veri yok"}),a.map(a=>(0,b.jsxs)("div",{className:"seg-row",children:[(0,b.jsx)("div",{className:"seg-row-label",title:a.ad,children:a.ad}),(0,b.jsxs)("div",{className:"seg-row-track",children:[(0,b.jsx)("div",{className:"seg-row-fill",style:{width:`${a.ciro/c*100}%`}}),(0,b.jsxs)("div",{className:"seg-row-meta",children:[(0,b.jsxs)("span",{className:"num",children:[a.musteriSayi.toLocaleString("tr-TR")," müşteri"]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"num",children:["₺",(0,g.formatCompact)(a.ciro)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"pay",children:["%",a.payPct.toFixed(1)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"disc",children:["isk. %",a.ortIskontoOraniPct.toFixed(1)]})]})]})]},a.kod))]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .seg-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; display: flex; flex-direction: column; gap: 12px; min-width: 0; }
        .seg-head { display: flex; flex-direction: column; gap: 2px; }
        .seg-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .seg-sub { font-size: 11.5px; color: var(--color-muted); }
        .seg-list { display: flex; flex-direction: column; gap: 10px; }
        .seg-row { display: grid; grid-template-columns: 130px 1fr; gap: 12px; align-items: center; }
        .seg-row-label { font-size: 12.5px; font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .seg-row-track { position: relative; height: 30px; background: var(--color-surface-2); border-radius: 5px; overflow: hidden; }
        .seg-row-fill { position: absolute; inset: 0 auto 0 0; background: var(--color-accent-soft, rgba(59, 130, 246, 0.18)); border-radius: 5px; transition: width 0.3s ease-out; }
        .seg-row-meta { position: relative; display: flex; align-items: center; gap: 6px; height: 100%; padding: 0 10px; font-size: 11.5px; color: var(--color-fg); font-variant-numeric: tabular-nums; }
        .seg-row-meta .sep { opacity: 0.35; }
        .seg-row-meta .pay { font-weight: 600; }
        .seg-row-meta .disc { color: var(--color-muted); }
        .seg-empty { font-size: 12px; color: var(--color-muted); padding: 12px 0; text-align: center; }
      `}})]})}function k({rows:a}){if((0,h.panelHidden)("panel.segment.ekgrup"))return null;let c=a.slice(0,12),d=Math.max(1,...c.map(a=>a.ciro));return(0,b.jsxs)("div",{className:"v3-panel seg-panel",children:[(0,b.jsxs)("div",{className:"seg-head",children:[(0,b.jsx)("div",{className:"seg-title",children:(0,h.panelTitle)("panel.segment.ekgrup","Müşteri Ek Grubu")}),(0,b.jsxs)("div",{className:"seg-sub",children:["Bayilik formatı · ",a.length," grup",a.length>12?` \xb7 top ${c.length} g\xf6sterimde`:""]})]}),(0,b.jsxs)("div",{className:"seg-list",children:[0===c.length&&(0,b.jsx)("div",{className:"seg-empty",children:"Henüz tanımlı ek grup yok"}),c.map(a=>{let c=a.aktifMusteriOraniPct>=50?"good":a.aktifMusteriOraniPct>=20?"neutral":"warn";return(0,b.jsxs)("div",{className:"seg-row",children:[(0,b.jsx)("div",{className:"seg-row-label",title:a.ad,children:a.ad}),(0,b.jsxs)("div",{className:"seg-row-track",children:[(0,b.jsx)("div",{className:"seg-row-fill",style:{width:`${a.ciro/d*100}%`}}),(0,b.jsxs)("div",{className:"seg-row-meta",children:[(0,b.jsx)("span",{className:"num",children:a.musteriSayi.toLocaleString("tr-TR")}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"num",children:["₺",(0,g.formatCompact)(a.ciro)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"pay",children:["%",a.payPct.toFixed(1)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:`active-pill ${c}`,children:["aktif %",a.aktifMusteriOraniPct.toFixed(0)]})]})]})]},a.kod)})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .seg-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; display: flex; flex-direction: column; gap: 12px; min-width: 0; }
        .seg-head { display: flex; flex-direction: column; gap: 2px; }
        .seg-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .seg-sub { font-size: 11.5px; color: var(--color-muted); }
        .seg-list { display: flex; flex-direction: column; gap: 10px; }
        .seg-row { display: grid; grid-template-columns: 130px 1fr; gap: 12px; align-items: center; }
        .seg-row-label { font-size: 12.5px; font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .seg-row-track { position: relative; height: 30px; background: var(--color-surface-2); border-radius: 5px; overflow: hidden; }
        .seg-row-fill { position: absolute; inset: 0 auto 0 0; background: var(--color-accent-soft, rgba(59, 130, 246, 0.18)); border-radius: 5px; transition: width 0.3s ease-out; }
        .seg-row-meta { position: relative; display: flex; align-items: center; gap: 6px; height: 100%; padding: 0 10px; font-size: 11.5px; color: var(--color-fg); font-variant-numeric: tabular-nums; flex-wrap: wrap; }
        .seg-row-meta .sep { opacity: 0.35; }
        .seg-row-meta .pay { font-weight: 600; }
        .active-pill { padding: 1px 7px; border-radius: 9px; font-size: 10.5px; font-weight: 600; letter-spacing: 0.01em; }
        .active-pill.good { background: rgba(22, 163, 74, 0.12); color: #16a34a; }
        .active-pill.neutral { background: var(--color-surface); color: var(--color-muted); border: 1px solid var(--color-border); }
        .active-pill.warn { background: rgba(220, 38, 38, 0.10); color: #dc2626; }
        .seg-empty { font-size: 12px; color: var(--color-muted); padding: 12px 0; text-align: center; }
      `}})]})}var l=a.i(717);function m({data:a}){if((0,h.panelHidden)("panel.segment.cross"))return null;let{tipler:c,markalar:d,cells:e}=a,f=c.length>0&&d.length>0,i=new Map;for(let a of e)i.set(`${a.tipAd}|${a.marka}`,a);let j=new Set(e.filter(a=>a.isStratejik).map(a=>a.marka));return(0,b.jsxs)("div",{className:"v3-panel cross-panel",children:[(0,b.jsxs)("div",{className:"cross-head",children:[(0,b.jsx)("div",{className:"cross-title",children:(0,h.panelTitle)("panel.segment.cross","Müşteri Tipi × Marka")}),(0,b.jsxs)("div",{className:"cross-sub",children:["Son 30g ciro payı (%) · ",c.length,"×",d.length," grid · stratejik markalar"," ",(0,b.jsx)("span",{className:"strat-dot"})," noktalı"]})]}),f?(0,b.jsxs)("div",{className:"x-grid",style:{gridTemplateColumns:`minmax(120px, 1.2fr) repeat(${d.length}, minmax(56px, 1fr)) minmax(72px, 0.9fr)`},children:[(0,b.jsx)("div",{className:"x-head",children:"Müşteri Tipi"}),d.map(a=>(0,b.jsxs)("div",{className:"x-head",title:a,children:[j.has(a)&&(0,b.jsx)("span",{className:"strat-dot"}),a.length>12?`${a.slice(0,11)}…`:a]},a)),(0,b.jsx)("div",{className:"x-head right",children:"Tip Ort."}),c.map(a=>{let c,e=0===(c=d.map(b=>i.get(`${a}|${b}`)?.payPct??0).filter(a=>a>0)).length?null:c.reduce((a,b)=>a+b,0)/c.length;return(0,b.jsxs)(l.Fragment,{children:[(0,b.jsx)("div",{className:"x-region",title:a,children:a}),d.map(c=>{let d=i.get(`${a}|${c}`),e=d?.payPct??0,f=d?.ciro??0,h=e<=0?"empty":e<1?"flat":e<3?"warm":e<7?"hot":"fire";return(0,b.jsx)("div",{className:`x-cell ${h}`,title:`${a} \xd7 ${c}
Ciro: ₺${(0,g.formatCompact)(f)}
Pay: %${e.toFixed(2)}`,children:e>.3?`%${e.toFixed(1)}`:""},c)}),(0,b.jsx)("div",{className:"x-avg",children:null==e?"—":`%${e.toFixed(1)}`})]},a)})]}):(0,b.jsx)("div",{className:"cross-empty",children:"Cross-segment verisi alınamadı."}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .cross-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; display: flex; flex-direction: column; gap: 14px; min-width: 0; }
        .cross-head { display: flex; flex-direction: column; gap: 2px; }
        .cross-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .cross-sub { font-size: 11.5px; color: var(--color-muted); display: inline-flex; align-items: center; gap: 4px; flex-wrap: wrap; }
        .strat-dot { display: inline-block; width: 7px; height: 7px; background: var(--color-accent); border-radius: 50%; flex-shrink: 0; }
        .cross-empty { font-size: 12px; color: var(--color-muted); padding: 18px 0; text-align: center; }

        .x-grid { display: grid; gap: 4px; font-size: 11px; min-width: 720px; }
        .x-grid .x-head {
          display: flex; align-items: center; justify-content: center;
          gap: 4px;
          text-align: center; padding: 6px 4px;
          font-size: 10px; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.4px; font-weight: 600;
          border-bottom: 1px solid var(--color-border);
          min-height: 32px;
        }
        .x-grid .x-head.right { justify-content: flex-end; padding-right: 8px; }

        .x-grid .x-region {
          display: flex; align-items: center;
          padding: 6px 10px; min-height: 44px;
          color: var(--color-fg); font-weight: 600; font-size: 11.5px;
          border-bottom: 1px solid var(--color-border);
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .x-grid .x-cell {
          display: flex; align-items: center; justify-content: center;
          padding: 6px 4px; min-height: 44px;
          text-align: center; font-feature-settings: "tnum";
          font-variant-numeric: tabular-nums;
          font-weight: 600;
          border-bottom: 1px solid var(--color-border);
          border-radius: 4px;
        }
        /* Pay yoğunluğu paletindeki 4 ton — komuta'daki kırmızı/yeşil bipolar
           yerine, tek y\xf6nl\xfc mavi (accent) intensity gradient. */
        .x-grid .x-cell.empty { background: var(--color-surface-2, #f5f5f4); color: var(--color-muted-2, #a8a29e); }
        .x-grid .x-cell.flat  { background: rgba(99, 102, 241, 0.08); color: var(--color-fg); }
        .x-grid .x-cell.warm  { background: rgba(99, 102, 241, 0.20); color: #312e81; }
        .x-grid .x-cell.hot   { background: rgba(99, 102, 241, 0.42); color: #ffffff; }
        .x-grid .x-cell.fire  { background: rgba(79, 70, 229, 0.72); color: #ffffff; }

        .x-grid .x-avg {
          display: flex; align-items: center; justify-content: center;
          padding: 6px 4px; min-height: 44px;
          text-align: center; font-feature-settings: "tnum";
          font-variant-numeric: tabular-nums;
          color: var(--color-accent, #6366f1); font-weight: 700; font-size: 11.5px;
          border-bottom: 1px solid var(--color-border);
          border-radius: 4px;
          background: var(--color-surface-2, #fafaf9);
        }

        /* Dark mode override — komuta paletiyle hizalı */
        :root[data-theme="dark"] .x-grid .x-cell.empty { background: rgba(255,255,255,0.04); color: var(--color-muted-2, #71717a); }
        :root[data-theme="dark"] .x-grid .x-cell.flat  { background: rgba(129, 140, 248, 0.12); }
        :root[data-theme="dark"] .x-grid .x-cell.warm  { background: rgba(129, 140, 248, 0.25); color: #e0e7ff; }
        :root[data-theme="dark"] .x-grid .x-cell.hot   { background: rgba(99, 102, 241, 0.55); color: #ffffff; }
        :root[data-theme="dark"] .x-grid .x-cell.fire  { background: rgba(67, 56, 202, 0.85); color: #ffffff; }
        :root[data-theme="dark"] .x-grid .x-avg { background: rgba(255,255,255,0.03); }
      `}})]})}function n({ekGrup:a,musteri:c}){if((0,h.panelHidden)("panel.segment.iskonto"))return null;let d=a.slice(0,12),e=Math.max(1,...d.map(a=>a.iskontoTutari));return(0,b.jsxs)("div",{className:"v3-panel iskonto-break-panel",children:[(0,b.jsxs)("div",{className:"seg-head",children:[(0,b.jsx)("div",{className:"seg-title",children:(0,h.panelTitle)("panel.segment.iskonto","İskonto Kırılımı — Ek Grup / Nokta")}),(0,b.jsxs)("div",{className:"seg-sub",children:["Son 30g DBLISKONTOTUTARI toplamı · Ek Grup (",a.length,") ve nokta (müşteri, top"," ",c.length,") bazında"]})]}),(0,b.jsxs)("div",{className:"iskonto-break-grid",children:[(0,b.jsxs)("div",{className:"iskonto-break-col",children:[(0,b.jsx)("div",{className:"iskonto-break-col-title",children:"Ek Grup bazında"}),0===d.length&&(0,b.jsx)("div",{className:"seg-empty",children:"Henüz veri yok"}),(0,b.jsx)("div",{className:"seg-list",children:d.map(a=>(0,b.jsxs)("div",{className:"seg-row",children:[(0,b.jsx)("div",{className:"seg-row-label",title:a.ad,children:a.ad}),(0,b.jsxs)("div",{className:"seg-row-track",children:[(0,b.jsx)("div",{className:"seg-row-fill iskonto-fill",style:{width:`${a.iskontoTutari/e*100}%`}}),(0,b.jsxs)("div",{className:"seg-row-meta",children:[(0,b.jsxs)("span",{className:"num",children:["₺",(0,g.formatCompact)(a.iskontoTutari)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"pay",children:["%",a.payPct.toFixed(1)]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsxs)("span",{className:"disc",children:["isk. oranı %",a.iskontoOraniPct.toFixed(1)]})]})]})]},a.kod))})]}),(0,b.jsxs)("div",{className:"iskonto-break-col",children:[(0,b.jsxs)("div",{className:"iskonto-break-col-title",children:["Nokta (müşteri) bazında — Top ",c.length]}),0===c.length?(0,b.jsx)("div",{className:"seg-empty",children:"Henüz veri yok"}):(0,b.jsx)("div",{className:"iskonto-table-wrap",children:(0,b.jsxs)("table",{className:"iskonto-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{className:"rank",children:"#"}),(0,b.jsx)("th",{children:"Müşteri"}),(0,b.jsx)("th",{children:"Ek Grup"}),(0,b.jsx)("th",{className:"num-col",children:"İskonto"}),(0,b.jsx)("th",{className:"num-col",children:"Oran"})]})}),(0,b.jsx)("tbody",{children:c.map(a=>(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:a.rank}),(0,b.jsx)("td",{className:"unvan",title:a.unvan,children:a.unvan||`M\xfcşteri #${a.musteriKod}`}),(0,b.jsx)("td",{className:"ekgrup",title:a.ekGrupAd??void 0,children:a.ekGrupAd??"(Tanımsız)"}),(0,b.jsxs)("td",{className:"num-col",children:["₺",(0,g.formatCompact)(a.iskontoTutari)]}),(0,b.jsxs)("td",{className:"num-col",children:["%",a.iskontoOraniPct.toFixed(1)]})]},a.musteriKod))})]})})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .iskonto-break-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; display: flex; flex-direction: column; gap: 14px; min-width: 0; }
        .seg-head { display: flex; flex-direction: column; gap: 2px; }
        .seg-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .seg-sub { font-size: 11.5px; color: var(--color-muted); }

        .iskonto-break-grid { display: grid; grid-template-columns: 1fr; gap: 20px; }
        @media (min-width: 900px) {
          .iskonto-break-grid { grid-template-columns: 1fr 1.3fr; align-items: start; }
        }
        .iskonto-break-col { display: flex; flex-direction: column; gap: 10px; min-width: 0; }
        .iskonto-break-col-title { font-size: 11px; font-weight: 600; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.4px; }

        .seg-list { display: flex; flex-direction: column; gap: 10px; }
        .seg-row { display: grid; grid-template-columns: 120px 1fr; gap: 12px; align-items: center; }
        .seg-row-label { font-size: 12.5px; font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .seg-row-track { position: relative; height: 30px; background: var(--color-surface-2); border-radius: 5px; overflow: hidden; }
        .seg-row-fill { position: absolute; inset: 0 auto 0 0; background: var(--color-accent-soft, rgba(59, 130, 246, 0.18)); border-radius: 5px; transition: width 0.3s ease-out; }
        .seg-row-fill.iskonto-fill { background: rgba(220, 38, 38, 0.14); }
        .seg-row-meta { position: relative; display: flex; align-items: center; gap: 6px; height: 100%; padding: 0 10px; font-size: 11.5px; color: var(--color-fg); font-variant-numeric: tabular-nums; flex-wrap: wrap; }
        .seg-row-meta .sep { opacity: 0.35; }
        .seg-row-meta .pay { font-weight: 600; }
        .seg-row-meta .disc { color: var(--color-muted); }
        .seg-empty { font-size: 12px; color: var(--color-muted); padding: 12px 0; text-align: center; }

        .iskonto-table-wrap { overflow-x: auto; }
        .iskonto-table { width: 100%; border-collapse: collapse; font-size: 11.5px; font-variant-numeric: tabular-nums; }
        .iskonto-table th { text-align: left; padding: 6px 8px; font-size: 10px; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.3px; font-weight: 600; border-bottom: 1px solid var(--color-border); white-space: nowrap; }
        .iskonto-table td { padding: 6px 8px; border-bottom: 1px solid var(--color-border); color: var(--color-fg); }
        .iskonto-table tbody tr:last-child td { border-bottom: none; }
        .iskonto-table th.rank, .iskonto-table td.rank { width: 24px; color: var(--color-muted); }
        .iskonto-table th.num-col, .iskonto-table td.num-col { text-align: right; white-space: nowrap; }
        .iskonto-table td.unvan { max-width: 220px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 500; }
        .iskonto-table td.ekgrup { max-width: 120px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--color-muted); }
      `}})]})}let o=/^\d{4}-\d{2}-\d{2}$/;async function p({searchParams:a}){let g=await a,h=g.from&&o.test(g.from)?g.from:null,l=g.to&&o.test(g.to)?g.to:null,q=h&&l?null:(g.donem??"").toLowerCase()||null,r=null,s=null;try{r=await (0,c.getWietnauerSegment)({dateFrom:h,dateTo:l,donem:q})}catch(a){s=a.message}let t=(0,f.donemLabel)(q,h,l),u=r?.musteriGrubu.length??0,v=r?.ekGrup.length??0,w=r?r.musteriGrubu.reduce((a,b)=>a+b.musteriSayi,0):0,x=r?`M\xfcşteri Grubu = M\xfcşteri Grup Kırılımı (${u} kırılım, ${w.toLocaleString("tr-TR")} m\xfcşteri, Prestige/Premium/Standart…); M\xfcşteri Tipi = m\xfcşteri grubu (TBLMUSTERIGRUP: OFF/ON TRADE/Turizm…); Ek Grubu (bayilik formatı, ${v} grup) — \xfc\xe7 ayrı boyut ${t} ciro \xfczerinden yan yana. Altta Tip \xd7 Marka heatmap'i ve Ek Grup / nokta bazında iskonto kırılımı.`:`M\xfcşteri Grubu (kırılım), M\xfcşteri Tipi (m\xfcşteri grubu) ve Ek Grubu (bayilik formatı) — \xfc\xe7 bağımsız boyut ${t} ciro \xfczerinden yan yana. Altta Tip \xd7 Marka heatmap'i ve Ek Grup / nokta bazında iskonto kırılımı.`;return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(d.V3PageHeader,{eyebrow:"Dashboard 03",title:"Müşteri Segmentasyon",contentKey:"page.segment.title",descKey:"page.segment.desc",description:x,dataNote:"TBLMUSTERIGRUPKIRILIM · TBLMUSTERIEKGRUP · TBLMUSTERIGRUP (Tip×Marka) · TBLURUNGRUP · TBLMSDFATURA.DBLISKONTOTUTARI",generatedAt:r?.generatedAt}),(0,b.jsx)(e.GlobalDonemFilter,{}),s&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",s,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula."})]}),r&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)("div",{className:"seg-triple-grid",children:[(0,b.jsx)(i,{rows:r.musteriGrubu}),(0,b.jsx)(k,{rows:r.ekGrup}),(0,b.jsx)(j,{rows:r.ekSaha})]}),(0,b.jsx)("div",{className:"seg-cross-wrap",children:(0,b.jsx)(m,{data:r.cross})}),(0,b.jsx)("div",{className:"seg-cross-wrap",children:(0,b.jsx)(n,{ekGrup:r.ekGrupIskonto,musteri:r.musteriIskonto})})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .seg-triple-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
          margin-bottom: 16px;
        }
        @media (min-width: 1080px) {
          .seg-triple-grid {
            grid-template-columns: repeat(3, 1fr);
            align-items: start;
          }
        }
        .seg-cross-wrap {
          display: block;
          margin-bottom: 16px;
        }
        .v3-error {
          background: var(--color-bad-bg, rgba(220, 38, 38, 0.05));
          border: 1px solid var(--color-bad, #dc2626);
          border-radius: 8px;
          padding: 14px 16px;
          margin-bottom: 20px;
          font-size: 13px;
          color: var(--color-fg);
        }
        .v3-error-hint {
          margin-top: 4px;
          font-size: 12px;
          color: var(--color-muted);
        }
      `}})]})}a.s(["default",0,p,"metadata",0,{title:"Müşteri Segmentasyon · V3 · Insider"}],31300)},63425,a=>{a.n(a.i(31300))}];

//# sourceMappingURL=apps_dashboard_app_v3_musteri-segmentasyon_page_tsx_05gdz4f._.js.map