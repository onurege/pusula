module.exports=[82100,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_setup_page_actions_18x2a6c.js.map