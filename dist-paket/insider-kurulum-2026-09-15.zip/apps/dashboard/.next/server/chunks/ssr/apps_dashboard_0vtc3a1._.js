module.exports=[41941,a=>{"use strict";a.s(["IskontoFilterBar",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call IskontoFilterBar() from the server but IskontoFilterBar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/iskonto/IskontoFilterBar.tsx <module evaluation>","IskontoFilterBar")},68229,a=>{"use strict";a.s(["IskontoFilterBar",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call IskontoFilterBar() from the server but IskontoFilterBar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/iskonto/IskontoFilterBar.tsx","IskontoFilterBar")},56731,a=>{"use strict";a.i(41941);var b=a.i(68229);a.n(b)},84065,a=>{"use strict";var b=a.i(7997),c=a.i(17239);a.i(2614);var d=a.i(12261),e=a.i(24580),f=a.i(56731),g=a.i(1980),h=a.i(1381);function i({brut:a,iskonto:c,net:d,iskontoOraniPct:e,faturaCount:f,aktifMusteriCount:g}){let k=e<15?{color:"#16a34a",label:"sağlıklı"}:e<25?{color:"#d97706",label:"nötr"}:{color:"#dc2626",label:"yatırım uyarısı"};return(0,b.jsxs)("div",{className:"hero-panel",children:[(0,b.jsxs)("div",{className:"hero-row",children:[(0,b.jsx)(j,{label:"Brüt Ciro",value:`₺${(0,h.formatCompact)(a)}`,sub:`${f.toLocaleString("tr-TR")} fatura`}),(0,b.jsx)(j,{label:"İskonto Toplamı",value:`₺${(0,h.formatCompact)(c)}`,sub:`${g.toLocaleString("tr-TR")} aktif m\xfcşteri`,accent:"muted"}),(0,b.jsx)(j,{label:"Net Ciro",value:`₺${(0,h.formatCompact)(d)}`,sub:"brüt − iskonto",accent:"solid"}),(0,b.jsx)(j,{label:"İskonto / Ciro",value:`%${e.toFixed(1)}`,sub:k.label,color:k.color})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .hero-panel {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 12px;
          padding: 22px 24px;
        }
        .hero-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 24px;
        }
        .hero-tile { display: flex; flex-direction: column; gap: 6px; }
        .hero-tile .label {
          font-size: 11px;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.06em;
          font-weight: 600;
        }
        .hero-tile .value {
          font-size: 36px;
          font-weight: 700;
          letter-spacing: -0.03em;
          font-variant-numeric: tabular-nums;
          line-height: 1.05;
          color: var(--color-fg);
        }
        .hero-tile .value.muted { color: var(--color-muted); }
        .hero-tile .value.solid { color: var(--color-fg); }
        .hero-tile .sub {
          font-size: 11.5px;
          color: var(--color-muted-2);
        }
      `}})]})}function j({label:a,value:c,sub:d,color:e,accent:f}){return(0,b.jsxs)("div",{className:"hero-tile",children:[(0,b.jsx)("div",{className:"label",children:a}),(0,b.jsx)("div",{className:`value${"muted"===f?" muted":""}${"solid"===f?" solid":""}`,style:e?{color:e}:void 0,children:c}),(0,b.jsx)("div",{className:"sub",children:d})]})}var k=a.i(93105);function l({points:a}){if((0,k.panelHidden)("panel.iskonto.monthly"))return null;if(0===a.length)return(0,b.jsx)("div",{className:"trend-panel",children:(0,b.jsxs)("div",{className:"trend-head",children:[(0,b.jsx)("div",{className:"trend-title",children:(0,k.panelTitle)("panel.iskonto.monthly","Aylık İskonto Trendi")}),(0,b.jsx)("div",{className:"trend-sub",children:"Veri yok"})]})});let c=Math.max(1,...a.map(a=>a.iskonto)),d=Math.max(30,5*Math.ceil(Math.max(1,...a.map(a=>a.iskontoOraniPct))/5)),e=614/a.length,f=Math.max(8,.55*e),g=a.map((a,b)=>[56+b*e+e/2,204-a.iskontoOraniPct/d*184]),i=g.map(([a,b],c)=>`${0===c?"M":"L"}${a.toFixed(1)},${b.toFixed(1)}`).join(" "),j=[0,.25,.5,.75,1].map(a=>({y:204-184*a,label:(0,h.formatCompact)(c*a)})),m=[0,.25,.5,.75,1].map(a=>({y:204-184*a,label:`%${(d*a).toFixed(0)}`}));return(0,b.jsxs)("div",{className:"trend-panel",children:[(0,b.jsxs)("div",{className:"trend-head",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"trend-title",children:(0,k.panelTitle)("panel.iskonto.monthly","Aylık İskonto Trendi")}),(0,b.jsx)("div",{className:"trend-sub",children:"Son 12 ay · İskonto tutarı (bar) ve iskonto/ciro oranı (çizgi)"})]}),(0,b.jsxs)("div",{className:"trend-legend",children:[(0,b.jsx)("span",{className:"lg-bar"})," iskonto tutarı",(0,b.jsx)("span",{className:"lg-line"})," oran %"]})]}),(0,b.jsx)("div",{className:"trend-svg-wrap",children:(0,b.jsxs)("svg",{viewBox:"0 0 720 240",preserveAspectRatio:"xMidYMid meet",role:"img",children:[j.map((a,c)=>(0,b.jsx)("line",{x1:56,x2:670,y1:a.y,y2:a.y,stroke:"var(--color-border)",strokeDasharray:"2 3",opacity:0===c?.8:.4},`grid-${c}`)),j.map((a,c)=>(0,b.jsxs)("text",{x:48,y:a.y+4,textAnchor:"end",fontSize:"10",fill:"var(--color-muted-2)",style:{fontVariantNumeric:"tabular-nums"},children:["₺",a.label]},`lt-${c}`)),m.map((a,c)=>(0,b.jsx)("text",{x:678,y:a.y+4,textAnchor:"start",fontSize:"10",fill:"var(--color-muted-2)",style:{fontVariantNumeric:"tabular-nums"},children:a.label},`rt-${c}`)),a.map((a,d)=>{let g=56+d*e+e/2,h=a.iskonto/c*184;return(0,b.jsxs)("g",{children:[(0,b.jsx)("rect",{x:g-f/2,y:204-h,width:f,height:Math.max(1,h),fill:"var(--color-muted-2)",opacity:"0.55",rx:"2"}),(0,b.jsx)("text",{x:g,y:220,textAnchor:"middle",fontSize:"10",fill:"var(--color-muted-2)",children:a.ay})]},a.yyyymm)}),(0,b.jsx)("path",{d:i,fill:"none",stroke:"var(--color-accent)",strokeWidth:"2",strokeLinejoin:"round",strokeLinecap:"round"}),g.map(([c,d],e)=>{let f;return(0,b.jsx)("circle",{cx:c,cy:d,r:"3.5",fill:(f=a[e]?.iskontoOraniPct??0)<15?"#16a34a":f<25?"#d97706":"#dc2626",stroke:"var(--color-surface)",strokeWidth:"1.5"},`pt-${e}`)})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .trend-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .trend-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 12px; }
        .trend-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .trend-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .trend-legend { font-size: 11px; color: var(--color-muted); display: inline-flex; align-items: center; gap: 8px; }
        .trend-legend .lg-bar { display: inline-block; width: 12px; height: 8px; background: var(--color-muted-2); opacity: 0.55; border-radius: 2px; margin-left: 4px; }
        .trend-legend .lg-line { display: inline-block; width: 14px; height: 2px; background: var(--color-accent); margin-left: 8px; vertical-align: middle; }
        .trend-svg-wrap { width: 100%; overflow-x: auto; }
        .trend-svg-wrap svg { width: 100%; min-width: 480px; height: auto; }
      `}})]})}function m({brands:a}){if((0,k.panelHidden)("panel.iskonto.brand"))return null;let c=a.filter(a=>a.isStratejik);return(0,b.jsxs)("div",{className:"brand-panel",children:[(0,b.jsx)("div",{className:"brand-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"brand-title",children:(0,k.panelTitle)("panel.iskonto.brand","Marka × İskonto Etkinliği")}),(0,b.jsxs)("div",{className:"brand-sub",children:["Son 30g · Top 15 marka · Detay seviyesi (brüt = birim × miktar)",c.length>0&&(0,b.jsxs)(b.Fragment,{children:[" · ",(0,b.jsx)("span",{className:"strat-dot"})," ",c.length," stratejik"]})]})]})}),(0,b.jsx)("div",{className:"brand-table-wrap",children:(0,b.jsxs)("table",{className:"brand-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"Marka"}),(0,b.jsx)("th",{className:"num",children:"Brüt"}),(0,b.jsx)("th",{className:"num",children:"İskonto"}),(0,b.jsx)("th",{className:"num",children:"Net"}),(0,b.jsx)("th",{className:"num",children:"Oran"}),(0,b.jsx)("th",{className:"num",children:"YoY Net"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>{let c=a.iskontoOraniPct<15?"#16a34a":a.iskontoOraniPct<25?"#d97706":"#dc2626",d=null==a.yoyNetPct?"var(--color-muted-2)":a.yoyNetPct>=0?"#16a34a":"#dc2626";return(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:a.rank}),(0,b.jsxs)("td",{className:"marka",children:[a.isStratejik&&(0,b.jsx)("span",{className:"strat-dot"}),(0,b.jsx)("span",{title:a.marka,children:a.marka})]}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,h.formatCompact)(a.brut)]}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,h.formatCompact)(a.iskonto)]}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,h.formatCompact)(a.net)]}),(0,b.jsxs)("td",{className:"num oran",style:{color:c},children:["%",a.iskontoOraniPct.toFixed(1)]}),(0,b.jsx)("td",{className:"num yoy",style:{color:d},children:null==a.yoyNetPct?"—":`${a.yoyNetPct>=0?"+":""}${a.yoyNetPct.toFixed(1)}%`})]},a.markaKod)})})]})}),(0,b.jsxs)("div",{className:"brand-legend",children:[(0,b.jsx)("span",{style:{color:"#16a34a"},children:"● sağlıklı <15%"}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsx)("span",{style:{color:"#d97706"},children:"● nötr 15–25%"}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsx)("span",{style:{color:"#dc2626"},children:"● uyarı >25%"})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .brand-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .brand-head { margin-bottom: 12px; }
        .brand-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .brand-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .strat-dot { display: inline-block; width: 8px; height: 8px; background: var(--color-accent); border-radius: 50%; margin-right: 6px; vertical-align: middle; }
        .brand-table-wrap { overflow-x: auto; margin: 0 -4px; }
        .brand-table { width: 100%; border-collapse: collapse; font-size: 12.5px; min-width: 680px; }
        .brand-table thead th {
          text-align: left;
          padding: 8px 10px;
          font-size: 10.5px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
          border-bottom: 1px solid var(--color-border);
        }
        .brand-table thead th.num { text-align: right; }
        .brand-table tbody tr { border-bottom: 1px solid var(--color-border); }
        .brand-table tbody tr:hover { background: var(--color-surface-2); }
        .brand-table td { padding: 9px 10px; color: var(--color-fg); }
        .brand-table td.rank { font-weight: 600; color: var(--color-muted); font-variant-numeric: tabular-nums; }
        .brand-table td.marka { font-weight: 500; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .brand-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
        .brand-table td.oran, .brand-table td.yoy { font-weight: 600; }
        .brand-legend { margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--color-border); font-size: 11px; color: var(--color-muted-2); display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .brand-legend .sep { opacity: 0.4; }
      `}})]})}let n={premium:{label:"premium",color:"#16a34a"},saglikli:{label:"sağlıklı",color:"#d97706"},bagimli:{label:"iskonto bağımlı",color:"#dc2626"}};function o({customers:a}){if((0,k.panelHidden)("panel.iskonto.customer"))return null;let c=a.filter(a=>"premium"===a.etiket).length,d=a.filter(a=>"bagimli"===a.etiket).length,e=a.reduce((a,b)=>a+b.iskonto,0);return(0,b.jsxs)("div",{className:"cust-panel",children:[(0,b.jsx)("div",{className:"cust-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"cust-title",children:(0,k.panelTitle)("panel.iskonto.customer","Müşteri ROI · Top 20")}),(0,b.jsxs)("div",{className:"cust-sub",children:["Son 30g · İskonto tutarı DESC · Toplam ₺",(0,h.formatCompact)(e)," iskonto yatırımı",c>0&&(0,b.jsxs)(b.Fragment,{children:[" · ",(0,b.jsxs)("span",{style:{color:"#16a34a",fontWeight:600},children:[c," premium"]})]}),d>0&&(0,b.jsxs)(b.Fragment,{children:[" · ",(0,b.jsxs)("span",{style:{color:"#dc2626",fontWeight:600},children:[d," bağımlı"]})]})]})]})}),(0,b.jsx)("div",{className:"cust-table-wrap",children:(0,b.jsxs)("table",{className:"cust-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"Müşteri"}),(0,b.jsx)("th",{children:"Şehir"}),(0,b.jsx)("th",{className:"num",children:"Brüt"}),(0,b.jsx)("th",{className:"num",children:"İskonto"}),(0,b.jsx)("th",{className:"num",children:"Net"}),(0,b.jsx)("th",{className:"num",children:"Oran"}),(0,b.jsx)("th",{children:"Etiket"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>{let c=n[a.etiket];return(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:a.rank}),(0,b.jsx)("td",{className:"unvan",title:a.unvan,children:a.unvan.length>46?a.unvan.slice(0,43)+"…":a.unvan}),(0,b.jsx)("td",{className:"sehir",children:a.sehir||"—"}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,h.formatCompact)(a.brut)]}),(0,b.jsxs)("td",{className:"num iskonto",children:["₺",(0,h.formatCompact)(a.iskonto)]}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,h.formatCompact)(a.net)]}),(0,b.jsxs)("td",{className:"num oran",style:{color:c.color},children:["%",a.iskontoOraniPct.toFixed(1)]}),(0,b.jsx)("td",{className:"etiket",children:(0,b.jsx)("span",{className:"pill",style:{color:c.color,borderColor:c.color},children:c.label})})]},a.id)})})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .cust-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .cust-head { margin-bottom: 12px; }
        .cust-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .cust-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .cust-table-wrap { overflow-x: auto; margin: 0 -4px; }
        .cust-table { width: 100%; border-collapse: collapse; font-size: 12.5px; min-width: 820px; }
        .cust-table thead th {
          text-align: left;
          padding: 8px 10px;
          font-size: 10.5px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
          border-bottom: 1px solid var(--color-border);
        }
        .cust-table thead th.num { text-align: right; }
        .cust-table tbody tr { border-bottom: 1px solid var(--color-border); }
        .cust-table tbody tr:hover { background: var(--color-surface-2); }
        .cust-table td { padding: 9px 10px; color: var(--color-fg); }
        .cust-table td.rank { font-weight: 600; color: var(--color-muted); font-variant-numeric: tabular-nums; }
        .cust-table td.unvan { font-weight: 500; max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .cust-table td.sehir { color: var(--color-muted); }
        .cust-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
        .cust-table td.iskonto { color: var(--color-fg-2); font-weight: 500; }
        .cust-table td.oran { font-weight: 600; }
        .pill { display: inline-block; padding: 2px 8px; font-size: 10.5px; font-weight: 600; border: 1px solid; border-radius: 999px; text-transform: lowercase; letter-spacing: 0.02em; }
      `}})]})}var p=a.i(40795);let q=/^\d{4}-\d{2}-\d{2}$/;function r(a){let b=(a??"").trim();return q.test(b)?b:null}async function s({searchParams:a}){let h=(0,d.getTenantConfig)(),j=await a,k=null!=j.distId?Number(j.distId):null,n=null!=k&&Number.isFinite(k)?k:null,q=r(j.from),t=r(j.to),u=q&&t?q:null,v=q&&t?t:null,w=u&&v?null:(j.donem??"").toLowerCase()||null,x=null,y=null;try{x=await (0,c.getWietnauerIskonto)({distId:n,dateFrom:u,dateTo:v,donem:w})}catch(a){y=a.message}let z=[];try{z=await (0,c.getAllowedDistributors)()}catch{z=[]}let A=u&&v?`${u} → ${v}`:null;return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(e.V3PageHeader,{eyebrow:"Dashboard 07",title:"Ticari Yatırım & İskonto",contentKey:"page.iskonto.title",descKey:"page.iskonto.desc",description:A?`${h.displayName} i\xe7in ${A} aralığında iskonto yatırımı: br\xfct → iskonto → net akışı, marka & m\xfcşteri & segment ROI'leri.`:`${h.displayName} i\xe7in iskonto yatırımı u\xe7tan uca: br\xfct → iskonto → net akışı, 12 aylık trend, marka & m\xfcşteri & segment ROI'leri. Sağlıklı iskonto = k\xfc\xe7\xfck yatırım, b\xfcy\xfck b\xfcy\xfcme.`,dataNote:"TBLMSDFATURA · DBLISKONTOTUTARI + TBLMSDBELGEDETAY · BYTTUR=0 · BYTDURUM=0",generatedAt:x?.generatedAt}),(0,b.jsx)(g.GlobalDonemFilter,{}),(0,b.jsx)(f.IskontoFilterBar,{distributors:z,selectedDistId:n,dateFrom:u,dateTo:v,showDateRange:!1}),y&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",y,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula."})]}),x&&(0,b.jsxs)("div",{className:"iskonto-stack",children:[(0,b.jsx)(i,{brut:x.overall.brut,iskonto:x.overall.iskonto,net:x.overall.net,iskontoOraniPct:x.overall.iskontoOraniPct,faturaCount:x.overall.faturaCount,aktifMusteriCount:x.overall.aktifMusteriCount}),(0,b.jsx)(l,{points:x.monthly}),(0,b.jsxs)("div",{className:"iskonto-twocol",children:[(0,b.jsx)(m,{brands:x.brands}),(0,b.jsx)(p.IskontoSegmentPanel,{segments:x.segments})]}),(0,b.jsx)(o,{customers:x.topCustomers})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .iskonto-stack { display: flex; flex-direction: column; gap: 16px; }
        .iskonto-twocol {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
        }
        @media (min-width: 1180px) {
          .iskonto-twocol {
            grid-template-columns: 3fr 2fr;
            align-items: start;
          }
        }
        .v3-error {
          background: var(--color-bad-bg, rgba(220, 38, 38, 0.05));
          border: 1px solid var(--color-bad, #dc2626);
          border-radius: 8px;
          padding: 14px 16px;
          margin-bottom: 20px;
          font-size: 13px;
          color: var(--color-fg);
        }
        .v3-error-hint {
          margin-top: 4px;
          font-size: 12px;
          color: var(--color-muted);
        }
      `}})]})}a.s(["default",0,s,"metadata",0,{title:"Ticari Yatırım & İskonto · V3 · Insider"}],84065)},41346,a=>{a.n(a.i(84065))}];

//# sourceMappingURL=apps_dashboard_0vtc3a1._.js.map