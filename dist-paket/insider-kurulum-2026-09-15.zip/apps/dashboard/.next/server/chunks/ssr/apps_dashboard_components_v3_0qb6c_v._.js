module.exports=[73478,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);let e=/^\d{4}-\d{2}-\d{2}$/,f=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];a.s(["GlobalDonemFilter",0,function(){let a=(0,c.useRouter)(),g=(0,c.usePathname)(),h=(0,c.useSearchParams)(),[i,j]=(0,d.useTransition)(),k=h?.get("from")??"",l=h?.get("to")??"",m=(h?.get("donem")??"").toLowerCase(),n=e.test(k)&&e.test(l),o=n?"serbest":m&&"son30g"!==m?m:"son30g",[p,q]=(0,d.useState)(n),[r,s]=(0,d.useState)(k),[t,u]=(0,d.useState)(l),v=e.test(r),w=e.test(t),x=v&&w&&r>t,y=v&&w&&!x;function z(b){let c=new URLSearchParams(h?.toString()??"");b(c);let d=c.toString();j(()=>a.push(`${g}${d?`?${d}`:""}`))}return(0,b.jsxs)("div",{className:"donem-filter",children:[(0,b.jsx)("span",{className:"lbl",children:"Dönem"}),(0,b.jsxs)("div",{className:"chips",children:[f.map(a=>(0,b.jsx)("button",{type:"button",className:`chip ${o===a.key?"on":""}`,onClick:()=>{var b;return b=a.key,void(q(!1),z(a=>{a.delete("from"),a.delete("to"),"son30g"===b?a.delete("donem"):a.set("donem",b)}))},disabled:i,children:a.label},a.key)),(0,b.jsx)("button",{type:"button",className:`chip ${"serbest"===o||p?"on":""}`,onClick:()=>q(a=>!a),disabled:i,children:"Serbest"})]}),(p||"serbest"===o)&&(0,b.jsxs)("div",{className:"range",children:[(0,b.jsx)("input",{type:"date",value:r,max:t||void 0,onChange:a=>s(a.target.value),disabled:i,className:"inp","aria-label":"Başlangıç tarihi"}),(0,b.jsx)("span",{className:"sep",children:"–"}),(0,b.jsx)("input",{type:"date",value:t,min:r||void 0,onChange:a=>u(a.target.value),disabled:i,className:"inp","aria-label":"Bitiş tarihi"}),(0,b.jsx)("button",{type:"button",className:"apply",onClick:function(){y&&z(a=>{a.delete("donem"),a.set("from",r),a.set("to",t)})},disabled:i||!y,children:"Uygula"}),x&&(0,b.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),i&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},46654,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(50944),e=a.i(28913);a.s(["SatisUnitToggle",0,function(){let a=(0,d.usePathname)()??"/",f=(0,d.useSearchParams)(),g=(0,e.useTenant)(),h=g.volume.key,i=f.get("unit")===h?h:"tl",j=[{id:"tl",label:`${g.currencySymbol} TL`,hint:"Ciro (net tutar) bazlı görünüm"},{id:h,label:g.volume.short,hint:g.volume.hint}];return(0,b.jsxs)("div",{role:"tablist","aria-label":"Birim",className:"satis-unit-toggle",title:`TL ↔ ${g.volume.short} g\xf6r\xfcn\xfcm anahtarı — sunucu sorgusu değişmez, yalnızca g\xf6sterim.`,children:[(0,b.jsx)("span",{className:"lbl",children:"Birim"}),j.map(d=>{var e;let g,h,j=i===d.id;return(0,b.jsx)(c.default,{href:(e=d.id,g=new URLSearchParams(f.toString()),"tl"===e?g.delete("unit"):g.set("unit",e),(h=g.toString())?`${a}?${h}`:a),role:"tab","aria-selected":j,title:d.hint,className:`opt${j?" active":""}`,children:d.label},d.id)}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .satis-unit-toggle {
          display: inline-flex; align-items: center; gap: 4px;
          padding: 4px;
          border-radius: 8px;
          background: var(--color-surface-2);
          border: 1px solid var(--color-border);
        }
        .satis-unit-toggle .lbl {
          padding: 0 8px;
          font-size: 10.5px;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--color-muted);
          font-weight: 600;
        }
        .satis-unit-toggle .opt {
          display: inline-flex; align-items: center;
          height: 28px; padding: 0 12px;
          border-radius: 6px;
          font-size: 12px; font-weight: 600;
          color: var(--color-muted);
          text-decoration: none;
          transition: background-color 0.15s ease, color 0.15s ease;
        }
        .satis-unit-toggle .opt:hover { color: var(--color-fg); }
        .satis-unit-toggle .opt.active {
          background: var(--color-surface);
          color: var(--color-fg);
          border: 1px solid var(--color-border);
          box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        }
      `}})]})}])}];

//# sourceMappingURL=apps_dashboard_components_v3_0qb6c_v._.js.map