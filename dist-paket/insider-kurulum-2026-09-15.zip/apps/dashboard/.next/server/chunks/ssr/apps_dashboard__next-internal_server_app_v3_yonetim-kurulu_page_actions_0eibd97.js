module.exports=[39544,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_yonetim-kurulu_page_actions_0eibd97.js.map