module.exports=[327,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(50944),e=a.i(71901),f=a.i(28913);function g(){let[a,g]=(0,c.useState)(""),[h,i]=(0,c.useState)(""),[j,k]=(0,c.useState)(null),[l,m]=(0,c.useState)(!1),{login:n}=(0,e.useAuth)(),o=(0,d.useRouter)(),p=(0,d.useSearchParams)(),q=(0,f.useTenant)();async function r(b){if(b.preventDefault(),!a.trim()||!h.trim())return;m(!0),k(null);let c=await n(a,h);if(c)k(c),m(!1);else{let a=p?.get("next"),b=q.ui?.defaultLanding??"/";o.push(a&&a.startsWith("/")?a:b),o.refresh()}}let s=q?.displayName??"Insider";return(0,b.jsxs)("div",{className:"login-wrap",children:[(0,b.jsxs)("form",{className:"login-card",onSubmit:r,children:[(0,b.jsx)("div",{className:"login-badge",children:(s[0]??"E").toUpperCase()}),(0,b.jsx)("h1",{className:"login-title",children:s}),(0,b.jsx)("p",{className:"login-sub",children:"Hesabınıza giriş yapın"}),(0,b.jsx)("label",{className:"login-label",htmlFor:"username",children:"Kullanıcı Adı"}),(0,b.jsx)("input",{id:"username",className:"login-input",type:"text",value:a,onChange:a=>g(a.target.value),placeholder:"Kullanıcı adınız",autoComplete:"username",autoFocus:!0}),(0,b.jsx)("label",{className:"login-label",htmlFor:"password",children:"Şifre"}),(0,b.jsx)("input",{id:"password",className:"login-input",type:"password",value:h,onChange:a=>i(a.target.value),placeholder:"Şifreniz",autoComplete:"current-password"}),j&&(0,b.jsx)("p",{className:"login-error",children:j}),(0,b.jsx)("button",{className:"login-btn",type:"submit",disabled:l||!a.trim()||!h.trim(),children:l?"Giriş yapılıyor…":"Giriş Yap"})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .login-wrap { min-height: 70dvh; display: flex; align-items: center; justify-content: center; padding: 24px; }
        .login-card {
          width: 100%; max-width: 360px;
          display: flex; flex-direction: column;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 14px;
          padding: 32px 28px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.06);
        }
        .login-badge {
          width: 52px; height: 52px; border-radius: 14px;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          display: flex; align-items: center; justify-content: center;
          font-size: 22px; font-weight: 700; margin: 0 auto 16px;
        }
        .login-title { font-size: 20px; font-weight: 700; text-align: center; color: var(--color-fg); letter-spacing: -0.01em; }
        .login-sub { font-size: 13px; color: var(--color-muted); text-align: center; margin: 4px 0 22px; }
        .login-label { font-size: 12px; font-weight: 600; color: var(--color-fg); margin-bottom: 6px; }
        .login-input {
          width: 100%; box-sizing: border-box;
          padding: 10px 12px; margin-bottom: 16px;
          font-size: 14px; color: var(--color-fg);
          background: var(--color-bg, var(--color-surface));
          border: 1px solid var(--color-border); border-radius: 8px;
          font-family: inherit;
        }
        .login-input:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; border-color: transparent; }
        .login-error { font-size: 13px; color: var(--color-bad, #dc2626); margin: 0 0 14px; }
        .login-btn {
          width: 100%; padding: 11px 16px;
          font-size: 14px; font-weight: 600;
          color: var(--color-accent-fg, #fff); background: var(--color-accent);
          border: none; border-radius: 8px; cursor: pointer;
          transition: opacity 0.15s;
        }
        .login-btn:hover:not(:disabled) { opacity: 0.9; }
        .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      `}})]})}a.s(["default",0,function(){return(0,b.jsx)(c.Suspense,{fallback:null,children:(0,b.jsx)(g,{})})}])}];

//# sourceMappingURL=apps_dashboard_app_login_page_tsx_05inbp8._.js.map