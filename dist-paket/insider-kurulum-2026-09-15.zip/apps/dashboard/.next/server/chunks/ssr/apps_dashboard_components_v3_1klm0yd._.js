module.exports=[73478,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);let e=/^\d{4}-\d{2}-\d{2}$/,f=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];a.s(["GlobalDonemFilter",0,function(){let a=(0,c.useRouter)(),g=(0,c.usePathname)(),h=(0,c.useSearchParams)(),[i,j]=(0,d.useTransition)(),k=h?.get("from")??"",l=h?.get("to")??"",m=(h?.get("donem")??"").toLowerCase(),n=e.test(k)&&e.test(l),o=n?"serbest":m&&"son30g"!==m?m:"son30g",[p,q]=(0,d.useState)(n),[r,s]=(0,d.useState)(k),[t,u]=(0,d.useState)(l),v=e.test(r),w=e.test(t),x=v&&w&&r>t,y=v&&w&&!x;function z(b){let c=new URLSearchParams(h?.toString()??"");b(c);let d=c.toString();j(()=>a.push(`${g}${d?`?${d}`:""}`))}return(0,b.jsxs)("div",{className:"donem-filter",children:[(0,b.jsx)("span",{className:"lbl",children:"Dönem"}),(0,b.jsxs)("div",{className:"chips",children:[f.map(a=>(0,b.jsx)("button",{type:"button",className:`chip ${o===a.key?"on":""}`,onClick:()=>{var b;return b=a.key,void(q(!1),z(a=>{a.delete("from"),a.delete("to"),"son30g"===b?a.delete("donem"):a.set("donem",b)}))},disabled:i,children:a.label},a.key)),(0,b.jsx)("button",{type:"button",className:`chip ${"serbest"===o||p?"on":""}`,onClick:()=>q(a=>!a),disabled:i,children:"Serbest"})]}),(p||"serbest"===o)&&(0,b.jsxs)("div",{className:"range",children:[(0,b.jsx)("input",{type:"date",value:r,max:t||void 0,onChange:a=>s(a.target.value),disabled:i,className:"inp","aria-label":"Başlangıç tarihi"}),(0,b.jsx)("span",{className:"sep",children:"–"}),(0,b.jsx)("input",{type:"date",value:t,min:r||void 0,onChange:a=>u(a.target.value),disabled:i,className:"inp","aria-label":"Bitiş tarihi"}),(0,b.jsx)("button",{type:"button",className:"apply",onClick:function(){y&&z(a=>{a.delete("donem"),a.set("from",r),a.set("to",t)})},disabled:i||!y,children:"Uygula"}),x&&(0,b.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),i&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},43342,a=>{"use strict";var b=a.i(87924);let c=(0,a.i(64831).default)("file-spreadsheet",[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]]);function d(a){let b=String(a);return/[;"\r\n]/.test(b)?`"${b.replace(/"/g,'""')}"`:b}function e(a){return a.map(d).join(";")}function f(a,b=0){return a.toLocaleString("tr-TR",{minimumFractionDigits:b,maximumFractionDigits:b})}a.s(["MarkaSkuExportButton",0,function({portfolio:a,topSkus:d}){return(0,b.jsxs)("button",{type:"button",onClick:function(){let b,c,g=new Blob(["\uFEFF"+function(a,b){let c=[];for(let b of(c.push(e(["Marka & SKU Performansı — dışa aktarım"])),c.push(e(["Oluşturulma",new Date().toLocaleString("tr-TR")])),c.push(""),c.push(e(["MARKA PORTFÖYÜ (son 30 gün net ciro)"])),c.push(e(["Sıra","Marka","Marka Kodu","Ciro (TL)","Pay (%)","Müşteri Sayısı","Fatura Sayısı","Stratejik Marka"])),a)){let a=b.isOther||b.isTotal;c.push(e([a?"":b.rank,b.isTotal?"TOPLAM":b.isOther?"Diğer":b.marka,a?"":b.markaKod,f(b.ciro,2),f(b.payPct,1),f(b.musteriSayi),f(b.faturaSayisi),a?"":b.isStratejik?"Evet":"Hayır"]))}for(let a of(c.push(""),c.push(e(["TOP SKU (son 30 gün net ciro)"])),c.push(e(["Sıra","Ürün Kodu","Ürün Adı","Marka","Ciro (TL)","Miktar","Müşteri Sayısı","Pay (%)","Stratejik Marka"])),b)){let b=a.isOther||a.isTotal;c.push(e([b?"":a.rank,b?"":a.urunKod,a.isTotal?"TOPLAM":a.isOther?"Diğer":a.ad,b?"":a.marka,f(a.ciro,2),f(a.miktar),f(a.musteriSayi),f(a.payPct,2),b?"":a.isStratejik?"Evet":"Hayır"]))}return c.join("\r\n")}(a,d)],{type:"text/csv;charset=utf-8;"}),h=URL.createObjectURL(g),i=document.createElement("a");i.href=h,i.download=`marka-sku-${b=new Date,c=a=>String(a).padStart(2,"0"),`${b.getFullYear()}${c(b.getMonth()+1)}${c(b.getDate())}`}.csv`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(h)},title:"Marka portföyü ve Top SKU tablolarını CSV olarak indir (Excel'de doğrudan açılır)",className:"inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md text-[11px] font-semibold border bg-surface-2 text-fg-2 border-border transition-colors hover:border-accent/40 hover:text-accent",children:[(0,b.jsx)(c,{size:12}),"Excel’e Aktar"]})}],43342)}];

//# sourceMappingURL=apps_dashboard_components_v3_1klm0yd._.js.map