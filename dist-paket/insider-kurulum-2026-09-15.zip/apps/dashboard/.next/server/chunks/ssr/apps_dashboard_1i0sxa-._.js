module.exports=[12245,a=>{"use strict";a.s(["KomutaFilterDropdowns",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call KomutaFilterDropdowns() from the server but KomutaFilterDropdowns is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/KomutaFilterDropdowns.tsx <module evaluation>","KomutaFilterDropdowns")},54276,a=>{"use strict";a.s(["KomutaFilterDropdowns",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call KomutaFilterDropdowns() from the server but KomutaFilterDropdowns is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/KomutaFilterDropdowns.tsx","KomutaFilterDropdowns")},61323,a=>{"use strict";a.i(12245);var b=a.i(54276);a.n(b)},88257,a=>{"use strict";a.s(["KomutaPeriyotDropdown",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call KomutaPeriyotDropdown() from the server but KomutaPeriyotDropdown is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/KomutaPeriyotDropdown.tsx <module evaluation>","KomutaPeriyotDropdown")},35691,a=>{"use strict";a.s(["KomutaPeriyotDropdown",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call KomutaPeriyotDropdown() from the server but KomutaPeriyotDropdown is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/KomutaPeriyotDropdown.tsx","KomutaPeriyotDropdown")},95937,a=>{"use strict";a.i(88257);var b=a.i(35691);a.n(b)},15686,a=>{"use strict";a.s(["FinanceAgentLauncher",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call FinanceAgentLauncher() from the server but FinanceAgentLauncher is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/FinanceAgentLauncher.tsx <module evaluation>","FinanceAgentLauncher")},69211,a=>{"use strict";a.s(["FinanceAgentLauncher",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call FinanceAgentLauncher() from the server but FinanceAgentLauncher is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/FinanceAgentLauncher.tsx","FinanceAgentLauncher")},88509,a=>{"use strict";a.i(15686);var b=a.i(69211);a.n(b)},71078,a=>{"use strict";a.s(["ChannelMixChart",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call ChannelMixChart() from the server but ChannelMixChart is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/ChannelMixChart.tsx <module evaluation>","ChannelMixChart")},22069,a=>{"use strict";a.s(["ChannelMixChart",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call ChannelMixChart() from the server but ChannelMixChart is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/ChannelMixChart.tsx","ChannelMixChart")},5013,a=>{"use strict";a.i(71078);var b=a.i(22069);a.n(b)},57123,a=>{"use strict";a.s(["CalendarChart",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call CalendarChart() from the server but CalendarChart is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/CalendarChart.tsx <module evaluation>","CalendarChart")},26949,a=>{"use strict";a.s(["CalendarChart",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call CalendarChart() from the server but CalendarChart is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/CalendarChart.tsx","CalendarChart")},71776,a=>{"use strict";a.i(57123);var b=a.i(26949);a.n(b)},99386,a=>{"use strict";a.s(["InfoHint",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call InfoHint() from the server but InfoHint is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/InfoHint.tsx <module evaluation>","InfoHint")},99750,a=>{"use strict";a.s(["InfoHint",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call InfoHint() from the server but InfoHint is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/InfoHint.tsx","InfoHint")},74347,a=>{"use strict";a.i(99386);var b=a.i(99750);a.n(b)},93310,a=>{"use strict";a.s(["TurkeyMapPolygon",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call TurkeyMapPolygon() from the server but TurkeyMapPolygon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/TurkeyMapPolygon.tsx <module evaluation>","TurkeyMapPolygon")},48190,a=>{"use strict";a.s(["TurkeyMapPolygon",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call TurkeyMapPolygon() from the server but TurkeyMapPolygon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/TurkeyMapPolygon.tsx","TurkeyMapPolygon")},71028,a=>{"use strict";a.i(93310);var b=a.i(48190);a.n(b)},74262,a=>{"use strict";a.s(["UnitToggle",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call UnitToggle() from the server but UnitToggle is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/UnitToggle.tsx <module evaluation>","UnitToggle")},88985,a=>{"use strict";a.s(["UnitToggle",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call UnitToggle() from the server but UnitToggle is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/UnitToggle.tsx","UnitToggle")},58718,a=>{"use strict";a.i(74262);var b=a.i(88985);a.n(b)},89120,a=>{"use strict";a.s(["CustomerTypeBrandPanel",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call CustomerTypeBrandPanel() from the server but CustomerTypeBrandPanel is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/CustomerTypeBrandPanel.tsx <module evaluation>","CustomerTypeBrandPanel")},14256,a=>{"use strict";a.s(["CustomerTypeBrandPanel",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call CustomerTypeBrandPanel() from the server but CustomerTypeBrandPanel is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/komuta/CustomerTypeBrandPanel.tsx","CustomerTypeBrandPanel")},56786,a=>{"use strict";a.i(89120);var b=a.i(14256);a.n(b)},32024,a=>{"use strict";var b=a.i(7997),c=a.i(717),d=a.i(95936);a.i(70396);var e=a.i(73727),f=a.i(17239),g=a.i(61323),h=a.i(95937),i=a.i(93105);a.i(88509);var j=a.i(5013),k=a.i(71776),l=a.i(74347),m=a.i(71028),n=a.i(58718),o=a.i(56786);async function p({searchParams:a}){let c,d=await a,g="1"===d.refresh,h="1"===d.reel,l="9le"===d.unit?"9le":"tl",n=d.bolge?.trim()||null,t=d.kanal?.trim()||null,u=d.urunGrup?.trim()||null,E=d.periyot?.trim()||"p12",F="p3"===E?3:"p6"===E?6:"ytd"===E?"ytd":12,G={bolgeler:[],kanallar:[],urunGruplari:[]};try{G=await (0,f.getKomutaFacets)()}catch{G={bolgeler:[],kanallar:[],urunGruplari:[]}}try{c=await (0,f.getKomutaSnapshot)({refresh:g,reelTL:h,unit:l,bolge:n,kanal:t,urunGrup:u})}catch(a){a instanceof Error&&/API 40[13]/.test(a.message)&&(0,e.redirect)("/login"),(0,e.notFound)()}let H=t?G.kanallar.find(a=>a.kod===t)?.ad??t:null,J=u?G.urunGruplari.find(a=>a.kod===u)?.ad??u:null,K=[n?`B\xf6lge: ${n}`:null,H?`Grup: ${H}`:null,J?`\xdcr\xfcn: ${J}`:null].filter(Boolean),L=K.length>0?K.join(" · "):"Tüm Distribütörler";return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:I}}),(0,b.jsxs)("div",{className:"komuta-root",children:[(0,b.jsx)(q,{generatedAt:c.generatedAt,reelTL:c.reelTL,demo:!!c.demoDate,scopeLabel:L}),(0,b.jsx)(r,{reelTL:c.reelTL,facets:G,bolge:n,kanal:t,urunGrup:u,periyot:E}),c.reelTL&&(0,b.jsx)(v,{}),c.brief&&c.brief.trim().length>=50?(0,b.jsx)(C,{brief:c.brief}):(0,b.jsxs)("div",{className:"ai-brief-empty",children:[(0,b.jsx)("span",{className:"ai-brief-empty-icon",children:"🤖"}),(0,b.jsxs)("div",{children:[(0,b.jsx)("strong",{children:"Günün AI yorumu henüz hazır değil."})," ",(0,b.jsx)("span",{className:"ai-brief-empty-sub",children:"Yorum, gece güncellemesinde (03:00) bir kez üretilir ve gün boyu aynı kalır. Bir sonraki güncellemede otomatik gelecek."})]})]}),(0,b.jsx)(s,{kpis:c.kpis}),c.upcomingEvent&&(0,b.jsx)(w,{event:c.upcomingEvent}),(0,b.jsxs)("div",{className:"main-grid",children:[!(0,i.panelHidden)("panel.cockpit.map")&&(0,b.jsx)(m.TurkeyMapPolygon,{regions:c.regions}),!(0,i.panelHidden)("panel.cockpit.channelmonthly")&&(0,b.jsx)(j.ChannelMixChart,{rows:c.channelMonthly,unit:c.unit,title:(0,i.panelTitle)("panel.cockpit.channelmonthly","Kanal Mix"),periodMonths:F,enablePieView:!0})]}),!(0,i.panelHidden)("panel.cockpit.calendar")&&(0,b.jsx)(k.CalendarChart,{monthly:c.monthlyTrend,unit:c.unit}),(0,b.jsxs)("div",{className:"battle-grid",children:[!(0,i.panelHidden)("panel.cockpit.channeltype")&&(0,b.jsx)(j.ChannelMixChart,{rows:c.channelByType,unit:c.unit,title:(0,i.panelTitle)("panel.cockpit.channeltype","Müşteri Grup Kırılımı · Son 12 Ay"),icon:"🛒",category:"grup kırılımı",sourceNote:"Müşteri grup kırılımı: Prestige / Premium Plus / Premium / Standart Plus / Standart dağılımı (TXTGRUPKIRILIMKOD), son 12 ay.",enableTypeFilter:!0,typeFilterLabel:"Grup Kırılımı"}),(0,b.jsx)(x,{matrix:c.matrix,unit:c.unit})]}),(0,b.jsx)(y,{heatmap:c.heatmap}),!(0,i.panelHidden)("panel.cockpit.customertypebrand")&&(0,b.jsx)(o.CustomerTypeBrandPanel,{data:c.customerTypeBrand,title:(0,i.panelTitle)("panel.cockpit.customertypebrand","Müşteri Grup Kırılımı × Marka")}),(0,b.jsxs)("div",{className:"bottom-grid",children:[(0,b.jsx)(z,{reps:c.reps,unit:c.unit}),(0,b.jsx)(A,{dists:c.topDists,unit:c.unit})]}),(0,b.jsx)(B,{portfolio:c.portfolio,unit:c.unit}),(0,b.jsx)(D,{generatedAt:c.generatedAt})]})]})}function q({generatedAt:a,reelTL:c,demo:d,scopeLabel:e}){let f=function(a){let b=Math.floor((Date.now()-new Date(a).getTime())/1e3);if(b<60)return"az önce";let c=Math.floor(b/60);if(c<60)return`${c} dk \xf6nce`;let d=Math.floor(c/60);return d<24?`${d} sa \xf6nce`:`${Math.floor(d/24)} g\xfcn \xf6nce`}(a);return(0,b.jsxs)("header",{className:"komuta-page-header",children:[(0,b.jsxs)("div",{className:"komuta-page-header-main",children:[(0,b.jsxs)("div",{className:"komuta-eyebrow",children:[(0,b.jsx)("span",{className:"komuta-eyebrow-dot"}),"Komuta"]}),(0,b.jsx)("h1",{className:"komuta-page-title",children:(0,i.t)((0,i.getContentMap)(),"page.cockpit.title","Operasyon Genel Görünümü")}),(0,b.jsxs)("p",{className:"komuta-page-desc",children:["Univera Distribütör Operasyonu · CEO / Satış Direktörü görünümü ·"," ",(0,b.jsx)("strong",{children:e})," · Son 30 Gün ·"," ",(0,b.jsx)("span",{style:{color:"#6366f1"},children:c?"Reel TL":"Nominal TL"})]})]}),(0,b.jsxs)("div",{className:"komuta-page-header-actions",children:[d&&(0,b.jsx)(u,{}),(0,b.jsxs)("span",{className:"live-indicator",children:[(0,b.jsx)("span",{className:"live-dot"}),f]})]})]})}function r({reelTL:a,facets:c,bolge:e,kanal:f,urunGrup:i,periyot:j}){return(0,b.jsxs)("div",{className:"filter-bar",children:[(0,b.jsx)(g.KomutaFilterDropdowns,{facets:c,bolge:e,kanal:f,urunGrup:i}),(0,b.jsx)(h.KomutaPeriyotDropdown,{periyot:j}),(0,b.jsx)("span",{className:"filter-spacer"}),(0,b.jsxs)("div",{className:"toggle-group",children:[(0,b.jsxs)(d.default,{href:a?"/komuta":"/komuta?reel=1",className:`toggle toggle-link${a?" on":""}`,title:"Geçmiş değerleri TÜFE multiplier ile bugünün parasına çevirir",prefetch:!1,children:[(0,b.jsx)("span",{className:"switch"})," Reel TL (TÜFE)"]}),(0,b.jsx)(n.UnitToggle,{})]})]})}function s({kpis:a}){if((0,i.panelHidden)("panel.cockpit.kpistrip"))return null;if(!a||0===a.length)return(0,b.jsx)("div",{className:"empty-note",children:"KPI verisi alınamadı."});let c=["#6366f1","#16a34a","#9333ea","#6366f1","#16a34a"];return(0,b.jsxs)("div",{className:"kpi-strip-wrap",children:[(0,b.jsxs)("div",{className:"kpi-strip-head",children:[(0,b.jsx)("span",{className:"kpi-strip-label",children:(0,i.panelTitle)("panel.cockpit.kpistrip","Son 30 gün özet")}),(0,b.jsx)(l.InfoHint,{title:"KPI hesaplaması",source:"TBLMSDFATURA + TBLMSDBELGEDETAY + TBLURUNEKSAHA (9L için)",window:"Son 30 gün vs önceki 30 gün (delta % hesabı)",base:"SUM(DBLNETTUTAR) (Ciro), COUNT (Fatura), SUM(DBLMIKTAR × ek_saha_26) (Hacim = 9L)",notes:["Filtre: BYTTUR=0 AND BYTDURUM=0 (onaylı satış faturası)",'9L çarpanı: TBLURUNEKSAHA saha 26 "9 LT Değer" (Pernod\'un resmi katsayısı; 701 ürün için dolu)',"Fallback (ek saha boş ise): DBLLITRE / 9 klasik hesaba düşülür","Demo modda GETDATE() çağrıları DEMO_DATE env değerine rewrite edilir"]})]}),(0,b.jsx)("div",{className:"kpi-strip",children:a.map((a,d)=>(0,i.panelHidden)(`kpi.cockpit.${a.id}`)?null:(0,b.jsxs)("div",{className:"kpi-card",style:{"--accent":c[d]??"#6366f1"},children:[(0,b.jsx)("div",{className:"kpi-label",children:(0,i.panelTitle)(`kpi.cockpit.${a.id}`,a.label)}),(0,b.jsx)("div",{className:"kpi-value",children:(0,b.jsx)(t,{k:a})}),(0,b.jsxs)("div",{className:"kpi-meta",children:[null!=a.delta&&(0,b.jsxs)("span",{className:a.delta>=0?"delta-up":"delta-down",children:[a.delta>=0?"▲":"▼"," %",Math.abs(a.delta).toFixed(1)]}),a.deltaSub&&(0,b.jsx)("span",{className:"kpi-sub",children:a.deltaSub})]})]},a.id))})]})}function t({k:a}){if("percent"===a.format)return(0,b.jsxs)(b.Fragment,{children:["%",a.value.toFixed(1)]});let c="compact"===a.format?E(a.value):Math.round(a.value).toLocaleString("tr-TR");return(0,b.jsxs)(b.Fragment,{children:[c,a.unit&&(0,b.jsx)("span",{style:{fontSize:"0.55em",opacity:.55,fontWeight:500,marginLeft:"0.32em",letterSpacing:"0.02em",verticalAlign:"0.18em"},children:a.unit})]})}function u(){return(0,b.jsxs)("span",{className:"demo-badge",title:"Demo modu — örnek veri",children:[(0,b.jsx)("span",{className:"demo-badge-dot"}),"Demo modu"]})}function v(){return(0,b.jsxs)("div",{className:"reel-banner",children:[(0,b.jsx)("div",{className:"reel-banner-icon",children:"📈"}),(0,b.jsxs)("div",{className:"reel-banner-text",children:[(0,b.jsx)("strong",{children:"Reel TL görünümü aktif"})," · Geçmiş değerler TÜFE multiplier'ı ile bugünün parasına çevrildi."," ",(0,b.jsx)("span",{style:{color:"#78716c"},children:"YoY ve 2-yıllık % değerleri reel kıyasla yeniden hesaplandı — enflasyon arındırılmış gerçek büyüme."})]}),(0,b.jsx)(d.default,{href:"/komuta",className:"reel-banner-cta",prefetch:!1,children:"Nominal TL'ye dön →"})]})}function w({event:a}){return(0,b.jsxs)("div",{className:"cal-banner",children:[(0,b.jsx)("div",{className:"cal-banner-icon",children:"📅"}),(0,b.jsxs)("div",{className:"cal-banner-text",children:[(0,b.jsxs)("strong",{children:[a.daysAhead," gün sonra ",a.name]})," · ","(",new Date(a.date).toLocaleDateString("tr-TR",{day:"2-digit",month:"long",year:"numeric"}),")"," · ",(0,b.jsx)("span",{style:{color:"#78716c"},children:"Yaklaşan Sezon panelinde geçen yıl etkisi"})]}),(0,b.jsx)("div",{className:"cal-banner-cta",children:"Sezon planını incele →"})]})}function x({matrix:a,unit:c}){return(0,i.panelHidden)("panel.cockpit.matrix")?null:(0,b.jsxs)("div",{className:"panel matrix-panel",children:[(0,b.jsxs)("div",{className:"panel-header",children:[(0,b.jsxs)("div",{className:"panel-title",children:[(0,b.jsx)("span",{className:"icon",children:"📋"})," ",(0,i.panelTitle)("panel.cockpit.matrix","Ürün Grubu × Dönem"),(0,b.jsx)(l.InfoHint,{title:"Matrix hesaplaması",source:"TBLMSDFATURA × TBLMSDBELGEDETAY × TBLURUN × TBLURUNGRUP",window:"5 dönem: bu ay, geçen ay, 3 ay önce, geçen yıl aynı ay, 2 yıl önce aynı ay",base:"SUM(DBLNETFIYAT × DBLMIKTAR) detay-bazlı + PeriodScales ile fatura tabanına normalize",notes:["Detay ciro fatura toplamından ~%5-15 farklı; her dönem için fatura/detay oranı (PeriodScales) hesaplanıp çarpılır","TBLURUNGRUP join'inde LNGDISTKOD=u.LNGDISTKOD ekleme yapma (her ikisi NULL→JOIN boşalır)","Reel TL modunda her dönem TÜFE multiplier'ı uygulanır",'Top 8 grup + "Diğer" (kalanların toplamı) + dip "Toplam" satırı']})]}),(0,b.jsx)("div",{className:"panel-meta",children:"Top 8 + Diğer + Toplam"})]}),0===a.length?(0,b.jsx)("div",{className:"empty-note",children:"Ürün grubu verisi yok."}):(0,b.jsxs)("table",{className:"matrix-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{children:"Ürün Grubu"}),(0,b.jsxs)("th",{className:"current",children:["Bu Ay",(0,b.jsx)("span",{className:"sub",children:"son 30g"})]}),(0,b.jsxs)("th",{children:["Geçen Ay",(0,b.jsx)("span",{className:"sub",children:"30-60g"})]}),(0,b.jsxs)("th",{children:["3 Ay Önce",(0,b.jsx)("span",{className:"sub",children:"90-120g"})]}),(0,b.jsxs)("th",{children:["Geçen Yıl",(0,b.jsx)("span",{className:"sub",children:"~365g"})]}),(0,b.jsxs)("th",{children:["2 Yıl Önce",(0,b.jsx)("span",{className:"sub",children:"~730g"})]}),(0,b.jsx)("th",{children:"Trend"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>{var d;return(0,b.jsxs)("tr",{className:a.isTotal?"matrix-row-total":a.isOther?"matrix-row-other":void 0,children:[(0,b.jsxs)("td",{title:a.grup,children:[G(a.grup,28),!a.isOther&&!a.isTotal&&(0,b.jsx)(H,{tier:a.tier})]}),(0,b.jsx)("td",{className:"matrix-cell-current",children:(0,b.jsx)(F,{n:a.buAy,unit:c})}),(0,b.jsx)("td",{children:(0,b.jsx)(F,{n:a.gecenAy,unit:c})}),(0,b.jsx)("td",{children:(0,b.jsx)(F,{n:a.ucAyOnce,unit:c})}),(0,b.jsxs)("td",{children:[(0,b.jsx)(F,{n:a.gecenYil,unit:c}),null!=a.yoyPct&&(0,b.jsxs)("span",{className:`delta-pill ${a.yoyPct>=0?"up":"down"}`,children:[a.yoyPct>=0?"+":"","%",a.yoyPct.toFixed(0)]})]}),(0,b.jsx)("td",{children:(0,b.jsx)(F,{n:a.ikiYilOnce,unit:c})}),(0,b.jsx)("td",{children:a.isTotal?"Σ":"rocket"===(d=a.trend)?"🚀":"up"===d?"📈":"down"===d?"📉":"📊"})]},a.grup)})})]})]})}function y({heatmap:a}){if((0,i.panelHidden)("panel.cockpit.heatmap")||0===a.length)return null;let d=a[0]?.cells.map(a=>a.grup)??[];return(0,b.jsxs)("div",{className:"panel heatmap-panel",children:[(0,b.jsxs)("div",{className:"panel-header",children:[(0,b.jsxs)("div",{className:"panel-title",children:[(0,b.jsx)("span",{className:"icon",children:"🔥"})," ",(0,i.panelTitle)("panel.cockpit.heatmap","Bölge × Ürün Grubu · YoY Değişim Heatmap"),(0,b.jsx)(l.InfoHint,{title:"Heatmap YoY hesaplaması",source:"TBLMSDFATURA × TBLMSDBELGEDETAY × TBLURUN × TBLURUNGRUP × TBLDIST × TBLDISTGRUP",window:"Son 30g vs -395..-365g (geçen yıl aynı pencere)",base:"SUM(DBLNETFIYAT × DBLMIKTAR) her bölge × her grup hücresi",notes:["Top 8 bölge × Top 8 grup + Diğer (detay ciro toplamına göre)","yoyPct = (son − önceki)/önceki × 100; bucket sınıfı (fire/hot/warm/flat/cool/cold) Komuta CSS palette'i","Sadece kırmızı (cool/cold) hücreler tıklanabilir → Finans Agentı modal"]})]}),(0,b.jsx)("div",{className:"panel-meta",children:"Son 30g vs Geçen yıl aynı 30g"})]}),(0,b.jsxs)("div",{className:"heatmap-grid",style:{gridTemplateColumns:`repeat(${d.length+2}, 1fr)`},children:[(0,b.jsx)("div",{className:"h-head",children:"Bölge"}),d.map(a=>(0,b.jsx)("div",{className:"h-head",title:a,children:G(a,12)},a)),(0,b.jsx)("div",{className:"h-head right",children:"Bölge Ort."}),a.map(a=>(0,b.jsxs)(c.Fragment,{children:[(0,b.jsxs)("div",{className:"h-region",children:[a.bolge," ",(0,b.jsxs)("span",{className:"reg-sub",children:[a.distSayisi," distribütör"]})]}),a.cells.map((c,d)=>{let e=("cool"===c.bucket||"cold"===c.bucket)&&null!=c.yoyPct;return(0,b.jsx)("div",{className:`h-cell ${c.bucket}${e?" h-cell-clickable":""}`,...e?{"data-finance-region":a.bolge,"data-finance-product-group":c.grup,role:"button",tabIndex:0,title:`${a.bolge} \xd7 ${c.grup} — finans analizini a\xe7`}:{},children:null==c.yoyPct?"—":`${c.yoyPct>=0?"+":""}%${c.yoyPct.toFixed(0)}`},d)}),(0,b.jsx)("div",{className:"h-avg",style:null!=a.rowAvgPct&&a.rowAvgPct<0?{color:"#dc2626"}:void 0,children:null==a.rowAvgPct?"—":`${a.rowAvgPct>=0?"+":""}%${a.rowAvgPct.toFixed(1)}`})]},a.bolge))]})]})}function z({reps:a,unit:c}){if((0,i.panelHidden)("panel.cockpit.reps"))return null;let d=a.slice(0,10),e=Math.max(1,...d.map(a=>a.ciro));return(0,b.jsxs)("div",{className:"panel leaderboard",children:[(0,b.jsxs)("div",{className:"panel-header",children:[(0,b.jsxs)("div",{className:"panel-title",children:[(0,b.jsx)("span",{className:"icon",children:"🏆"})," ",(0,i.panelTitle)("panel.cockpit.reps","Top Satış Temsilcileri"),(0,b.jsx)(l.InfoHint,{title:"Satış temsilcisi sıralaması",source:"TBLMSDFATURA × TBLSATISTEMSILCISI × TBLDIST",window:"Son 30 gün",base:"SUM(DBLNETTUTAR) her temsilci için + COUNT fatura",notes:["Filtre: f.BYTTUR=0, f.BYTDURUM=0, s.BYTDURUM=0 (aktif temsilci)","Top 10; sıralama ciro DESC"]})]}),(0,b.jsx)("div",{className:"panel-meta",children:"Son 30g · ciro sırası"})]}),0===d.length?(0,b.jsx)("div",{className:"empty-note",children:"Temsilci verisi yok."}):d.map(a=>{let d=a.ciro/e*100;return(0,b.jsxs)("div",{className:"lb-row",children:[(0,b.jsx)("div",{className:`lb-rank${1===a.rank?" top1":2===a.rank?" top2":3===a.rank?" top3":""}`,children:a.rank}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"lb-name",children:a.ad}),a.distributor&&(0,b.jsx)("span",{className:"lb-region",children:a.distributor})]}),(0,b.jsx)("div",{className:"lb-bar",children:(0,b.jsx)("div",{className:`lb-bar-fill${d>=70?"":d>=40?" warn":" bad"}`,style:{width:`${d}%`}})}),(0,b.jsx)("div",{className:`lb-pct ${d>=70?"":d>=40?"warn":"bad"}`,children:(0,b.jsx)(F,{n:a.ciro,unit:c})})]},a.ad+a.rank)})]})}function A({dists:a,unit:c}){if((0,i.panelHidden)("panel.cockpit.dists"))return null;let d=Math.max(1,...a.map(a=>a.ciro));return(0,b.jsxs)("div",{className:"panel leaderboard",children:[(0,b.jsxs)("div",{className:"panel-header",children:[(0,b.jsxs)("div",{className:"panel-title",children:[(0,b.jsx)("span",{className:"icon",children:"🏢"})," ",(0,i.panelTitle)("panel.cockpit.dists","Top Distribütörler"),(0,b.jsx)(l.InfoHint,{title:"Distribütör sıralaması",source:"TBLMSDFATURA × TBLDIST × TBLDISTEKGRUP",window:"Son 30 gün",base:"SUM(DBLNETTUTAR) her distribütör için + COUNT fatura",notes:["Filtre: f.BYTTUR=0, f.BYTDURUM=0, d.BYTDURUM=0","Bölge etiketi (TBLDISTEKGRUP.TXTAD) liste satırında görünür","Top 10; sıralama ciro DESC"]})]}),(0,b.jsx)("div",{className:"panel-meta",children:"Son 30g · ciro sırası"})]}),0===a.length?(0,b.jsx)("div",{className:"empty-note",children:"Distribütör verisi yok."}):a.map(a=>{let e=a.ciro/d*100;return(0,b.jsxs)("div",{className:"lb-row",children:[(0,b.jsx)("div",{className:`lb-rank${1===a.rank?" top1":2===a.rank?" top2":3===a.rank?" top3":""}`,children:a.rank}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"lb-name",children:a.ad}),a.bolge&&(0,b.jsx)("span",{className:"lb-region",children:a.bolge})]}),(0,b.jsx)("div",{className:"lb-bar",children:(0,b.jsx)("div",{className:`lb-bar-fill${e>=70?"":e>=40?" warn":" bad"}`,style:{width:`${e}%`}})}),(0,b.jsx)("div",{className:`lb-pct ${e>=70?"":e>=40?"warn":"bad"}`,children:(0,b.jsx)(F,{n:a.ciro,unit:c})})]},a.ad+a.rank)})]})}function B({portfolio:a,unit:c}){return(0,i.panelHidden)("panel.cockpit.portfolio")?null:(0,b.jsxs)("div",{className:"panel brand-portfolio",children:[(0,b.jsxs)("div",{className:"panel-header",children:[(0,b.jsxs)("div",{className:"panel-title",children:[(0,b.jsx)("span",{className:"icon",children:"🥃"})," ",(0,i.panelTitle)("panel.cockpit.portfolio","Ürün Grubu Portföyü · 2 Yıllık Yörünge"),(0,b.jsx)(l.InfoHint,{title:"Portföy hesaplaması",source:"TBLMSDFATURA × TBLMSDBELGEDETAY × TBLURUN × TBLURUNGRUP",window:"3 dönem: son 30g, geçen yıl aynı 30g (-395..-365g), 2 yıl önce aynı 30g (-760..-730g)",base:"SUM(DBLNETFIYAT × DBLMIKTAR) detay-bazlı + PeriodScales ile fatura tabanına normalize",notes:["Tier sınıflandırma (luxury/premium/core/value) ürün grubu adına göre keyword eşleşmesi","yoyPct = (bu − geçenYıl)/geçenYıl × 100","twoYrPct = (bu − ikiYılÖnce)/ikiYılÖnce × 100","Reel TL modunda baz değerler TÜFE multiplier ile bugünün TL'sine çevrilir"]})]}),(0,b.jsx)("div",{className:"panel-meta",children:"Top 8 grup + Diğer"})]}),0===a.length?(0,b.jsx)("div",{className:"empty-note",children:"Portföy verisi yok."}):(0,b.jsxs)("table",{className:"bp-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{children:"Ürün Grubu"}),(0,b.jsx)("th",{className:"current",children:"Son 30g"}),(0,b.jsx)("th",{children:"1 yıl önce"}),(0,b.jsx)("th",{children:"2 yıl önce"}),(0,b.jsx)("th",{children:"YoY"}),(0,b.jsx)("th",{children:"2-yıl Δ"}),(0,b.jsx)("th",{children:"Trend"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>{let d=Math.max(a.bu,a.oneYearAgo,a.twoYearsAgo)||1,e=a.twoYearsAgo/d*100,f=a.oneYearAgo/d*100,g=a.bu/d*100,h=null!=a.yoyPct&&a.yoyPct<0;return(0,b.jsxs)("tr",{children:[(0,b.jsxs)("td",{title:a.grup,children:[G(a.grup,26),(0,b.jsx)(H,{tier:a.tier})]}),(0,b.jsx)("td",{className:"current",children:(0,b.jsx)(F,{n:a.bu,unit:c})}),(0,b.jsx)("td",{className:"right",children:(0,b.jsx)(F,{n:a.oneYearAgo,unit:c})}),(0,b.jsx)("td",{className:"right",children:(0,b.jsx)(F,{n:a.twoYearsAgo,unit:c})}),(0,b.jsx)("td",{className:"right",children:null==a.yoyPct?"—":(0,b.jsxs)("span",{className:`delta-pill ${a.yoyPct>=0?"up":"down"}`,children:[a.yoyPct>=0?"+":"","%",a.yoyPct.toFixed(0)]})}),(0,b.jsx)("td",{className:"right",children:null==a.twoYrPct?"—":(0,b.jsxs)("span",{className:`delta-pill ${a.twoYrPct>=0?"up":"down"}`,children:[a.twoYrPct>=0?"+":"","%",a.twoYrPct.toFixed(0)]})}),(0,b.jsx)("td",{className:"right",children:(0,b.jsxs)("span",{className:"bp-2yspark",children:[(0,b.jsx)("span",{className:"bar",style:{height:`${e}%`}}),(0,b.jsx)("span",{className:"bar",style:{height:`${f}%`}}),(0,b.jsx)("span",{className:`bar last${h?" declining":""}`,style:{height:`${g}%`}})]})})]},a.grup)})})]})]})}function C({brief:a}){return(0,i.panelHidden)("panel.cockpit.brief")?null:(0,b.jsxs)("div",{className:"ai-insight",children:[(0,b.jsx)("div",{className:"ai-icon",children:"✨"}),(0,b.jsxs)("div",{className:"ai-text",children:[(0,b.jsx)("div",{className:"ai-title",children:(0,i.panelTitle)("panel.cockpit.brief","UNIQUE AI · Bu Sabahın Yorumu")}),(0,b.jsx)("div",{className:"ai-body",dangerouslySetInnerHTML:{__html:a}})]})]})}function D({generatedAt:a}){return(0,b.jsxs)("div",{className:"footer-bar",children:[(0,b.jsxs)("span",{children:["UNIQUE AI Reports · Univera veri kaynağı · son sorgulama:"," ",new Date(a).toLocaleString("tr-TR")]}),(0,b.jsx)("span",{children:"Görünüm: CEO / Satış Direktörü"})]})}function E(a){return Number.isFinite(a)?Math.abs(a)>=1e9?(a/1e9).toFixed(1)+"Mr":Math.abs(a)>=1e6?(a/1e6).toFixed(1)+"M":Math.abs(a)>=1e3?(a/1e3).toFixed(1)+"K":Math.round(a).toString():"0"}function F({n:a,unit:c}){return(0,b.jsxs)(b.Fragment,{children:[E(a),(0,b.jsx)("span",{style:{fontSize:"0.72em",opacity:.55,fontWeight:500,marginLeft:"0.32em",letterSpacing:"0.02em"},children:"9le"===c?"9L":"₺"})]})}function G(a,b){return a.length>b?a.slice(0,b-1)+"…":a}function H({tier:a}){return"value"===a?null:(0,b.jsx)("span",{className:`tier-badge tier-${a}`,children:"luxury"===a?"LUX":"premium"===a?"PREM":"CORE"})}let I=`
.komuta-root {
  background: var(--color-bg);
  color: var(--color-fg);
  font-family: var(--font-sans);
  font-size: 13px;
  padding: 4px 0 20px 0;
  -webkit-font-smoothing: antialiased;
}
.komuta-root * { box-sizing: border-box; }

/* PAGE HEADER — risk/ziyaret sayfalarındaki tasarıma uyumlu */
.komuta-root .komuta-page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 18px;
}
.komuta-root .komuta-page-header-main { flex: 1; }
.komuta-root .komuta-eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  font-weight: 600;
  color: #6366f1;
  background: rgba(99, 102, 241, 0.08);
  border: 1px solid rgba(99, 102, 241, 0.2);
  border-radius: 6px;
  padding: 3px 8px;
  margin-bottom: 8px;
}
.komuta-root .komuta-eyebrow-dot {
  width: 6px; height: 6px;
  background: #6366f1;
  border-radius: 50%;
  animation: komuta-pulse 2s infinite;
}
.komuta-root .komuta-page-title {
  font-size: 28px;
  font-weight: 600;
  letter-spacing: -0.3px;
  color: #1c1917;
  margin: 0 0 6px 0;
  line-height: 1.15;
}
.komuta-root .komuta-page-desc {
  font-size: 14px;
  color: #44403c;
  line-height: 1.55;
  margin: 0;
  max-width: 720px;
}
.komuta-root .komuta-page-desc strong { color: #1c1917; font-weight: 600; }
.komuta-root .komuta-page-header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 12px;
  flex-shrink: 0;
}
.komuta-root .live-indicator {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 4px 10px; background: rgba(22, 163, 74, 0.1);
  border: 1px solid rgba(22, 163, 74, 0.25); border-radius: 999px;
  font-size: 11px; color: #16a34a;
}
.komuta-root .live-dot { width: 6px; height: 6px; background: #16a34a; border-radius: 50%; animation: komuta-pulse 2s infinite; }
.komuta-root .refresh-btn {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 6px 12px; background: #6366f1;
  border: 1px solid #6366f1; border-radius: 6px;
  font-size: 12px; color: #ffffff; font-weight: 500; text-decoration: none;
  cursor: pointer;
  box-shadow: 0 1px 2px rgba(28, 25, 23, 0.05);
}
.komuta-root .refresh-btn:hover { background: #4f46e5; }
@keyframes komuta-pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }

/* FILTER BAR */
.komuta-root .filter-bar {
  display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
  padding: 10px 16px; background: #ffffff; border: 1px solid #d6d3d1;
  border-radius: 8px; margin-bottom: 14px;
}
.komuta-root .filter-chip {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 6px 12px; background: #fafaf9; border: 1px solid #d6d3d1;
  border-radius: 6px; font-size: 12px; color: #44403c; cursor: pointer;
}
.komuta-root .filter-chip.active { background: rgba(99, 102, 241, 0.12); border-color: #6366f1; color: #6366f1; }
.komuta-root .filter-chip .caret { font-size: 9px; opacity: 0.6; }
.komuta-root .filter-spacer { flex: 1; }
.komuta-root .toggle-group { display: flex; gap: 8px; }
.komuta-root .toggle {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 6px 12px; background: #fafaf9; border: 1px solid #d6d3d1;
  border-radius: 6px; font-size: 11px; color: #78716c; cursor: help;
}
.komuta-root .toggle.on { background: rgba(99, 102, 241, 0.12); border-color: rgba(99, 102, 241, 0.4); color: #6366f1; }
.komuta-root .toggle-link { text-decoration: none; cursor: pointer; }
.komuta-root .toggle-link:hover { border-color: rgba(99, 102, 241, 0.6); }
.komuta-root .switch { width: 26px; height: 14px; background: #d6d3d1; border-radius: 999px; position: relative; flex-shrink: 0; }
.komuta-root .switch::after { content: ''; position: absolute; width: 10px; height: 10px; background: #78716c; border-radius: 50%; top: 2px; left: 2px; transition: 0.2s; }
.komuta-root .toggle.on .switch { background: #6366f1; }
.komuta-root .toggle.on .switch::after { background: #ffffff; left: 14px; }

/* CALENDAR BANNER */
.komuta-root .cal-banner {
  display: flex; align-items: center; gap: 14px;
  padding: 10px 16px; margin-bottom: 14px;
  background: linear-gradient(90deg, rgba(99, 102, 241, 0.12) 0%, rgba(99, 102, 241, 0.04) 100%);
  border: 1px solid rgba(99, 102, 241, 0.3);
  border-left: 3px solid #6366f1;
  border-radius: 6px;
  font-size: 12px;
}
.komuta-root .cal-banner-icon { font-size: 16px; flex-shrink: 0; }
.komuta-root .cal-banner-text { flex: 1; color: #44403c; line-height: 1.5; }
.komuta-root .cal-banner-text strong { color: #1c1917; font-weight: 600; }
.komuta-root .cal-banner-cta {
  flex-shrink: 0; padding: 5px 12px;
  background: rgba(99, 102, 241, 0.18); border: 1px solid rgba(99, 102, 241, 0.4);
  border-radius: 5px; font-size: 11px; color: #6366f1; cursor: pointer; font-weight: 500;
  text-decoration: none;
}

/* REEL TL banner (toggle aktif olduğunda) */
.komuta-root .demo-badge {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 3px 10px;
  background: rgba(217, 119, 6, 0.10);
  border: 1px solid rgba(217, 119, 6, 0.35);
  border-radius: 999px;
  font-size: 11px; font-weight: 600; color: #b45309;
  letter-spacing: 0.2px; white-space: nowrap;
}
.komuta-root .demo-badge-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: #d97706; flex-shrink: 0;
}

.komuta-root .reel-banner {
  display: flex; align-items: center; gap: 14px;
  padding: 10px 16px; margin-bottom: 14px;
  background: linear-gradient(90deg, rgba(147, 51, 234, 0.14) 0%, rgba(147, 51, 234, 0.04) 100%);
  border: 1px solid rgba(147, 51, 234, 0.35);
  border-left: 3px solid #9333ea;
  border-radius: 6px;
  font-size: 12px;
}
.komuta-root .reel-banner-icon { font-size: 16px; flex-shrink: 0; }
.komuta-root .reel-banner-text { flex: 1; color: #44403c; line-height: 1.5; }
.komuta-root .reel-banner-text strong { color: #1c1917; font-weight: 600; }
.komuta-root .reel-banner-cta {
  flex-shrink: 0; padding: 5px 12px;
  background: rgba(147, 51, 234, 0.18); border: 1px solid rgba(147, 51, 234, 0.4);
  border-radius: 5px; font-size: 11px; color: #9333ea; font-weight: 500;
  text-decoration: none;
}
.komuta-root .reel-banner-cta:hover { background: rgba(147, 51, 234, 0.28); }

/* KPI STRIP */
.komuta-root .kpi-strip-wrap { margin-bottom: 14px; }
.komuta-root .kpi-strip-head { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; padding: 0 2px; }
.komuta-root .kpi-strip-label { font-size: 10.5px; color: #6366f1; text-transform: uppercase; letter-spacing: 0.6px; font-weight: 700; }
.komuta-root .kpi-strip { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; }
.komuta-root .kpi-card {
  background: #ffffff; border: 1px solid #d6d3d1; border-radius: 10px;
  padding: 14px 16px; position: relative; overflow: hidden;
}
.komuta-root .kpi-card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--accent, #6366f1), transparent);
  opacity: 0.6;
}
.komuta-root .kpi-label {
  font-size: 10.5px; color: #78716c; text-transform: uppercase;
  letter-spacing: 0.6px; font-weight: 500; margin-bottom: 8px;
}
.komuta-root .kpi-value { font-size: 26px; font-weight: 700; letter-spacing: -0.6px; color: #1c1917; line-height: 1.1; }
.komuta-root .kpi-meta { display: flex; align-items: center; gap: 8px; margin-top: 6px; font-size: 11px; flex-wrap: wrap; }
.komuta-root .delta-up { color: #16a34a; }
.komuta-root .delta-down { color: #dc2626; }
.komuta-root .kpi-sub { color: #a8a29e; font-size: 10.5px; }

/* MAIN GRID */
.komuta-root .main-grid {
  display: grid; grid-template-columns: 1.3fr 1fr; gap: 14px; margin-bottom: 14px;
}
.komuta-root .panel {
  background: #ffffff; border: 1px solid #d6d3d1; border-radius: 10px;
  padding: 16px;
}
.komuta-root .panel-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.komuta-root .panel-title { font-size: 13px; font-weight: 600; color: #1c1917; display: flex; align-items: center; gap: 8px; }
.komuta-root .panel-title .icon { font-size: 14px; }
.komuta-root .panel-meta { font-size: 11px; color: #78716c; }
.komuta-root .map-panel-meta { display: flex; align-items: center; gap: 12px; }
.komuta-root .empty-note { color: #a8a29e; font-size: 12px; padding: 20px 0; text-align: center; }

/* TURKEY MAP */
.komuta-root .map-panel { position: relative; }
.komuta-root .map-svg { width: 100%; height: 360px; display: block; }
.komuta-root .map-legend {
  margin-top: 8px; padding: 8px 12px;
  background: #fafaf9; border: 1px solid #e7e5e4; border-radius: 6px;
  font-size: 10.5px; display: flex; gap: 16px; flex-wrap: wrap; align-items: center;
}
.komuta-root .map-panel .legend-item { display: flex; align-items: center; gap: 5px; color: #44403c; }
.komuta-root .map-panel .legend-dot { width: 8px; height: 8px; border-radius: 50%; }
.komuta-root .map-unplaced-pills {
  margin-top: 12px; padding: 10px 12px;
  background: rgba(120, 113, 108, 0.04); border: 1px solid #e7e5e4;
  border-radius: 6px;
}
.komuta-root .map-unplaced-label {
  font-size: 10px; color: #78716c; text-transform: uppercase;
  letter-spacing: 0.6px; font-weight: 600; margin-bottom: 8px;
}
.komuta-root .map-unplaced-row {
  display: flex; flex-wrap: wrap; gap: 6px;
}
.komuta-root .unplaced-pill {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 4px 10px; border-radius: 999px;
  background: #fafaf9; border: 1px solid #d6d3d1;
  font-size: 11px; color: #44403c;
  max-width: 100%; min-width: 0;
}
.komuta-root .unplaced-dot {
  width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0;
}
.komuta-root .unplaced-pill.tone-hot .unplaced-dot { background: #16a34a; }
.komuta-root .unplaced-pill.tone-medium .unplaced-dot { background: #6366f1; }
.komuta-root .unplaced-pill.tone-muted .unplaced-dot { background: #78716c; }
.komuta-root .unplaced-pill.tone-cool .unplaced-dot { background: #dc2626; }
.komuta-root .unplaced-pill.tone-hot { border-color: rgba(22, 163, 74, 0.3); }
.komuta-root .unplaced-pill.tone-medium { border-color: rgba(99, 102, 241, 0.3); }
.komuta-root .unplaced-pill.tone-cool { border-color: rgba(220, 38, 38, 0.3); }
.komuta-root .unplaced-name {
  font-weight: 500; max-width: 180px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.komuta-root .unplaced-num {
  color: #1c1917; font-weight: 600; font-feature-settings: "tnum"; font-size: 10.5px;
}
.komuta-root .unplaced-delta {
  font-feature-settings: "tnum"; font-weight: 600; font-size: 10.5px;
  padding: 1px 5px; border-radius: 3px;
}
.komuta-root .unplaced-pill.tone-hot .unplaced-delta {
  background: rgba(22, 163, 74, 0.15); color: #16a34a;
}
.komuta-root .unplaced-pill.tone-medium .unplaced-delta {
  background: rgba(99, 102, 241, 0.15); color: #6366f1;
}
.komuta-root .unplaced-pill.tone-muted .unplaced-delta {
  background: rgba(120, 113, 108, 0.15); color: #78716c;
}
.komuta-root .unplaced-pill.tone-cool .unplaced-delta {
  background: rgba(220, 38, 38, 0.15); color: #dc2626;
}

/* DONUT + TREND */
.komuta-root .donut-wrap { display: flex; align-items: center; gap: 18px; margin-bottom: 12px; }
.komuta-root .donut-svg { width: 130px; height: 130px; flex-shrink: 0; }
.komuta-root .channel-list { flex: 1; display: flex; flex-direction: column; gap: 6px; min-width: 0; }
.komuta-root .channel-row { display: flex; align-items: center; justify-content: space-between; padding: 4px 0; font-size: 12px; }
.komuta-root .channel-name { display: flex; align-items: center; gap: 8px; color: #44403c; min-width: 0; flex: 1; }
.komuta-root .channel-pip { width: 10px; height: 10px; border-radius: 2px; flex-shrink: 0; }
.komuta-root .channel-truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.komuta-root .channel-num { color: #1c1917; font-weight: 600; font-feature-settings: "tnum"; }
.komuta-root .channel-pct { color: #78716c; font-size: 11px; margin-left: 6px; font-feature-settings: "tnum"; }
.komuta-root .trend-mini { display: flex; gap: 4px; align-items: flex-end; height: 60px; padding: 8px 0; border-top: 1px solid #e7e5e4; }
.komuta-root .trend-bar { flex: 1; background: linear-gradient(180deg, #6366f1, #4f46e5); border-radius: 2px 2px 0 0; min-height: 6px; opacity: 0.85; }
.komuta-root .trend-bar.peak { background: linear-gradient(180deg, #a16207, #6366f1); opacity: 1; }
.komuta-root .trend-bar.ramazan { background: linear-gradient(180deg, #9333ea, #9333ea); opacity: 0.6; }
.komuta-root .trend-labels { display: flex; gap: 4px; font-size: 10px; color: #a8a29e; margin-top: 4px; }
.komuta-root .trend-labels span { flex: 1; text-align: center; }

/* CALENDAR SHRED */
.komuta-root .section-eyebrow {
  font-size: 10px; color: #a8a29e; text-transform: uppercase; letter-spacing: 0.8px;
  margin: 18px 0 8px 4px; font-weight: 600;
}
.komuta-root .calendar-track {
  position: relative; height: 130px;
  background: linear-gradient(180deg, #ffffff 0%, #ffffff 100%);
  border: 1px solid #d6d3d1; border-radius: 8px;
  padding: 12px 16px 8px 16px;
  margin-bottom: 14px;
}
.komuta-root .cal-month-grid { position: relative; display: grid; grid-template-columns: repeat(12, 1fr); height: 100%; }
.komuta-root .cal-month { border-right: 1px dashed #e7e5e4; position: relative; padding: 0 4px; }
.komuta-root .cal-month:last-child { border-right: none; }
.komuta-root .cal-month-label { font-size: 10px; color: #a8a29e; text-align: center; padding-top: 4px; font-weight: 500; }
.komuta-root .cal-month-label.current { color: #6366f1; font-weight: 700; }
.komuta-root .cal-trend-svg { position: absolute; left: 16px; right: 16px; top: 36px; height: 60px; width: calc(100% - 32px); }
.komuta-root .cal-legend-row { display: flex; gap: 16px; padding: 8px 4px 0 4px; font-size: 10.5px; color: #78716c; }
.komuta-root .legend-item { display: flex; align-items: center; gap: 5px; color: #44403c; }
.komuta-root .legend-dot { width: 8px; height: 8px; border-radius: 50%; }

/* CALENDAR V2 — mockup parity (HTML overlay + SVG hybrid, 3-row band area) */
.komuta-root .cal-v2 {
  position: relative;
  background: linear-gradient(180deg, #ffffff 0%, #ffffff 100%);
  border: 1px solid #d6d3d1;
  border-radius: 8px;
  padding: 10px 16px 6px 16px;
  margin-bottom: 14px;
  height: 168px;
  box-sizing: border-box;
}
.komuta-root .cal-v2-months {
  position: absolute;
  inset: 10px 16px auto 16px;
  height: 16px;
}
.komuta-root .cal-v2-month-lbl {
  position: absolute;
  transform: translateX(-50%);
  font-size: 10.5px;
  color: #a8a29e;
  font-weight: 500;
  white-space: nowrap;
}
.komuta-root .cal-v2-month-lbl.current { color: #6366f1; font-weight: 700; }

/* SVG: sadece eğriler ve bug\xfcn dot — bantlar yok */
.komuta-root .cal-v2-svg {
  position: absolute;
  left: 16px;
  right: 16px;
  top: 28px;
  width: calc(100% - 32px);
  height: 80px;
}

/* Overlay container: SVG'nin altında, 2-satır bant/marker alanı */
.komuta-root .cal-v2-overlay {
  position: absolute;
  inset: 28px 16px 24px 16px;
  pointer-events: none;
}

/* 2 satır: \xfcst (g\xf6rseller) + alt (etiketler aynı hizada) */
.komuta-root .cal-v2-visuals-row {
  position: absolute;
  left: 0;
  right: 0;
  top: 84px;
  height: 12px;
}
.komuta-root .cal-v2-labels-row {
  position: absolute;
  left: 0;
  right: 0;
  top: 100px;
  height: 16px;
}

.komuta-root .cal-v2-band-line {
  position: absolute;
  top: 4px;
  height: 4px;
  border-radius: 2px;
}
.komuta-root .cal-v2-band-line.summer  { background: #16a34a; }
.komuta-root .cal-v2-band-line.ramazan { background: #9333ea; }

.komuta-root .cal-v2-marker-dot {
  position: absolute;
  top: 2px;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #6366f1;
  border: 1px solid #ffffff;
  transform: translateX(-50%);
}

.komuta-root .cal-v2-lbl {
  position: absolute;
  top: 0;
  transform: translateX(-50%);
  font-size: 10px;
  font-weight: 600;
  white-space: nowrap;
  line-height: 14px;
}
.komuta-root .cal-v2-lbl.summer  { color: #16a34a; }
.komuta-root .cal-v2-lbl.ramazan { color: #9333ea; }
.komuta-root .cal-v2-lbl.marker  { color: #78716c; font-weight: 500; }
.komuta-root .cal-v2-lbl.today-badge {
  color: #dc2626;
  font-weight: 700;
  background: rgba(220, 38, 38, 0.12);
  border: 1px solid #dc2626;
  border-radius: 3px;
  padding: 0 5px;
  font-size: 9px;
  line-height: 14px;
  transform: translateX(-100%);
}

/* "Bug\xfcn" kırmızı yazı — eğri seviyesinde dot'un sağında */
.komuta-root .cal-v2-today-text {
  position: absolute;
  transform: translate(10px, -50%);
  font-size: 11px;
  font-weight: 700;
  color: #dc2626;
  white-space: nowrap;
  pointer-events: none;
}

.komuta-root .cal-v2-legend {
  position: absolute;
  left: 16px;
  right: 16px;
  bottom: 4px;
  display: flex;
  flex-wrap: wrap;
  gap: 14px;
  padding-top: 4px;
  border-top: 1px solid #e7e5e4;
  font-size: 10px;
  color: #44403c;
}
.komuta-root .cal-v2-dash {
  display: inline-block;
  width: 14px;
  height: 0;
  border-top: 1.5px dashed #78716c;
  vertical-align: middle;
}

/* BATTLE GRID */
.komuta-root .battle-grid { display: grid; grid-template-columns: 1fr 1.3fr; gap: 14px; margin-bottom: 14px; }
.komuta-root .upcoming {
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(147, 51, 234, 0.06));
  border: 1px solid #d6d3d1; border-radius: 10px; padding: 18px;
  position: relative; overflow: hidden;
}
.komuta-root .upcoming::before {
  content: ''; position: absolute; top: 0; right: 0; width: 100px; height: 100px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.2) 0%, transparent 70%);
  pointer-events: none;
}
.komuta-root .upcoming-eyebrow { font-size: 10.5px; color: #6366f1; text-transform: uppercase; letter-spacing: 0.8px; font-weight: 600; margin-bottom: 6px; position: relative; }
.komuta-root .upcoming-title { font-size: 22px; font-weight: 700; color: #1c1917; letter-spacing: -0.5px; margin-bottom: 4px; position: relative; }
.komuta-root .upcoming-date { font-size: 12px; color: #78716c; margin-bottom: 14px; position: relative; }
.komuta-root .upcoming-stat-grid { display: flex; flex-direction: column; gap: 4px; padding: 10px 12px; background: #fafaf9; border: 1px solid #d6d3d1; border-radius: 6px; margin-bottom: 12px; position: relative; }
.komuta-root .upcoming-stat-row { display: flex; justify-content: space-between; align-items: center; font-size: 11.5px; padding: 3px 0; }
.komuta-root .upcoming-stat-row .lbl { color: #78716c; }
.komuta-root .upcoming-stat-row .val { font-weight: 600; color: #16a34a; font-feature-settings: "tnum"; }
.komuta-root .upcoming-action-row { font-size: 12px; color: #44403c; line-height: 1.5; margin-bottom: 8px; position: relative; }
.komuta-root .upcoming-action-row .hi { color: #6366f1; font-weight: 600; }
.komuta-root .upcoming-window { display: flex; align-items: center; gap: 8px; padding: 8px 12px; background: rgba(220, 38, 38, 0.08); border: 1px solid rgba(220, 38, 38, 0.3); border-radius: 6px; font-size: 11.5px; color: #dc2626; font-weight: 500; position: relative; }

/* MATRIX */
.komuta-root .matrix-panel { padding: 16px; }
.komuta-root .matrix-table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
.komuta-root .matrix-table th { text-align: right; padding: 8px 10px; font-size: 10px; color: #78716c; font-weight: 600; text-transform: uppercase; letter-spacing: 0.4px; border-bottom: 1px solid #d6d3d1; }
.komuta-root .matrix-table th:first-child { text-align: left; }
.komuta-root .matrix-table th .sub { display: block; font-size: 9px; color: #a8a29e; font-weight: 500; text-transform: none; letter-spacing: 0; margin-top: 2px; }
.komuta-root .matrix-table th.current { color: #6366f1; }
.komuta-root .matrix-table td { padding: 7px 10px; border-bottom: 1px solid #e7e5e4; text-align: right; font-feature-settings: "tnum"; color: #44403c; }
.komuta-root .matrix-table td:first-child { text-align: left; color: #1c1917; font-weight: 500; }
.komuta-root .matrix-table tr:last-child td { border-bottom: none; }
.komuta-root .matrix-table tr:hover td { background: rgba(99, 102, 241, 0.04); }
.komuta-root .matrix-cell-current { background: rgba(99, 102, 241, 0.06); color: #6366f1 !important; font-weight: 600; }
.komuta-root .matrix-row-other td { color: #78716c; font-style: italic; }
.komuta-root .matrix-row-other td:first-child { color: #78716c; font-weight: 500; }
.komuta-root .matrix-row-total td { border-top: 1.5px solid #d6d3d1; background: #fafaf9; font-weight: 700; }
.komuta-root .matrix-row-total td:first-child { color: #1c1917; font-weight: 700; }
.komuta-root .delta-pill { display: inline-block; font-size: 10px; padding: 1px 5px; border-radius: 3px; margin-left: 4px; font-weight: 600; }
.komuta-root .delta-pill.up { background: rgba(22, 163, 74, 0.15); color: #16a34a; }
.komuta-root .delta-pill.down { background: rgba(220, 38, 38, 0.15); color: #dc2626; }

/* HEATMAP */
.komuta-root .heatmap-panel { padding: 16px; margin-bottom: 14px; }
.komuta-root .heatmap-grid { display: grid; gap: 4px; font-size: 11px; }
.komuta-root .heatmap-grid > .h-head { display: flex; align-items: center; justify-content: center; text-align: center; padding: 6px 4px; font-size: 10px; color: #78716c; text-transform: uppercase; letter-spacing: 0.4px; font-weight: 600; border-bottom: 1px solid #d6d3d1; min-height: 32px; }
.komuta-root .heatmap-grid .h-region { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 6px 6px; min-height: 48px; color: #1c1917; font-weight: 600; font-size: 10.5px; border-bottom: 1px solid #e7e5e4; gap: 2px; overflow: hidden; }
.komuta-root .heatmap-grid .h-region .reg-sub { font-size: 9px; color: #a8a29e; font-weight: 400; }
.komuta-root .heatmap-grid .h-cell { display: flex; align-items: center; justify-content: center; padding: 6px 4px; min-height: 48px; text-align: center; font-feature-settings: "tnum"; font-weight: 600; border-bottom: 1px solid #e7e5e4; border-radius: 4px; }
/* Heatmap paleti — 3 pastel ton: kırmızı (negatif) / gri (n\xf6tr) / yeşil (pozitif). */
.komuta-root .heatmap-grid .h-cell.cold,
.komuta-root .heatmap-grid .h-cell.cool { background: #fecaca; color: #991b1b; }
.komuta-root .heatmap-grid .h-cell.flat { background: #f5f5f4; color: #57534e; }
.komuta-root .heatmap-grid .h-cell.warm,
.komuta-root .heatmap-grid .h-cell.hot,
.komuta-root .heatmap-grid .h-cell.fire { background: #bbf7d0; color: #166534; }
.komuta-root .heatmap-grid .h-cell.h-cell-clickable { cursor: pointer; position: relative; transition: filter 0.15s, transform 0.15s, box-shadow 0.15s; }
.komuta-root .heatmap-grid .h-cell.h-cell-clickable:hover { filter: brightness(0.96) saturate(1.1); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(127, 29, 29, 0.18); }
.komuta-root .heatmap-grid .h-cell.h-cell-clickable:focus-visible { outline: 2px solid #6366f1; outline-offset: 2px; }
.komuta-root .heatmap-grid .h-avg { display: flex; align-items: center; justify-content: center; padding: 6px 4px; min-height: 48px; text-align: center; font-feature-settings: "tnum"; color: #6366f1; font-weight: 700; font-size: 11.5px; border-bottom: 1px solid #e7e5e4; border-radius: 4px; background: #fafaf9; }

/* BOTTOM GRID */
.komuta-root .bottom-grid { display: grid; grid-template-columns: 1fr 1.2fr; gap: 14px; }
.komuta-root .leaderboard .lb-row { display: grid; grid-template-columns: 22px 1fr 80px 90px; gap: 10px; padding: 8px 0; border-bottom: 1px solid #e7e5e4; align-items: center; font-size: 12px; }
.komuta-root .lb-row:last-child { border-bottom: none; }
.komuta-root .lb-rank { width: 22px; height: 22px; border-radius: 50%; background: #e7e5e4; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; color: #78716c; }
.komuta-root .lb-rank.top1 { background: linear-gradient(135deg, #6366f1, #4f46e5); color: #ffffff; }
.komuta-root .lb-rank.top2 { background: #a8a29e; color: #ffffff; }
.komuta-root .lb-rank.top3 { background: #92400e; color: #ffffff; }
.komuta-root .lb-name { color: #1c1917; }
.komuta-root .lb-region { color: #a8a29e; font-size: 10.5px; display: block; margin-top: 1px; }
.komuta-root .lb-bar { height: 6px; background: #e7e5e4; border-radius: 3px; overflow: hidden; }
.komuta-root .lb-bar-fill { height: 100%; background: linear-gradient(90deg, #16a34a, #16a34a); border-radius: 3px; }
.komuta-root .lb-bar-fill.warn { background: linear-gradient(90deg, #6366f1, #a16207); }
.komuta-root .lb-bar-fill.bad { background: linear-gradient(90deg, #dc2626, #b91c1c); }
.komuta-root .lb-pct { font-size: 11.5px; font-weight: 600; text-align: right; font-feature-settings: "tnum"; color: #1c1917; }
.komuta-root .lb-pct.bad { color: #dc2626; }
.komuta-root .lb-pct.warn { color: #6366f1; }

/* BRAND PORTFOLIO */
.komuta-root .brand-portfolio { padding: 16px; }
.komuta-root .bp-table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
.komuta-root .bp-table th { text-align: right; padding: 8px 10px; font-size: 10px; color: #78716c; font-weight: 600; text-transform: uppercase; letter-spacing: 0.4px; border-bottom: 1px solid #d6d3d1; }
.komuta-root .bp-table th:first-child { text-align: left; }
.komuta-root .bp-table th.current { color: #6366f1; }
.komuta-root .bp-table td { padding: 9px 10px; border-bottom: 1px solid #e7e5e4; font-feature-settings: "tnum"; color: #44403c; }
.komuta-root .bp-table td:first-child { color: #1c1917; font-weight: 500; }
.komuta-root .bp-table td.current { color: #6366f1; font-weight: 600; text-align: right; }
.komuta-root .bp-table td.right { text-align: right; }
.komuta-root .bp-table tr:last-child td { border-bottom: none; }
.komuta-root .bp-2yspark { display: inline-flex; gap: 2px; align-items: flex-end; height: 18px; }
.komuta-root .bp-2yspark .bar { width: 4px; background: #6366f1; border-radius: 1px; opacity: 0.7; }
.komuta-root .bp-2yspark .bar.last { opacity: 1; background: linear-gradient(180deg, #a16207, #6366f1); }
.komuta-root .bp-2yspark .bar.last.declining { background: linear-gradient(180deg, #dc2626, #b91c1c); }

/* TIER BADGES (PREM / LUX / CORE) */
.komuta-root .tier-badge {
  display: inline-block; font-size: 9px; padding: 1px 5px; border-radius: 3px;
  margin-left: 6px; vertical-align: middle; font-weight: 600;
  letter-spacing: 0.3px; text-transform: uppercase;
  border: 1px solid;
}
.komuta-root .tier-luxury {
  background: rgba(147, 51, 234, 0.12);
  color: #9333ea;
  border-color: rgba(147, 51, 234, 0.35);
}
.komuta-root .tier-premium {
  background: rgba(99, 102, 241, 0.15);
  color: #6366f1;
  border-color: rgba(99, 102, 241, 0.35);
}
.komuta-root .tier-core {
  background: rgba(99, 102, 241, 0.12);
  color: #6366f1;
  border-color: rgba(99, 102, 241, 0.3);
}

/* AI INSIGHT */
.komuta-root .ai-insight {
  margin-top: 14px; padding: 14px 18px;
  background: linear-gradient(90deg, rgba(99, 102, 241, 0.08) 0%, rgba(99, 102, 241, 0.02) 100%);
  border: 1px solid rgba(99, 102, 241, 0.25); border-left: 3px solid #6366f1;
  border-radius: 8px; display: flex; gap: 14px; align-items: flex-start;
}
.komuta-root .ai-icon {
  flex-shrink: 0; width: 30px; height: 30px; border-radius: 8px;
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  display: flex; align-items: center; justify-content: center;
  font-size: 16px; color: #ffffff;
}
.komuta-root .ai-text { flex: 1; min-width: 0; }
.komuta-root .ai-title { font-size: 11px; font-weight: 600; color: #6366f1; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
.komuta-root .ai-body { font-size: 12.5px; color: #44403c; line-height: 1.6; }
.komuta-root .ai-body strong { color: #1c1917; }
.komuta-root .ai-body p { margin-bottom: 8px; }

.komuta-root .footer-bar {
  margin-top: 14px; padding: 10px 16px; display: flex; justify-content: space-between;
  font-size: 11px; color: #a8a29e; flex-wrap: wrap; gap: 8px;
}

/* =============================================================================
 * DARK MODE — Komuta sayfasının light hardcoded hex'leri i\xe7in koyu varyant.
 * Mantık: light hardcoded değerler aşağıdaki gibi takipli override edilir;
 * surface'ler zinc, kart fill'leri koyu, fg yumuşak beyaz, kırmızı/yeşil
 * accent'ler hafif desature'lı.
 * ============================================================================= */
:root[data-theme="dark"] .komuta-root {
  background: var(--color-bg);
  color: var(--color-fg);
}
:root[data-theme="dark"] .komuta-root .panel,
:root[data-theme="dark"] .komuta-root .kpi-card,
:root[data-theme="dark"] .komuta-root .upcoming,
:root[data-theme="dark"] .komuta-root .ai-insight,
:root[data-theme="dark"] .komuta-root .channel-mix-card,
:root[data-theme="dark"] .komuta-root .cal-v2,
:root[data-theme="dark"] .komuta-root .filter-bar,
:root[data-theme="dark"] .komuta-root .demo-banner,
:root[data-theme="dark"] .komuta-root .reel-banner {
  background: var(--color-surface) !important;
  border-color: var(--color-border) !important;
  color: var(--color-fg) !important;
}
:root[data-theme="dark"] .komuta-root .komuta-eyebrow,
:root[data-theme="dark"] .komuta-root .section-eyebrow,
:root[data-theme="dark"] .komuta-root .panel-meta,
:root[data-theme="dark"] .komuta-root .kpi-label,
:root[data-theme="dark"] .komuta-root .kpi-strip-label,
:root[data-theme="dark"] .komuta-root .kpi-sub,
:root[data-theme="dark"] .komuta-root .kpi-meta {
  color: var(--color-muted) !important;
}
:root[data-theme="dark"] .komuta-root .panel-title,
:root[data-theme="dark"] .komuta-root h1,
:root[data-theme="dark"] .komuta-root h2,
:root[data-theme="dark"] .komuta-root h3,
:root[data-theme="dark"] .komuta-root .kpi-value,
:root[data-theme="dark"] .komuta-root .h-region {
  color: var(--color-fg) !important;
}
:root[data-theme="dark"] .komuta-root .empty-note,
:root[data-theme="dark"] .komuta-root .lb-region,
:root[data-theme="dark"] .komuta-root .upcoming-stat-row .lbl,
:root[data-theme="dark"] .komuta-root .channel-name {
  color: var(--color-fg-2) !important;
}
:root[data-theme="dark"] .komuta-root .lb-bar,
:root[data-theme="dark"] .komuta-root .trend-bar,
:root[data-theme="dark"] .komuta-root .channel-pip,
:root[data-theme="dark"] .komuta-root .legend-dot {
  /* color: kalır (data-driven), zemin sadece koyulaştırılır */
}
:root[data-theme="dark"] .komuta-root .lb-bar { background: var(--color-surface-2) !important; }
:root[data-theme="dark"] .komuta-root .trend-mini,
:root[data-theme="dark"] .komuta-root .trend-labels span {
  color: var(--color-muted) !important;
}
:root[data-theme="dark"] .komuta-root .delta-up { color: var(--color-good) !important; }
:root[data-theme="dark"] .komuta-root .delta-down { color: var(--color-bad) !important; }

/* Heatmap — pastel tonlar dark mode değişkenlerine işaret eder */
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell.cold,
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell.cool {
  background: var(--color-heat-neg-bg);
  color: var(--color-heat-neg-fg);
}
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell.flat {
  background: var(--color-heat-flat-bg);
  color: var(--color-heat-flat-fg);
}
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell.warm,
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell.hot,
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell.fire {
  background: var(--color-heat-pos-bg);
  color: var(--color-heat-pos-fg);
}
:root[data-theme="dark"] .komuta-root .heatmap-grid > .h-head {
  color: var(--color-muted) !important;
  border-bottom-color: var(--color-border-strong) !important;
}
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-avg {
  background: var(--color-surface-2) !important;
  color: var(--color-accent) !important;
  border-bottom-color: var(--color-border) !important;
}
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-region,
:root[data-theme="dark"] .komuta-root .heatmap-grid .h-cell {
  border-bottom-color: var(--color-border) !important;
}

/* AI insight kartı — dark zeminde indigo-soft tinted */
:root[data-theme="dark"] .komuta-root .ai-insight {
  background: linear-gradient(180deg, var(--color-accent-soft) 0%, var(--color-surface) 100%) !important;
}
:root[data-theme="dark"] .komuta-root .ai-title { color: var(--color-accent) !important; }
:root[data-theme="dark"] .komuta-root .ai-body { color: var(--color-fg-2) !important; }
:root[data-theme="dark"] .komuta-root .ai-body strong { color: var(--color-fg) !important; }

/* Footer ve filter chip'leri */
:root[data-theme="dark"] .komuta-root .footer-bar,
:root[data-theme="dark"] .komuta-root .filter-bar .filter-meta {
  color: var(--color-muted-2) !important;
}

/* TurkeyMap (eski stilize SVG dead code) ve calendar legend */
:root[data-theme="dark"] .komuta-root .cal-v2-legend {
  color: var(--color-muted) !important;
  border-top-color: var(--color-border) !important;
}
:root[data-theme="dark"] .komuta-root .cal-v2-month-lbl {
  color: var(--color-muted) !important;
}

/* Channel mix donut/list (eski TBLMUSTERIGRUP komponenti h\xe2l\xe2 render edilebilir) */
:root[data-theme="dark"] .komuta-root .channel-row {
  border-bottom-color: var(--color-border) !important;
}

/* ---- Geniş kapsamlı renk override'ı ------------------------------------- */
/* T\xfcm hardcoded "siyah text" (#1c1917) → fg */
:root[data-theme="dark"] .komuta-root .komuta-page-desc strong,
:root[data-theme="dark"] .komuta-root .cal-banner-text strong,
:root[data-theme="dark"] .komuta-root .demo-banner-text strong,
:root[data-theme="dark"] .komuta-root .reel-banner-text strong,
:root[data-theme="dark"] .komuta-root .kpi-value,
:root[data-theme="dark"] .komuta-root .panel-title,
:root[data-theme="dark"] .komuta-root .upcoming-title,
:root[data-theme="dark"] .komuta-root .lb-name,
:root[data-theme="dark"] .komuta-root .lb-pct,
:root[data-theme="dark"] .komuta-root .channel-num,
:root[data-theme="dark"] .komuta-root .matrix-table td:first-child {
  color: var(--color-fg) !important;
}

/* T\xfcm hardcoded "orta gri text" (#44403c) → fg-2 */
:root[data-theme="dark"] .komuta-root .komuta-page-desc,
:root[data-theme="dark"] .komuta-root .cal-banner-text,
:root[data-theme="dark"] .komuta-root .demo-banner-text,
:root[data-theme="dark"] .komuta-root .reel-banner-text,
:root[data-theme="dark"] .komuta-root .map-panel .legend-item,
:root[data-theme="dark"] .komuta-root .matrix-table td,
:root[data-theme="dark"] .komuta-root .upcoming-action-row,
:root[data-theme="dark"] .komuta-root .bp-table td,
:root[data-theme="dark"] .komuta-root .channel-name,
:root[data-theme="dark"] .komuta-root .legend-item,
:root[data-theme="dark"] .komuta-root .ai-body,
:root[data-theme="dark"] .komuta-root .toggle,
:root[data-theme="dark"] .komuta-root .toggle-pill {
  color: var(--color-fg-2) !important;
}

/* T\xfcm hardcoded light backgroundlar (#ffffff, #fafaf9) → surface / surface-2 */
:root[data-theme="dark"] .komuta-root .toggle,
:root[data-theme="dark"] .komuta-root .toggle-pill,
:root[data-theme="dark"] .komuta-root .switch,
:root[data-theme="dark"] .komuta-root .map-panel .legend,
:root[data-theme="dark"] .komuta-root .upcoming-stat-grid,
:root[data-theme="dark"] .komuta-root .channel-mix-card,
:root[data-theme="dark"] .komuta-root .matrix-card,
:root[data-theme="dark"] .komuta-root .bp-card {
  background: var(--color-surface-2) !important;
  border-color: var(--color-border) !important;
}

/* Toggle switch top'ı (knob) — dark zeminde de h\xe2l\xe2 beyaz */
:root[data-theme="dark"] .komuta-root .toggle.on .switch::after,
:root[data-theme="dark"] .komuta-root .switch::after {
  background: var(--color-fg) !important;
}

/* Matrix / bp tablo border'ları */
:root[data-theme="dark"] .komuta-root .matrix-table td,
:root[data-theme="dark"] .komuta-root .bp-table td,
:root[data-theme="dark"] .komuta-root .matrix-table th,
:root[data-theme="dark"] .komuta-root .bp-table th {
  border-bottom-color: var(--color-border) !important;
}

/* md16 — "Diğer" (katlanmış) ve "Toplam" (dip toplam) satırları */
:root[data-theme="dark"] .komuta-root .matrix-row-other td {
  color: var(--color-muted) !important;
}
:root[data-theme="dark"] .komuta-root .matrix-row-total td {
  background: var(--color-surface-2) !important;
  border-top-color: var(--color-border-strong, var(--color-border)) !important;
}
:root[data-theme="dark"] .komuta-root .matrix-row-total td:first-child {
  color: var(--color-fg) !important;
}
`;a.s(["default",0,p,"metadata",0,{title:"Komuta · Insider"}])}];

//# sourceMappingURL=apps_dashboard_1i0sxa-._.js.map