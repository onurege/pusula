module.exports=[73478,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);let e=/^\d{4}-\d{2}-\d{2}$/,f=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];a.s(["GlobalDonemFilter",0,function(){let a=(0,c.useRouter)(),g=(0,c.usePathname)(),h=(0,c.useSearchParams)(),[i,j]=(0,d.useTransition)(),k=h?.get("from")??"",l=h?.get("to")??"",m=(h?.get("donem")??"").toLowerCase(),n=e.test(k)&&e.test(l),o=n?"serbest":m&&"son30g"!==m?m:"son30g",[p,q]=(0,d.useState)(n),[r,s]=(0,d.useState)(k),[t,u]=(0,d.useState)(l),v=e.test(r),w=e.test(t),x=v&&w&&r>t,y=v&&w&&!x;function z(b){let c=new URLSearchParams(h?.toString()??"");b(c);let d=c.toString();j(()=>a.push(`${g}${d?`?${d}`:""}`))}return(0,b.jsxs)("div",{className:"donem-filter",children:[(0,b.jsx)("span",{className:"lbl",children:"Dönem"}),(0,b.jsxs)("div",{className:"chips",children:[f.map(a=>(0,b.jsx)("button",{type:"button",className:`chip ${o===a.key?"on":""}`,onClick:()=>{var b;return b=a.key,void(q(!1),z(a=>{a.delete("from"),a.delete("to"),"son30g"===b?a.delete("donem"):a.set("donem",b)}))},disabled:i,children:a.label},a.key)),(0,b.jsx)("button",{type:"button",className:`chip ${"serbest"===o||p?"on":""}`,onClick:()=>q(a=>!a),disabled:i,children:"Serbest"})]}),(p||"serbest"===o)&&(0,b.jsxs)("div",{className:"range",children:[(0,b.jsx)("input",{type:"date",value:r,max:t||void 0,onChange:a=>s(a.target.value),disabled:i,className:"inp","aria-label":"Başlangıç tarihi"}),(0,b.jsx)("span",{className:"sep",children:"–"}),(0,b.jsx)("input",{type:"date",value:t,min:r||void 0,onChange:a=>u(a.target.value),disabled:i,className:"inp","aria-label":"Bitiş tarihi"}),(0,b.jsx)("button",{type:"button",className:"apply",onClick:function(){y&&z(a=>{a.delete("donem"),a.set("from",r),a.set("to",t)})},disabled:i||!y,children:"Uygula"}),x&&(0,b.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),i&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},97593,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);a.s(["IskontoFilterBar",0,function({distributors:a,selectedDistId:e,dateFrom:f,dateTo:g,showDateRange:h=!0}){let i=(0,c.useRouter)(),j=(0,c.usePathname)(),k=(0,c.useSearchParams)(),[l,m]=(0,d.useTransition)(),[n,o]=(0,d.useState)(f??""),[p,q]=(0,d.useState)(g??"");function r(a){let b=new URLSearchParams(k?.toString()??"");a(b);let c=b.toString();m(()=>{i.push(`${j}${c?`?${c}`:""}`)})}let s=!!(f&&g),t=!!(n&&p&&n<=p);return(0,b.jsxs)("div",{className:"iskonto-filterbar",children:[(0,b.jsxs)("div",{className:"iskonto-filter-field",children:[(0,b.jsx)("label",{htmlFor:"iskonto-dist-select",className:"lbl",children:"Distribütör"}),(0,b.jsxs)("select",{id:"iskonto-dist-select",value:e??"all",onChange:function(a){let b=a.target.value;r(a=>{""===b||"all"===b?a.delete("distId"):a.set("distId",b)})},disabled:l,className:"sel",children:[(0,b.jsx)("option",{value:"all",children:"Tümü — portföy toplamı"}),a.map(a=>(0,b.jsx)("option",{value:a.id,children:a.ad},a.id))]})]}),h&&(0,b.jsxs)("form",{className:"iskonto-filter-field iskonto-date-field",onSubmit:function(a){a.preventDefault();let b=n.trim(),c=p.trim();r(a=>{b&&c?(a.set("from",b),a.set("to",c)):(a.delete("from"),a.delete("to"))})},children:[(0,b.jsx)("label",{htmlFor:"iskonto-from",className:"lbl",children:"Tarih Aralığı"}),(0,b.jsxs)("div",{className:"iskonto-date-row",children:[(0,b.jsx)("input",{id:"iskonto-from",type:"date",value:n,max:p||void 0,onChange:a=>o(a.target.value),className:"date-input","aria-label":"Başlangıç tarihi"}),(0,b.jsx)("span",{className:"sep",children:"–"}),(0,b.jsx)("input",{id:"iskonto-to",type:"date",value:p,min:n||void 0,onChange:a=>q(a.target.value),className:"date-input","aria-label":"Bitiş tarihi"}),(0,b.jsx)("button",{type:"submit",className:"btn-apply",disabled:l||!t,children:"Uygula"}),s&&(0,b.jsx)("button",{type:"button",className:"btn-clear",onClick:function(){o(""),q(""),r(a=>{a.delete("from"),a.delete("to")})},disabled:l,children:"Varsayılana dön"})]})]}),l&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .iskonto-filterbar {
          display: flex;
          align-items: flex-end;
          gap: 20px;
          flex-wrap: wrap;
          padding: 12px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .iskonto-filter-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .iskonto-filterbar .lbl {
          font-size: 10.5px;
          font-weight: 650;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .iskonto-filterbar .sel {
          min-width: 240px;
          padding: 7px 10px;
          font-size: 13px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
          cursor: pointer;
        }
        .iskonto-date-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .iskonto-filterbar .date-input {
          padding: 6px 8px;
          font-size: 12.5px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
        }
        .iskonto-filterbar .sep { color: var(--color-muted); font-size: 12px; }
        .iskonto-filterbar .btn-apply,
        .iskonto-filterbar .btn-clear {
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 600;
          border-radius: 6px;
          cursor: pointer;
          font-family: inherit;
          white-space: nowrap;
        }
        .iskonto-filterbar .btn-apply {
          background: var(--color-accent);
          color: var(--color-on-accent, #fff);
          border: 1px solid var(--color-accent);
        }
        .iskonto-filterbar .btn-apply:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .iskonto-filterbar .btn-clear {
          background: var(--color-surface);
          color: var(--color-muted);
          border: 1px solid var(--color-border);
        }
        .iskonto-filterbar .sel:disabled,
        .iskonto-filterbar .date-input:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .iskonto-filterbar .sel:focus,
        .iskonto-filterbar .date-input:focus {
          outline: 2px solid var(--color-accent);
          outline-offset: 2px;
        }
        .iskonto-filterbar .loading {
          font-size: 11px;
          color: var(--color-muted);
          font-style: italic;
        }
      `}})]})}])}];

//# sourceMappingURL=apps_dashboard_components_v3_05vbms0._.js.map