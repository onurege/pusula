module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},71306,(a,b,c)=>{b.exports=a.r(18622)},79847,a=>{a.n(a.i(3343))},9185,a=>{a.n(a.i(29432))},72842,a=>{a.n(a.i(75164))},54897,a=>{a.n(a.i(30106))},56157,a=>{a.n(a.i(18970))},94331,a=>{a.n(a.i(60644))},15988,a=>{a.n(a.i(56952))},25766,a=>{a.n(a.i(77341))},29725,a=>{a.n(a.i(94290))},90833,a=>{a.n(a.i(46994))},5785,a=>{a.n(a.i(90588))},74793,a=>{a.n(a.i(33169))},85826,a=>{a.n(a.i(37111))},21565,a=>{a.n(a.i(41763))},65911,a=>{a.n(a.i(8950))},25128,a=>{a.n(a.i(91562))},40781,a=>{a.n(a.i(49670))},69411,a=>{a.n(a.i(75700))},63081,a=>{a.n(a.i(276))},62837,a=>{a.n(a.i(67361))},34607,a=>{a.n(a.i(11614))},96338,a=>{a.n(a.i(21751))},50642,a=>{a.n(a.i(12213))},32242,a=>{a.n(a.i(22693))},88530,a=>{a.n(a.i(10531))},8583,a=>{a.n(a.i(1082))},38534,a=>{a.n(a.i(98175))},70408,a=>{a.n(a.i(9095))},22922,a=>{a.n(a.i(96772))},78294,a=>{a.n(a.i(71717))},16625,a=>{a.n(a.i(85034))},88648,a=>{a.n(a.i(68113))},51914,a=>{a.n(a.i(66482))},25466,a=>{a.n(a.i(91505))},24580,a=>{"use strict";var b=a.i(7997),c=a.i(93105);a.s(["V3PageHeader",0,function({eyebrow:a,title:d,description:e,dataNote:f,generatedAt:g,contentKey:h,descKey:i}){let j=(0,c.getContentMap)(),k=h?(0,c.t)(j,h,d):d,l=i?(0,c.t)(j,i,e):e,m=g?new Date(g).toLocaleString("tr-TR",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}):null;return(0,b.jsxs)("header",{className:"v3-head",children:[(0,b.jsxs)("div",{className:"v3-head-main",children:[(0,b.jsxs)("div",{className:"v3-eyebrow",children:[(0,b.jsx)("span",{className:"v3-eyebrow-dot"}),a]}),(0,b.jsx)("h1",{className:"v3-title",children:k}),(0,b.jsx)("p",{className:"v3-desc",children:l})]}),(f||m)&&(0,b.jsxs)("aside",{className:"v3-meta",children:[f&&(0,b.jsx)("div",{className:"v3-meta-note",children:f}),m&&(0,b.jsxs)("div",{className:"v3-meta-ts",children:["son güncelleme · ",m]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 24px; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--color-border); flex-wrap: wrap; }
        .v3-head-main { min-width: 280px; flex: 1; }
        .v3-eyebrow { display: inline-flex; align-items: center; gap: 6px; font-size: 10.5px; font-weight: 600; color: var(--color-accent); letter-spacing: 0.06em; text-transform: uppercase; }
        .v3-eyebrow-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--color-accent); }
        .v3-title { font-size: 28px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.025em; margin: 4px 0 6px; line-height: 1.15; }
        .v3-desc { font-size: 13.5px; color: var(--color-muted); margin: 0; max-width: 720px; line-height: 1.55; }
        .v3-meta { font-size: 11px; color: var(--color-muted-2); text-align: right; max-width: 280px; }
        .v3-meta-note { line-height: 1.5; }
        .v3-meta-ts { margin-top: 6px; opacity: 0.8; font-variant-numeric: tabular-nums; }
      `}})]})}])},64240,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},790,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/app-dir/link.js <module evaluation>"))},84707,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/app-dir/link.js"))},97647,a=>{"use strict";a.i(790);var b=a.i(84707);a.n(b)},95936,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={default:function(){return i},useLinkStatus:function(){return h.useLinkStatus}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f=a.r(64240),g=a.r(7997),h=f._(a.r(97647));function i(a){let b=a.legacyBehavior,c="string"==typeof a.children||"number"==typeof a.children||"string"==typeof a.children?.type,d=a.children?.type?.$$typeof===Symbol.for("react.client.reference");return!b||c||d||(a.children?.type?.$$typeof===Symbol.for("react.lazy")?console.error("Using a Lazy Component as a direct child of `<Link legacyBehavior>` from a Server Component is not supported. If you need legacyBehavior, wrap your Lazy Component in a Client Component that renders the Link's `<a>` tag."):console.error("Using a Server Component as a direct child of `<Link legacyBehavior>` is not supported. If you need legacyBehavior, wrap your Server Component in a Client Component that renders the Link's `<a>` tag.")),(0,g.jsx)(h.default,{...a})}("function"==typeof c.default||"object"==typeof c.default&&null!==c.default)&&void 0===c.default.__esModule&&(Object.defineProperty(c.default,"__esModule",{value:!0}),Object.assign(c.default,c),b.exports=c.default)},8174,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/node_modules/lucide-react/dist/esm/Icon.mjs <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/node_modules/lucide-react/dist/esm/Icon.mjs <module evaluation>","default")},90697,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/node_modules/lucide-react/dist/esm/Icon.mjs from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/node_modules/lucide-react/dist/esm/Icon.mjs","default")},53808,a=>{"use strict";a.i(8174);var b=a.i(90697);a.n(b)},44760,a=>{"use strict";var b=a.i(7997),c=a.i(95936),d=a.i(717);let e=a=>{let b=a.replace(/^([A-Z])|[\s-_]+(\w)/g,(a,b,c)=>c?c.toUpperCase():b.toLowerCase());return b.charAt(0).toUpperCase()+b.slice(1)};var f=a.i(53808);let g=(a,b)=>{let c=(0,d.forwardRef)(({className:c,...g},h)=>(0,d.createElement)(f.default,{ref:h,iconNode:b,className:((...a)=>a.filter((a,b,c)=>!!a&&""!==a.trim()&&c.indexOf(a)===b).join(" ").trim())(`lucide-${e(a).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${a}`,c),...g}));return c.displayName=e(a),c},h=g("chart-pie",[["path",{d:"M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",key:"pzmjnu"}],["path",{d:"M21.21 15.89A10 10 0 1 1 8 2.83",key:"k2fpak"}]]),i=g("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),j=g("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]),k=g("package",[["path",{d:"M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",key:"1a0edw"}],["path",{d:"M12 22V12",key:"d0xqtd"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}]]),l=g("truck",[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]]),m=g("target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]),n=g("wallet",[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]);var o=a.i(24580);a.i(2614);var p=a.i(12261),q=a.i(93105);let r=[{no:"01",href:"/v3/yonetim-kurulu",title:"Yönetim Kurulu",desc:"Top 10/20/50 müşteri, marka katkıları, iskonto KPI. CEO sabah görünümü.",icon:h,accent:"#6366f1",ready:!0},{no:"02",href:"/v3/satis-performans",title:"Satış Performans",desc:"Distribütör/ekip/temsilci, drop size, aktif + yeni müşteri kazanımı.",icon:i,accent:"#16a34a",ready:!0},{no:"03",href:"/v3/musteri-segmentasyon",title:"Müşteri Segmentasyon",desc:"3 ayrı segment boyutu yan yana — kanal × ciro × iskonto cross.",icon:j,accent:"#0891b2",ready:!0},{no:"04",href:"/v3/marka-sku",title:"Marka & SKU",desc:"Marka penetrasyonu, Top 5 SKU, stratejik marka özel zoom panelleri.",icon:k,accent:"#9333ea",ready:!0},{no:"05",href:"/v3/stok-tukenme",title:"Stok Tükenme",desc:"SKU bazında kalan gün, tahmini tükenme tarihi ve miktar bazlı 90g devir.",icon:k,accent:"#0f766e",ready:!0},{no:"06",href:"/v3/saha-operasyon",title:"Saha Operasyon",desc:"Günlük/haftalık ziyaret trendleri, kapsama, sipariş dönüşümü.",icon:l,accent:"#d97706",ready:!0},{no:"07",href:"/v3/aktivasyon-risk",title:"Aktivasyon & Risk",desc:"Pasifleşen müşteri, stratejik marka sessizliği, yeniden kazanım.",icon:m,accent:"#dc2626",ready:!0},{no:"08",href:"/v3/ticari-yatirim",title:"Ticari Yatırım & İskonto",desc:"İskonto harcaması, marka × etkinlik, müşteri/segment ROI.",icon:n,accent:"#b45309",ready:!0}];a.s(["default",0,function(){let a=(0,p.getTenantConfig)(),d=(0,q.getContentMap)();return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(o.V3PageHeader,{eyebrow:"V3 · Özet",title:`${a.displayName} — ${(0,q.t)(d,"page.ozet.title","Yönetim Paneli")}`,description:"Sekiz dashboard, sekiz soru: yönetici özeti, satış performansı, müşteri segmenti, marka katkısı, stok tükenme, saha operasyonu, müşteri sağlığı ve ticari yatırım. Her kart kendi sayfasında açılır."}),(0,b.jsx)("div",{className:"v3-card-grid",children:r.map(a=>(0,b.jsxs)(c.default,{href:a.href,className:`v3-card ${a.ready?"ready":""}`,children:[(0,b.jsx)("div",{className:"v3-card-num",children:a.no}),(0,b.jsx)("div",{className:"v3-card-icon",style:{color:a.accent},children:(0,b.jsx)(a.icon,{size:22,strokeWidth:1.7})}),(0,b.jsx)("div",{className:"v3-card-title",children:a.title}),(0,b.jsx)("div",{className:"v3-card-desc",children:a.desc}),(0,b.jsxs)("div",{className:"v3-card-foot",children:[a.ready?(0,b.jsx)("span",{className:"v3-card-badge ready",children:"Hazır"}):(0,b.jsx)("span",{className:"v3-card-badge soon",children:"Hazırlanıyor"}),(0,b.jsx)("span",{className:"v3-card-arrow",children:"→"})]})]},a.href))}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .v3-card-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 14px;
        }
        .v3-card {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 12px;
          padding: 18px 18px 14px;
          display: flex;
          flex-direction: column;
          gap: 8px;
          text-decoration: none;
          color: inherit;
          transition: border-color 0.15s, transform 0.1s;
          position: relative;
        }
        .v3-card:hover {
          border-color: var(--color-accent);
          transform: translateY(-1px);
        }
        .v3-card.ready { border-color: var(--color-accent-soft); }
        .v3-card-num {
          font-size: 10.5px;
          font-weight: 600;
          color: var(--color-muted);
          letter-spacing: 0.06em;
        }
        .v3-card-icon {
          margin-top: 2px;
          margin-bottom: 4px;
        }
        .v3-card-title {
          font-size: 16px;
          font-weight: 600;
          color: var(--color-fg);
          letter-spacing: -0.01em;
          line-height: 1.2;
        }
        .v3-card-desc {
          font-size: 12.5px;
          color: var(--color-muted);
          line-height: 1.5;
          flex: 1;
        }
        .v3-card-foot {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: 6px;
        }
        .v3-card-badge {
          font-size: 9.5px;
          font-weight: 600;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          padding: 3px 7px;
          border-radius: 4px;
        }
        .v3-card-badge.ready {
          background: var(--color-accent-soft);
          color: var(--color-accent);
        }
        .v3-card-badge.soon {
          background: var(--color-surface-2);
          color: var(--color-muted);
          border: 1px solid var(--color-border);
        }
        .v3-card-arrow {
          color: var(--color-muted-2);
          font-size: 14px;
          transition: transform 0.15s;
        }
        .v3-card:hover .v3-card-arrow {
          transform: translateX(2px);
          color: var(--color-accent);
        }
      `}})]})},"metadata",0,{title:"V3 Özet · Insider"}],44760)},33733,a=>{a.n(a.i(44760))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1t_he7s._.js.map