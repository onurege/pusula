module.exports=[67848,a=>{"use strict";a.s(["MarkaSkuExportButton",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call MarkaSkuExportButton() from the server but MarkaSkuExportButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/marka/ExportButton.tsx <module evaluation>","MarkaSkuExportButton")},42905,a=>{"use strict";a.s(["MarkaSkuExportButton",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call MarkaSkuExportButton() from the server but MarkaSkuExportButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/marka/ExportButton.tsx","MarkaSkuExportButton")},27052,a=>{"use strict";a.i(67848);var b=a.i(42905);a.n(b)},9385,a=>{"use strict";var b=a.i(7997),c=a.i(17239),d=a.i(93105);a.i(2614);var e=a.i(12261),f=a.i(24580),g=a.i(1980),h=a.i(30590),i=a.i(1381);function j({rows:a,periodLabel:c="Son 30g"}){if((0,d.panelHidden)("panel.marka.portfolio"))return null;let e=a.filter(a=>!a.isOther&&!a.isTotal),f=Math.max(1,...e.map(a=>a.ciro)),g=e.filter(a=>a.isStratejik),h=g.reduce((a,b)=>a+b.payPct,0);return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.marka.portfolio","Marka Portföyü")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[c," · Top ",e.length," marka net ciroya göre ·"," ",g.length>0?(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("span",{className:"strat-dot"})," ",g.length," stratejik marka portföyün ",(0,b.jsxs)("strong",{children:["%",h.toFixed(1)]}),"'sini taşıyor"]}):"stratejik marka tanımı yok"]})]})}),(0,b.jsx)("div",{className:"v3-bars",children:a.map(a=>{let c=a.isTotal?"total":a.isOther?"other":a.isStratejik?"strat":"";return(0,b.jsxs)("div",{className:`bar-row ${c}`,children:[(0,b.jsxs)("div",{className:"bar-label",title:a.marka,children:[!a.isOther&&!a.isTotal&&a.isStratejik&&(0,b.jsx)("span",{className:"strat-dot"}),!a.isOther&&!a.isTotal&&(0,b.jsxs)("span",{className:"bar-rank",children:["#",a.rank]}),(0,b.jsx)("span",{className:"bar-name",children:a.marka})]}),(0,b.jsx)("div",{className:"bar-track",children:!a.isTotal&&(0,b.jsx)("div",{className:"bar-fill",style:{width:`${Math.min(a.ciro/f*100,100)}%`}})}),(0,b.jsxs)("div",{className:"bar-meta",children:[(0,b.jsxs)("span",{className:"bar-val",children:["₺",(0,i.formatCompact)(a.ciro)]}),(0,b.jsxs)("span",{className:"bar-pay",children:["%",a.payPct.toFixed(1)]}),(0,b.jsxs)("span",{className:"bar-cust",children:[a.musteriSayi.toLocaleString("tr-TR")," müş"]}),(0,b.jsxs)("span",{className:"bar-fat",children:[a.faturaSayisi.toLocaleString("tr-TR")," fat"]})]})]},a.markaKod||a.marka)})}),(0,b.jsxs)("div",{className:"v3-bars-legend",children:[(0,b.jsxs)("span",{children:[(0,b.jsx)("span",{className:"strat-dot"})," stratejik marka"]}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsx)("span",{children:"net ciro"}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsx)("span",{children:"portföy payı"}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsx)("span",{children:"distinct müşteri"}),(0,b.jsx)("span",{className:"sep",children:"·"}),(0,b.jsx)("span",{children:"fatura sayısı"})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; display: inline-flex; align-items: center; gap: 4px; flex-wrap: wrap; }
        .strat-dot { display: inline-block; width: 8px; height: 8px; background: var(--color-accent); border-radius: 50%; flex-shrink: 0; }
        .v3-bars { display: flex; flex-direction: column; gap: 5px; }
        .bar-row { display: grid; grid-template-columns: 200px 1fr 280px; align-items: center; gap: 12px; padding: 6px 0; font-size: 12.5px; }
        .bar-row:hover { background: var(--color-surface-2); margin: 0 -8px; padding: 6px 8px; border-radius: 6px; }
        .bar-row.strat .bar-fill { background: var(--color-accent); }
        .bar-row.other { border-top: 1px solid var(--color-border); }
        .bar-row.other .bar-name { font-style: italic; color: var(--color-muted); }
        .bar-row.other .bar-meta { opacity: 0.75; }
        .bar-row.other .bar-fill { background: var(--color-muted-2); opacity: 0.4; }
        .bar-row.total { border-top: 2px solid var(--color-fg); margin-top: 2px; }
        .bar-row.total .bar-name { font-weight: 700; color: var(--color-fg); }
        .bar-row.total .bar-val { font-weight: 700; color: var(--color-fg); }
        .bar-row.total .bar-pay, .bar-row.total .bar-cust, .bar-row.total .bar-fat { color: var(--color-fg); font-weight: 600; }
        .bar-label { display: inline-flex; align-items: center; gap: 6px; overflow: hidden; }
        .bar-rank { font-size: 10.5px; color: var(--color-muted-2); font-variant-numeric: tabular-nums; font-weight: 500; min-width: 22px; }
        .bar-name { font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .bar-track { height: 18px; background: var(--color-surface-2); border-radius: 4px; overflow: hidden; position: relative; }
        .bar-fill { height: 100%; background: var(--color-muted-2); border-radius: 4px; opacity: 0.75; transition: width 0.3s ease-out; }
        .bar-meta { display: inline-flex; align-items: baseline; justify-content: flex-end; gap: 10px; font-variant-numeric: tabular-nums; }
        .bar-val { color: var(--color-fg); font-weight: 600; min-width: 70px; text-align: right; }
        .bar-pay { color: var(--color-muted); font-size: 11.5px; min-width: 42px; text-align: right; }
        .bar-cust { color: var(--color-muted-2); font-size: 11.5px; min-width: 60px; text-align: right; }
        .bar-fat { color: var(--color-muted-2); font-size: 11.5px; min-width: 56px; text-align: right; }
        .v3-bars-legend { margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--color-border); font-size: 11px; color: var(--color-muted-2); display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .v3-bars-legend .sep { opacity: 0.4; }
      `}})]})}function k({rows:a,periodLabel:c="Son 30g"}){if((0,d.panelHidden)("panel.marka.topsku"))return null;let e=a.filter(a=>!a.isOther&&!a.isTotal),f=e.reduce((a,b)=>a+b.payPct,0);return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.marka.topsku","Top 10 SKU")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[c," net ciro · İlk 10 ürün portföyün",(0,b.jsxs)("strong",{children:[" %",f.toFixed(1)]}),"'ini taşıyor"]})]})}),(0,b.jsx)("div",{className:"v3-table-wrap",children:(0,b.jsxs)("table",{className:"v3-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"SKU"}),(0,b.jsx)("th",{children:"Marka"}),(0,b.jsx)("th",{className:"num",children:"Ciro (30g)"}),(0,b.jsx)("th",{className:"num",children:"Miktar"}),(0,b.jsx)("th",{className:"num",children:"Müşteri"}),(0,b.jsx)("th",{className:"num",children:"Pay"})]})}),(0,b.jsx)("tbody",{children:0===e.length?(0,b.jsx)("tr",{children:(0,b.jsx)("td",{colSpan:7,className:"empty",children:"Son 30 günde SKU verisi yok."})}):a.map(a=>{let c=a.isOther||a.isTotal,d=a.isTotal?"total-row":a.isOther?"other-row":"";return(0,b.jsxs)("tr",{className:d,children:[(0,b.jsx)("td",{className:"rank",children:c?"":a.rank}),(0,b.jsx)("td",{className:"ad",title:a.ad,children:a.ad.length>60?a.ad.slice(0,57)+"…":a.ad}),(0,b.jsx)("td",{children:c?null:(0,b.jsxs)("span",{className:`brand-chip ${a.isStratejik?"strat":""}`,title:a.isStratejik?"Stratejik marka":void 0,children:[a.isStratejik&&(0,b.jsx)("span",{className:"strat-dot"}),a.marka||"—"]})}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,i.formatCompact)(a.ciro)]}),(0,b.jsx)("td",{className:"num",children:a.miktar.toLocaleString("tr-TR",{maximumFractionDigits:0})}),(0,b.jsx)("td",{className:"num",children:a.musteriSayi.toLocaleString("tr-TR")}),(0,b.jsxs)("td",{className:"num pay",children:[!a.isTotal&&(0,b.jsx)("span",{className:"pay-bar",style:{width:`${Math.min(12*a.payPct,100)}%`}}),(0,b.jsxs)("span",{className:"pay-val",children:["%",a.payPct.toFixed(2)]})]})]},a.urunKod)})})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .v3-table-wrap { overflow-x: auto; margin: 0 -4px; }
        .v3-table { width: 100%; border-collapse: collapse; font-size: 12.5px; min-width: 720px; }
        .v3-table thead th { text-align: left; padding: 8px 10px; font-size: 10.5px; font-weight: 600; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.04em; border-bottom: 1px solid var(--color-border); }
        .v3-table thead th.num { text-align: right; }
        .v3-table tbody tr { border-bottom: 1px solid var(--color-border); }
        .v3-table tbody tr:hover { background: var(--color-surface-2); }
        .v3-table td { padding: 9px 10px; color: var(--color-fg); }
        .v3-table td.rank { font-weight: 600; color: var(--color-muted); font-variant-numeric: tabular-nums; width: 30px; }
        .v3-table td.ad { font-weight: 500; max-width: 360px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .v3-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
        .v3-table td.empty { text-align: center; color: var(--color-muted); padding: 24px; }
        .v3-table tbody tr.other-row td { font-style: italic; color: var(--color-muted); border-top: 1px solid var(--color-border); }
        .v3-table tbody tr.other-row:hover { background: transparent; }
        .v3-table tbody tr.total-row td { font-weight: 700; color: var(--color-fg); border-top: 2px solid var(--color-fg); }
        .v3-table tbody tr.total-row:hover { background: transparent; }
        .v3-table td.pay { position: relative; min-width: 90px; }
        .pay-bar { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); height: 4px; background: var(--color-accent-soft); border-radius: 2px; z-index: 0; opacity: 0.7; }
        .pay-val { position: relative; z-index: 1; color: var(--color-fg-2); font-weight: 500; }
        .brand-chip { display: inline-flex; align-items: center; gap: 4px; padding: 2px 7px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: 999px; font-size: 11px; font-weight: 500; color: var(--color-fg-2); }
        .brand-chip.strat { background: var(--color-accent-soft, rgba(159, 225, 203, 0.18)); border-color: var(--color-accent); color: var(--color-fg); }
        .strat-dot { display: inline-block; width: 6px; height: 6px; background: var(--color-accent); border-radius: 50%; }
      `}})]})}function l({rows:a,aktifMusteriToplam:c,periodLabel:e="Son 30g"}){if((0,d.panelHidden)("panel.marka.penetration"))return null;let f=a.filter(a=>!a.isOther&&!a.isTotal),g=f.length>0,h=Math.max(1,...f.map(a=>a.penetrasyonPct));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,d.panelTitle)("panel.marka.penetration","Marka Penetrasyonu")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[e," aktif portföy:"," ",(0,b.jsx)("strong",{children:c.toLocaleString("tr-TR")})," ","müşteri · Markaların portföye yayılım oranı"]})]})}),(0,b.jsxs)("div",{className:"pen-bars",children:[!g&&(0,b.jsx)("div",{className:"empty",children:"Son 30 günde marka penetrasyon verisi yok."}),g&&a.map(a=>{let d=a.isTotal?"total":a.isOther?"other":a.isStratejik?"strat":"";return(0,b.jsxs)("div",{className:`pen-row ${d}`,children:[(0,b.jsxs)("div",{className:"pen-name",title:a.marka,children:[!a.isOther&&!a.isTotal&&a.isStratejik&&(0,b.jsx)("span",{className:"strat-dot"}),!a.isOther&&!a.isTotal&&(0,b.jsxs)("span",{className:"pen-rank",children:["#",a.rank]}),a.marka]}),(0,b.jsxs)("div",{className:"pen-track",children:[!a.isTotal&&(0,b.jsx)("div",{className:"pen-fill",style:{width:`${Math.min(a.penetrasyonPct/h*100,100)}%`}}),(0,b.jsxs)("span",{className:"pen-pct",children:["%",a.penetrasyonPct.toFixed(1)]})]}),(0,b.jsxs)("div",{className:"pen-count",children:[a.musteriSayi.toLocaleString("tr-TR")," /"," ",c.toLocaleString("tr-TR")]})]},a.markaKod||a.marka)})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .pen-bars { display: flex; flex-direction: column; gap: 6px; }
        .pen-row { display: grid; grid-template-columns: 200px 1fr 160px; align-items: center; gap: 12px; font-size: 12.5px; padding: 5px 0; }
        .pen-row.strat .pen-fill { background: var(--color-accent); opacity: 0.85; }
        .pen-row.other { border-top: 1px solid var(--color-border); }
        .pen-row.other .pen-name { font-style: italic; color: var(--color-muted); }
        .pen-row.other .pen-fill { opacity: 0.4; }
        .pen-row.total { border-top: 2px solid var(--color-fg); margin-top: 2px; }
        .pen-row.total .pen-name { font-weight: 700; color: var(--color-fg); }
        .pen-row.total .pen-count { color: var(--color-fg); font-weight: 600; }
        .pen-row.total .pen-track { background: transparent; }
        .pen-name { display: inline-flex; align-items: center; gap: 6px; color: var(--color-fg); font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pen-rank { font-size: 10.5px; color: var(--color-muted-2); font-variant-numeric: tabular-nums; min-width: 22px; }
        .pen-track { position: relative; height: 22px; background: var(--color-surface-2); border-radius: 4px; overflow: hidden; }
        .pen-fill { height: 100%; background: #9FE1CB; border-radius: 4px; opacity: 0.7; transition: width 0.3s ease-out; }
        .pen-pct { position: absolute; left: 8px; top: 50%; transform: translateY(-50%); font-size: 11.5px; color: var(--color-fg); font-variant-numeric: tabular-nums; font-weight: 600; }
        .pen-count { text-align: right; color: var(--color-muted-2); font-size: 11px; font-variant-numeric: tabular-nums; }
        .strat-dot { display: inline-block; width: 8px; height: 8px; background: var(--color-accent); border-radius: 50%; }
        .empty { padding: 20px; text-align: center; color: var(--color-muted); font-size: 12.5px; }
      `}})]})}function m({brands:a,periodLabel:c="Son 30g"}){if(0===a.length)return(0,b.jsxs)("div",{className:"v3-panel empty",children:[(0,b.jsx)("div",{className:"v3-panel-title",children:"Stratejik Marka Zoom"}),(0,b.jsx)("p",{className:"empty-msg",children:"tenant.strategicBrands listesi boş — stratejik marka takibi tanımlanmamış."}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
          .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
          .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); }
          .empty-msg { font-size: 12.5px; color: var(--color-muted); margin: 8px 0 0; }
        `}})]});let d=a.filter(a=>a.hasData),e=d.reduce((a,b)=>a+b.ciro,0);return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:"Stratejik Marka Zoom"}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[c," · ",d.length,"/",a.length," marka aktif · Toplam stratejik ciro ",(0,b.jsxs)("strong",{children:["₺",(0,i.formatCompact)(e)]})]})]})}),(0,b.jsx)("div",{className:"strat-grid",children:a.map(a=>(0,b.jsxs)("div",{className:`strat-card ${a.hasData?"":"empty-card"}`,children:[(0,b.jsxs)("div",{className:"card-head",children:[(0,b.jsx)("span",{className:"strat-dot"}),(0,b.jsx)("span",{className:"card-name",title:a.marka,children:a.marka})]}),(0,b.jsx)("div",{className:"card-hero",children:a.hasData?`₺${(0,i.formatCompact)(a.ciro)}`:"—"}),(0,b.jsx)("div",{className:"card-meta",children:a.hasData?(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)("span",{children:[a.musteriSayi.toLocaleString("tr-TR")," müşteri"]}),(0,b.jsx)("span",{className:"dot",children:"·"}),(0,b.jsxs)("span",{children:[a.faturaSayisi.toLocaleString("tr-TR")," fatura"]})]}):(0,b.jsx)("span",{children:"son 30g satış yok"})}),a.hasData&&a.topSkus.length>0&&(0,b.jsx)("ol",{className:"card-skus",children:a.topSkus.map((a,c)=>(0,b.jsxs)("li",{children:[(0,b.jsx)("span",{className:"sku-rank",children:c+1}),(0,b.jsx)("span",{className:"sku-ad",title:a.ad,children:a.ad.length>36?a.ad.slice(0,33)+"…":a.ad}),(0,b.jsxs)("span",{className:"sku-ciro",children:["₺",(0,i.formatCompact)(a.ciro)]})]},a.urunKod))}),a.hasData&&0===a.topSkus.length&&(0,b.jsx)("div",{className:"card-no-sku",children:"SKU detayı çekilemedi."})]},a.marka))}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .strat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; }
        .strat-card { background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: 8px; padding: 12px 14px; display: flex; flex-direction: column; gap: 8px; }
        .strat-card.empty-card { opacity: 0.55; }
        .card-head { display: inline-flex; align-items: center; gap: 6px; }
        .strat-dot { width: 8px; height: 8px; background: var(--color-accent); border-radius: 50%; flex-shrink: 0; }
        .card-name { font-size: 12.5px; font-weight: 600; color: var(--color-fg); letter-spacing: 0.01em; }
        .card-hero { font-size: 22px; font-weight: 700; color: var(--color-fg); font-variant-numeric: tabular-nums; line-height: 1.1; letter-spacing: -0.02em; }
        .card-meta { font-size: 11px; color: var(--color-muted); display: inline-flex; gap: 4px; }
        .card-meta .dot { opacity: 0.5; }
        .card-skus { list-style: none; margin: 6px 0 0; padding: 8px 0 0; border-top: 1px dashed var(--color-border); display: flex; flex-direction: column; gap: 4px; }
        .card-skus li { display: grid; grid-template-columns: 18px 1fr auto; align-items: baseline; gap: 6px; font-size: 11.5px; font-variant-numeric: tabular-nums; }
        .sku-rank { color: var(--color-muted-2); font-weight: 500; }
        .sku-ad { color: var(--color-fg-2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .sku-ciro { color: var(--color-fg); font-weight: 500; }
        .card-no-sku { font-size: 11px; color: var(--color-muted-2); border-top: 1px dashed var(--color-border); padding-top: 6px; }
      `}})]})}var n=a.i(27052);let o=/^\d{4}-\d{2}-\d{2}$/;async function p({searchParams:a}){let r=(0,e.getTenantConfig)(),s=await a,t=s.from&&o.test(s.from)?s.from:null,u=s.to&&o.test(s.to)?s.to:null,v=t&&u?null:(s.donem??"").toLowerCase()||null,w=null,x=null;try{w=await (0,c.getWietnauerMarka)({dateFrom:t,dateTo:u,donem:v})}catch(a){x=a.message}let y=w?.toplamCiro30??0,z=w?.aktifMusteriToplam??0,A=w?w.portfolio.slice(0,5).reduce((a,b)=>a+b.payPct,0):0,B=w?w.strategic.filter(a=>a.hasData).length:0,C=w?.strategic.length??0,D=w?w.strategic.reduce((a,b)=>a+b.ciro,0):0,E=y>0?D/y*100:0,F=w?w.portfolio.filter(a=>!a.isOther&&!a.isTotal).length:0,G=w?w.topSkus.filter(a=>!a.isOther&&!a.isTotal).length:0,H=w?w.portfolio.find(a=>!a.isOther&&!a.isTotal)??null:null,I=(0,h.donemLabel)(v,t,u),J=I.charAt(0).toUpperCase()+I.slice(1);return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(f.V3PageHeader,{eyebrow:"Dashboard 04",title:"Marka & SKU Performansı",contentKey:"page.marka.title",descKey:"page.marka.desc",description:`${r.displayName} marka portf\xf6y\xfc, SKU şampiyonları, penetrasyon ve stratejik marka zoom — ${I} net ciro odağında, YTD ivme metrikleriyle.`,dataNote:"TBLURUNGRUP / TBLURUNEKGRUP · TBLURUN · TBLMSDBELGEDETAY · DBLNETFIYAT · BYTTUR=0 · BYTDURUM=0",generatedAt:w?.generatedAt}),(0,b.jsx)(g.GlobalDonemFilter,{}),x&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",x,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula. API restart gerekebilir."})]}),w&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("div",{className:"v3-toolbar",children:(0,b.jsx)(n.MarkaSkuExportButton,{portfolio:w.portfolio,topSkus:w.topSkus})}),(0,b.jsxs)("div",{className:"v3-kpi-grid",children:[!(0,d.panelHidden)("kpi.marka.ciro")&&(0,b.jsx)(q,{label:(0,d.cs)("kpi.marka.ciro","Toplam Net Ciro"),value:`₺${(0,i.formatCompact)(y)}`,sub:`${I} \xb7 ${F} marka \xd7 ${G} SKU bazlı`}),!(0,d.panelHidden)("kpi.marka.aktif")&&(0,b.jsx)(q,{label:(0,d.cs)("kpi.marka.aktif","Aktif Müşteri"),value:z.toLocaleString("tr-TR"),sub:`${I} fatura kesilen distinct`}),!(0,d.panelHidden)("kpi.marka.top5")&&(0,b.jsx)(q,{label:(0,d.cs)("kpi.marka.top5","Top 5 Marka Payı"),value:`%${A.toFixed(1)}`,sub:H?`lider: ${H.marka} \xb7 %${H.payPct.toFixed(1)}`:"portföyün konsantrasyonu",tone:A>70?"warn":"neutral"}),!(0,d.panelHidden)("kpi.marka.stratejik")&&(0,b.jsx)(q,{label:(0,d.cs)("kpi.marka.stratejik","Stratejik Marka Payı"),value:`%${E.toFixed(1)}`,sub:`${B}/${C} marka aktif`,tone:"accent"})]}),(0,b.jsxs)("div",{className:"v3-content",children:[(0,b.jsx)(j,{rows:w.portfolio,periodLabel:J}),(0,b.jsxs)("div",{className:"row-2col",children:[(0,b.jsx)(k,{rows:w.topSkus,periodLabel:J}),(0,b.jsx)(l,{rows:w.penetration,aktifMusteriToplam:w.aktifMusteriToplam,periodLabel:J})]}),(0,b.jsx)(m,{brands:w.strategic,periodLabel:J})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .v3-toolbar {
          display: flex;
          justify-content: flex-end;
          margin-bottom: 12px;
        }
        .v3-kpi-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
          gap: 12px;
          margin-bottom: 20px;
        }
        .v3-content {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .row-2col {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
        }
        @media (min-width: 1080px) {
          .row-2col {
            grid-template-columns: 1.4fr 1fr;
            align-items: start;
          }
        }
        .v3-error {
          background: var(--color-bad-bg, rgba(220, 38, 38, 0.05));
          border: 1px solid var(--color-bad, #dc2626);
          border-radius: 8px;
          padding: 14px 16px;
          margin-bottom: 20px;
          font-size: 13px;
          color: var(--color-fg);
        }
        .v3-error-hint {
          margin-top: 4px;
          font-size: 12px;
          color: var(--color-muted);
        }
      `}})]})}function q({label:a,value:c,sub:d,tone:e}){return(0,b.jsxs)("div",{style:{background:"var(--color-surface)",border:"1px solid var(--color-border)",borderRadius:10,padding:"14px 16px",display:"flex",flexDirection:"column",gap:4},children:[(0,b.jsx)("div",{style:{fontSize:10.5,color:"var(--color-muted)",textTransform:"uppercase",letterSpacing:"0.05em",fontWeight:600},children:a}),(0,b.jsx)("div",{style:{fontSize:24,fontWeight:700,color:"warn"===e?"var(--color-bad)":"accent"===e?"var(--color-accent)":"var(--color-fg)",letterSpacing:"-0.02em",fontVariantNumeric:"tabular-nums",lineHeight:1.1},children:c}),(0,b.jsx)("div",{style:{fontSize:11,color:"var(--color-muted-2)"},children:d})]})}a.s(["default",0,p,"metadata",0,{title:"Marka & SKU · V3 · Insider"}],9385)},44988,a=>{a.n(a.i(9385))}];

//# sourceMappingURL=apps_dashboard_0hi_eof._.js.map