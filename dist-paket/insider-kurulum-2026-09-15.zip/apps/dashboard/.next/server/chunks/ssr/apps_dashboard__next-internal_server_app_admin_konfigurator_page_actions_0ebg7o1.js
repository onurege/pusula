module.exports=[87592,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_admin_konfigurator_page_actions_0ebg7o1.js.map