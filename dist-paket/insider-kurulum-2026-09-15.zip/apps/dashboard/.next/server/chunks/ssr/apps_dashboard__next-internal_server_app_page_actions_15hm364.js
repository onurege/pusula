module.exports=[24492,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_page_actions_15hm364.js.map