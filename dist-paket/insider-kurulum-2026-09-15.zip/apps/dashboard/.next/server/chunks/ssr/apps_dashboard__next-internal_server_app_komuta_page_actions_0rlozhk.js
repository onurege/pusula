module.exports=[15836,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_komuta_page_actions_0rlozhk.js.map