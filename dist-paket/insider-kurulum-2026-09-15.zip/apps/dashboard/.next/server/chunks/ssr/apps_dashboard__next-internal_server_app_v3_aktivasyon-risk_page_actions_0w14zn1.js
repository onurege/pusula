module.exports=[77010,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_aktivasyon-risk_page_actions_0w14zn1.js.map