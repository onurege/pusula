module.exports=[98884,a=>{"use strict";a.s(["SatisUnitToggle",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call SatisUnitToggle() from the server but SatisUnitToggle is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/satis/SatisUnitToggle.tsx <module evaluation>","SatisUnitToggle")},3670,a=>{"use strict";a.s(["SatisUnitToggle",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call SatisUnitToggle() from the server but SatisUnitToggle is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/apps/dashboard/components/v3/satis/SatisUnitToggle.tsx","SatisUnitToggle")},70430,a=>{"use strict";a.i(98884);var b=a.i(3670);a.n(b)},62128,a=>{"use strict";var b=a.i(7997),c=a.i(93105);a.i(2614);var d=a.i(12261),e=a.i(24580),f=a.i(1381);function g({pct:a,hasPrev:c}){if(!c)return(0,b.jsx)("span",{className:"delta-badge new",children:"yeni"});let d=a>0,e=a<0,f=`${d?"▲":e?"▼":"▬"} %${Math.abs(a).toFixed(1)}`;return(0,b.jsxs)("span",{className:"delta-badge",style:{color:d?"#16a34a":e?"#dc2626":"var(--color-muted-2)"},title:`\xd6nceki 30 g\xfcne g\xf6re %${a.toFixed(2)} değişim`,children:[f,(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .delta-badge { display: inline-flex; align-items: center; gap: 2px; font-variant-numeric: tabular-nums; font-weight: 500; font-size: 11.5px; white-space: nowrap; }
        .delta-badge.new { color: var(--color-accent); font-style: italic; font-weight: 600; }
      `}})]})}function h({rows:a,rangeLabel:d="Son 30g"}){return(0,c.panelHidden)("panel.satis.rep")?null:0===a.length?(0,b.jsxs)("div",{className:"v3-panel v3-panel-empty",children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.rep","Satış Temsilcisi Leaderboard")}),(0,b.jsxs)("p",{children:[d," içinde temsilci atamalı fatura bulunamadı."]})]}):(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.rep","Satış Temsilcisi Leaderboard")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[d," net ciro · Top ",a.length," · vs önceki dönem delta"]})]})}),(0,b.jsx)("div",{className:"v3-table-wrap",children:(0,b.jsxs)("table",{className:"v3-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{style:{width:36},children:"#"}),(0,b.jsx)("th",{children:"Temsilci"}),(0,b.jsx)("th",{children:"Distribütör"}),(0,b.jsx)("th",{children:"Bölge"}),(0,b.jsx)("th",{className:"num",children:"Ciro"}),(0,b.jsx)("th",{className:"num",children:"Müşteri"}),(0,b.jsx)("th",{className:"num",children:"Ort. Sepet"}),(0,b.jsx)("th",{className:"num",children:"Δ"})]})}),(0,b.jsx)("tbody",{children:a.map(a=>(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{className:"rank",children:a.rank}),(0,b.jsx)("td",{className:"name",title:a.ad,children:a.ad}),(0,b.jsx)("td",{className:"dist",children:a.distAd||"—"}),(0,b.jsx)("td",{className:"region",children:a.region||"—"}),(0,b.jsxs)("td",{className:"num strong",children:["₺",(0,f.formatCompact)(a.ciro)]}),(0,b.jsx)("td",{className:"num",children:a.musteriSayi.toLocaleString("tr-TR")}),(0,b.jsxs)("td",{className:"num",children:["₺",(0,f.formatCompact)(a.ortSepet)]}),(0,b.jsx)("td",{className:"num",children:(0,b.jsx)(g,{pct:a.deltaPct,hasPrev:a.prevCiro>0})})]},a.id))})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-empty p { font-size: 12.5px; color: var(--color-muted); margin: 8px 0 0; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .v3-table-wrap { overflow-x: auto; margin: 0 -4px; }
        .v3-table { width: 100%; border-collapse: collapse; font-size: 12.5px; min-width: 820px; }
        .v3-table thead th { text-align: left; padding: 8px 10px; font-size: 10.5px; font-weight: 600; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.04em; border-bottom: 1px solid var(--color-border); }
        .v3-table thead th.num { text-align: right; }
        .v3-table tbody tr { border-bottom: 1px solid var(--color-border); }
        .v3-table tbody tr:hover { background: var(--color-surface-2); }
        .v3-table td { padding: 9px 10px; color: var(--color-fg); }
        .v3-table td.rank { font-weight: 600; color: var(--color-muted); font-variant-numeric: tabular-nums; }
        .v3-table td.name { font-weight: 500; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .v3-table td.dist { color: var(--color-muted); max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .v3-table td.region { color: var(--color-muted-2); }
        .v3-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
        .v3-table td.num.strong { font-weight: 600; color: var(--color-fg); }
      `}})]})}function i({rows:a,unit:d="tl",volumeShort:e,rangeLabel:g="Son 30g"}){if((0,c.panelHidden)("panel.satis.hiz"))return null;if(0===a.length)return(0,b.jsxs)("div",{className:"v3-panel v3-panel-empty",children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.hiz","Nokta Başına Satış Hızı")}),(0,b.jsxs)("p",{children:[g," içinde fatura kaydı bulunamadı."]})]});let h="tl"!==d&&!!e,j=[...a.map(a=>({...a,hiz:h?a.musteriSayi>0?a.hacim/a.musteriSayi:0:a.satisHizi}))].sort((a,b)=>b.hiz-a.hiz).slice(0,15),k=Math.max(1,...j.map(a=>a.hiz));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.hiz","Nokta Başına Satış Hızı")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[g," · ",h?`hacim (${e})`:"ciro"," / aktif nokta (aktif müşteri) · Top ",j.length]})]})}),(0,b.jsx)("div",{className:"v3-bars",children:j.map(a=>(0,b.jsxs)("div",{className:"bar-row",children:[(0,b.jsxs)("div",{className:"bar-label",title:a.ad,children:[(0,b.jsxs)("span",{className:"bar-rank",children:["#",a.rank]}),(0,b.jsx)("span",{className:"bar-name",children:a.ad}),a.region&&(0,b.jsx)("span",{className:"bar-region",children:a.region})]}),(0,b.jsx)("div",{className:"bar-track",children:(0,b.jsx)("div",{className:"bar-fill",style:{width:`${a.hiz/k*100}%`}})}),(0,b.jsxs)("div",{className:"bar-meta",children:[(0,b.jsx)("span",{className:"bar-val",children:h?`${(0,f.formatCompact)(a.hiz)} ${e}`:`₺${(0,f.formatCompact)(a.hiz)}`}),(0,b.jsxs)("span",{className:"bar-cust",children:[a.musteriSayi.toLocaleString("tr-TR")," nokta"]})]})]},a.id))}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-empty p { font-size: 12.5px; color: var(--color-muted); margin: 8px 0 0; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .v3-bars { display: flex; flex-direction: column; gap: 5px; }
        .bar-row { display: grid; grid-template-columns: 220px 1fr 200px; align-items: center; gap: 12px; padding: 6px 0; font-size: 12.5px; }
        .bar-row:hover { background: var(--color-surface-2); margin: 0 -8px; padding: 6px 8px; border-radius: 6px; }
        .bar-label { display: inline-flex; align-items: center; gap: 6px; overflow: hidden; }
        .bar-rank { font-size: 10.5px; color: var(--color-muted-2); font-variant-numeric: tabular-nums; font-weight: 500; min-width: 22px; }
        .bar-name { font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; }
        .bar-region { font-size: 10.5px; color: var(--color-muted-2); white-space: nowrap; }
        .bar-track { height: 18px; background: var(--color-surface-2); border-radius: 4px; overflow: hidden; position: relative; }
        .bar-fill { height: 100%; background: var(--color-accent); border-radius: 4px; opacity: 0.65; transition: width 0.3s ease-out; }
        .bar-meta { display: inline-flex; align-items: baseline; justify-content: flex-end; gap: 10px; font-variant-numeric: tabular-nums; }
        .bar-val { color: var(--color-fg); font-weight: 600; min-width: 80px; text-align: right; }
        .bar-cust { color: var(--color-muted); font-size: 11.5px; min-width: 80px; text-align: right; }
      `}})]})}function j({rows:a,rangeLabel:d="Son 30g"}){if((0,c.panelHidden)("panel.satis.drop"))return null;if(0===a.length)return(0,b.jsxs)("div",{className:"v3-panel v3-panel-empty",children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.drop","Drop Size (Nokta Başına Ciro)")}),(0,b.jsx)("p",{children:"Yeterli müşteri tabanlı distribütör bulunamadı (≥5 müşteri)."})]});let e=Math.max(1,...a.map(a=>a.dropSize));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.drop","Drop Size (Nokta Başına Ciro)")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:[d," · ciro / distinct müşteri · Top ",a.length," ·",(0,b.jsx)("span",{className:"hint",children:" en az 5 müşterisi olan distribütörler"})]})]})}),(0,b.jsx)("div",{className:"v3-bars",children:a.map(a=>(0,b.jsxs)("div",{className:"bar-row",children:[(0,b.jsxs)("div",{className:"bar-label",title:a.ad,children:[(0,b.jsxs)("span",{className:"bar-rank",children:["#",a.rank]}),(0,b.jsx)("span",{className:"bar-name",children:a.ad}),a.region&&(0,b.jsx)("span",{className:"bar-region",children:a.region})]}),(0,b.jsx)("div",{className:"bar-track",children:(0,b.jsx)("div",{className:"bar-fill",style:{width:`${a.dropSize/e*100}%`}})}),(0,b.jsxs)("div",{className:"bar-meta",children:[(0,b.jsxs)("span",{className:"bar-val",children:["₺",(0,f.formatCompact)(a.dropSize)]}),(0,b.jsxs)("span",{className:"bar-cust",children:[a.musteriSayi.toLocaleString("tr-TR")," müşteri"]})]})]},a.id))}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-empty p { font-size: 12.5px; color: var(--color-muted); margin: 8px 0 0; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .v3-panel-sub .hint { color: var(--color-muted-2); }
        .v3-bars { display: flex; flex-direction: column; gap: 5px; }
        .bar-row { display: grid; grid-template-columns: 220px 1fr 200px; align-items: center; gap: 12px; padding: 6px 0; font-size: 12.5px; }
        .bar-row:hover { background: var(--color-surface-2); margin: 0 -8px; padding: 6px 8px; border-radius: 6px; }
        .bar-label { display: inline-flex; align-items: center; gap: 6px; overflow: hidden; }
        .bar-rank { font-size: 10.5px; color: var(--color-muted-2); font-variant-numeric: tabular-nums; font-weight: 500; min-width: 22px; }
        .bar-name { font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; }
        .bar-region { font-size: 10.5px; color: var(--color-muted-2); white-space: nowrap; }
        .bar-track { height: 18px; background: var(--color-surface-2); border-radius: 4px; overflow: hidden; position: relative; }
        .bar-fill { height: 100%; background: var(--color-accent); border-radius: 4px; opacity: 0.65; transition: width 0.3s ease-out; }
        .bar-meta { display: inline-flex; align-items: baseline; justify-content: flex-end; gap: 10px; font-variant-numeric: tabular-nums; }
        .bar-val { color: var(--color-fg); font-weight: 600; min-width: 80px; text-align: right; }
        .bar-cust { color: var(--color-muted); font-size: 11.5px; min-width: 80px; text-align: right; }
      `}})]})}function k({items:a,totalYeniMusteri:d,totalYeniCiro:e}){if((0,c.panelHidden)("panel.satis.new"))return null;let g=Math.max(1,...a.map(a=>a.yeniMusteriSayi));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.new","Yeni Müşteri Kazanımı")}),(0,b.jsx)("div",{className:"v3-panel-sub",children:"Son 90g · ilk faturası bu pencerede kesilmiş müşteriler"})]})}),(0,b.jsxs)("div",{className:"kpi-row",children:[(0,b.jsxs)("div",{className:"kpi-tile",children:[(0,b.jsx)("div",{className:"kpi-label",children:"Toplam Yeni Müşteri"}),(0,b.jsx)("div",{className:"kpi-val",children:d.toLocaleString("tr-TR")}),(0,b.jsx)("div",{className:"kpi-sub",children:"son 90g"})]}),(0,b.jsxs)("div",{className:"kpi-tile",children:[(0,b.jsx)("div",{className:"kpi-label",children:"Yeni Müşteri Cirosu"}),(0,b.jsxs)("div",{className:"kpi-val",children:["₺",(0,f.formatCompact)(e)]}),(0,b.jsx)("div",{className:"kpi-sub",children:"son 90g net"})]})]}),0===a.length?(0,b.jsx)("p",{className:"empty",children:"Bu pencerede yeni müşteri kazanılmamış."}):(0,b.jsxs)("div",{className:"v3-bars",children:[(0,b.jsx)("div",{className:"bars-head",children:(0,b.jsxs)("span",{children:["Distribütör × Yeni Müşteri (Top ",a.length,")"]})}),a.map(a=>(0,b.jsxs)("div",{className:"bar-row",children:[(0,b.jsxs)("div",{className:"bar-label",title:a.distAd,children:[(0,b.jsx)("span",{className:"bar-name",children:a.distAd}),a.region&&(0,b.jsx)("span",{className:"bar-region",children:a.region})]}),(0,b.jsx)("div",{className:"bar-track",children:(0,b.jsx)("div",{className:"bar-fill",style:{width:`${a.yeniMusteriSayi/g*100}%`}})}),(0,b.jsxs)("div",{className:"bar-meta",children:[(0,b.jsx)("span",{className:"bar-val",children:a.yeniMusteriSayi.toLocaleString("tr-TR")}),(0,b.jsxs)("span",{className:"bar-ciro",children:["₺",(0,f.formatCompact)(a.yeniMusteriCiro)]})]})]},a.distId))]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-head { margin-bottom: 14px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .kpi-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
        .kpi-tile { background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: 8px; padding: 12px 14px; }
        .kpi-label { font-size: 10.5px; font-weight: 600; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.05em; }
        .kpi-val { font-size: 22px; font-weight: 700; color: var(--color-fg); letter-spacing: -0.02em; font-variant-numeric: tabular-nums; line-height: 1.15; margin-top: 4px; }
        .kpi-sub { font-size: 11px; color: var(--color-muted-2); margin-top: 2px; }
        .bars-head { font-size: 10.5px; font-weight: 600; color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 6px; border-bottom: 1px solid var(--color-border); margin-bottom: 6px; }
        .v3-bars { display: flex; flex-direction: column; gap: 4px; }
        .bar-row { display: grid; grid-template-columns: 200px 1fr 160px; align-items: center; gap: 12px; padding: 5px 0; font-size: 12.5px; }
        .bar-row:hover { background: var(--color-surface-2); margin: 0 -8px; padding: 5px 8px; border-radius: 6px; }
        .bar-label { display: inline-flex; align-items: center; gap: 6px; overflow: hidden; }
        .bar-name { font-weight: 500; color: var(--color-fg); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; }
        .bar-region { font-size: 10.5px; color: var(--color-muted-2); white-space: nowrap; }
        .bar-track { height: 14px; background: var(--color-surface-2); border-radius: 3px; overflow: hidden; position: relative; }
        .bar-fill { height: 100%; background: #16a34a; border-radius: 3px; opacity: 0.65; transition: width 0.3s ease-out; }
        .bar-meta { display: inline-flex; align-items: baseline; justify-content: flex-end; gap: 10px; font-variant-numeric: tabular-nums; }
        .bar-val { color: var(--color-fg); font-weight: 600; min-width: 50px; text-align: right; }
        .bar-ciro { color: var(--color-muted); font-size: 11.5px; min-width: 70px; text-align: right; }
        .empty { font-size: 12.5px; color: var(--color-muted); margin: 4px 0 0; }
      `}})]})}function l({points:a}){if((0,c.panelHidden)("panel.satis.avg"))return null;if(0===a.length)return(0,b.jsxs)("div",{className:"v3-panel v3-panel-empty",children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.avg","Ortalama Sipariş Büyüklüğü Trendi")}),(0,b.jsx)("p",{children:"Son 12 ayda fatura kaydı bulunamadı."})]});let d=a.map(a=>a.ortSepet),e=Math.max(...d,1),g=Math.min(...d,0),h=e-g||1,i=b=>1===a.length?379:56+b/(a.length-1)*646,j=a=>190-(a-g)/h*172,k=a.map((a,b)=>`${0===b?"M":"L"} ${i(b).toFixed(1)} ${j(a.ortSepet).toFixed(1)}`).join(" "),n=k+` L ${i(a.length-1).toFixed(1)} 190.0`+` L ${i(0).toFixed(1)} 190.0 Z`,o=a.length>=6?a.slice(-3).reduce((a,b)=>a+b.ortSepet,0)/3:null,p=a.length>=6?a.slice(-6,-3).reduce((a,b)=>a+b.ortSepet,0)/3:null,q=null!==o&&null!==p&&p>0?(o-p)/p*100:null,r=[0,.33,.66,1].map(a=>({v:g+a*h,y:190-172*a}));return(0,b.jsxs)("div",{className:"v3-panel",children:[(0,b.jsx)("div",{className:"v3-panel-head",children:(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"v3-panel-title",children:(0,c.panelTitle)("panel.satis.avg","Ortalama Sipariş Büyüklüğü Trendi")}),(0,b.jsxs)("div",{className:"v3-panel-sub",children:["Son ",a.length," ay · AVG(net ciro) / fatura",null!==q&&(0,b.jsxs)(b.Fragment,{children:[" ","· son 3 ay vs önceki 3 ay"," ",(0,b.jsxs)("strong",{style:{color:null===q?"var(--color-muted-2)":q>0?"#16a34a":q<0?"#dc2626":"var(--color-muted)"},children:[q>0?"▲":q<0?"▼":"▬"," ","%",Math.abs(q).toFixed(1)]})]})]})]})}),(0,b.jsx)("div",{className:"chart-wrap",children:(0,b.jsxs)("svg",{viewBox:"0 0 720 220",preserveAspectRatio:"none",role:"img","aria-label":"Aylık ortalama sipariş büyüklüğü trend grafiği",children:[r.map((a,c)=>(0,b.jsxs)("g",{children:[(0,b.jsx)("line",{x1:56,x2:702,y1:a.y,y2:a.y,stroke:"var(--color-border)",strokeDasharray:"2 3",strokeWidth:1}),(0,b.jsxs)("text",{x:48,y:a.y+3,textAnchor:"end",fontSize:10,fill:"var(--color-muted-2)",fontFamily:"inherit",children:["₺",(0,f.formatCompact)(a.v)]})]},c)),(0,b.jsx)("path",{d:n,fill:"var(--color-accent)",opacity:.12}),(0,b.jsx)("path",{d:k,fill:"none",stroke:"var(--color-accent)",strokeWidth:2,strokeLinejoin:"round",strokeLinecap:"round"}),a.map((c,d)=>(0,b.jsxs)("g",{children:[(0,b.jsx)("circle",{cx:i(d),cy:j(c.ortSepet),r:3,fill:"var(--color-surface)",stroke:"var(--color-accent)",strokeWidth:1.5,"aria-label":`${c.ay}: ort sepet ${(0,f.formatCompact)(c.ortSepet)} TL, ${c.faturaSayi} fatura`}),(a.length<=6||d%2==0||d===a.length-1)&&(0,b.jsx)("text",{x:i(d),y:206,textAnchor:"middle",fontSize:10,fill:"var(--color-muted)",fontFamily:"inherit",children:m(c.ay)})]},c.ay))]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-panel { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 10px; padding: 18px 20px; }
        .v3-panel-empty p { font-size: 12.5px; color: var(--color-muted); margin: 8px 0 0; }
        .v3-panel-head { margin-bottom: 12px; }
        .v3-panel-title { font-size: 15px; font-weight: 600; color: var(--color-fg); letter-spacing: -0.01em; }
        .v3-panel-sub { font-size: 12px; color: var(--color-muted); margin-top: 2px; }
        .chart-wrap { width: 100%; overflow-x: auto; }
        .chart-wrap svg { width: 100%; height: auto; min-width: 480px; display: block; }
      `}})]})}function m(a){let[b,c]=a.split("-"),d=Math.max(0,Math.min(11,Number(c)-1)),e=b?.slice(2)??"";return`${["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"][d]} '${e}`}var n=a.i(1980),o=a.i(70430);let p=/^\d{4}-\d{2}-\d{2}$/,q=process.env.ENROUTE_API_URL??"http://localhost:8080";function r(a){let b=(a??"").trim();return p.test(b)?b:null}function s(a){return new Date(`${a}T12:00:00`).toLocaleDateString("tr-TR",{day:"2-digit",month:"short"})}async function t(b){let c=new URLSearchParams;b.dateFrom&&c.set("from",b.dateFrom),b.dateTo?c.set("to",b.dateTo):b.donem&&"son30g"!==b.donem&&c.set("donem",b.donem);let d=c.toString(),e=`/api/wietnauer/satis${d?`?${d}`:""}`,f=null;try{let{cookies:b}=await a.A(23804),c=await b();f=c.get("enroute_auth")?.value??null}catch{f=null}let g=await fetch(`${q}${e}`,{headers:{"Content-Type":"application/json",...f?{Authorization:`Bearer ${f}`}:{}},cache:"no-store"});if(!g.ok){let a=await g.text(),b=a;try{let c=JSON.parse(a);b=[c.error,c.stack].filter(Boolean).join("\n")}catch{}throw Error(`API ${g.status}: ${b}`)}return g.json()}let u={son30g:"Son 30g",mtd:"Bu Ay",ytd:"Bu Yıl",q1:"Ç1",q2:"Ç2",q3:"Ç3"};async function v({searchParams:a}){let g=(0,d.getTenantConfig)(),p=await a,q=r(p.from),x=r(p.to),y=!!(q&&x&&q<=x),z=(p.donem??"").toLowerCase(),A=g.volume.key,B=p.unit===A?A:"tl",C=y&&q&&x?`${s(q)} – ${s(x)}`:u[z]??"Son 30g",D=null,E=null;try{D=await t({dateFrom:y?q:null,dateTo:y?x:null,donem:y?null:z||null})}catch(a){E=a.message}let F=D?.distLeaderboard.reduce((a,b)=>a+b.ciro,0)??0,G=D?.distLeaderboard.reduce((a,b)=>a+b.hacim,0)??0,H=g.volume?.short??"",I=B===A&&H,J=D?.distLeaderboard.length??0,K=D?.repLeaderboard.length??0,L=D&&D.avgOrderTrend.length>0?D.avgOrderTrend[D.avgOrderTrend.length-1]??null:null,M=L?.ortSepet??0;return(0,b.jsxs)("div",{className:"v3-page",children:[(0,b.jsx)(e.V3PageHeader,{eyebrow:"Dashboard 02",title:"Satış Performansı",contentKey:"page.satis.title",descKey:"page.satis.desc",description:D?`${g.displayName} distrib\xfct\xf6r ve saha satış temsilcisi performansı tek ekranda — ${C} i\xe7inde ${J} distrib\xfct\xf6r, ${K} temsilci; leaderboard, drop size, yeni m\xfcşteri kazanımı ve ortalama sepet trendi.`:`${g.displayName} distrib\xfct\xf6r ve saha satış temsilcisi performansı tek ekranda — leaderboard, drop size, yeni m\xfcşteri kazanımı ve ortalama sepet trendi.`,dataNote:"TBLMSDFATURA + TBLDISTPERSONEL + TBLDIST + TBLDISTEKGRUP · BYTTUR=0 · BYTDURUM=0",generatedAt:D?.generatedAt}),E&&(0,b.jsxs)("div",{className:"v3-error",children:[(0,b.jsx)("strong",{children:"Veri alınamadı:"})," ",E,(0,b.jsx)("div",{className:"v3-error-hint",children:"VPN kontrol et veya MSSQL bağlantı durumunu doğrula."})]}),(0,b.jsx)(n.GlobalDonemFilter,{}),(0,b.jsx)("div",{className:"v3-controls-row",children:(0,b.jsx)(o.SatisUnitToggle,{})}),D&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)("div",{className:"v3-kpi-grid",children:[I?(0,b.jsx)(w,{label:`Top Distrib\xfct\xf6r Hacmi (${H})`,value:(0,f.formatCompact)(G),sub:`${C} \xb7 ₺${(0,f.formatCompact)(F)} ciro \xb7 ${J} dist`}):(0,b.jsx)(w,{label:"Top Distribütör Cirosu",value:`₺${(0,f.formatCompact)(F)}`,sub:`${C}${H?` \xb7 ${(0,f.formatCompact)(G)} ${H}`:""} \xb7 ${J} dist`}),!(0,c.panelHidden)("kpi.satis.temsilci")&&(0,b.jsx)(w,{label:(0,c.cs)("kpi.satis.temsilci","Top Temsilci Sayısı"),value:K.toLocaleString("tr-TR"),sub:`${C} performans listesinde`}),!(0,c.panelHidden)("kpi.satis.yeni")&&(0,b.jsx)(w,{label:(0,c.cs)("kpi.satis.yeni","Yeni Müşteri (90g)"),value:D.newCustomers.totalYeniMusteri.toLocaleString("tr-TR"),sub:`₺${(0,f.formatCompact)(D.newCustomers.totalYeniCiro)} ciro`,tone:"accent"}),!(0,c.panelHidden)("kpi.satis.sepet")&&(0,b.jsx)(w,{label:(0,c.cs)("kpi.satis.sepet","Güncel Ort. Sepet"),value:`₺${(0,f.formatCompact)(M)}`,sub:L?`${m(L.ay)} \xb7 ${L.faturaSayi.toLocaleString("tr-TR")} fatura`:"son ay · AVG net/fatura"})]}),(0,b.jsxs)("div",{className:"v3-content-stack",children:[(0,b.jsx)(h,{rows:D.repLeaderboard,rangeLabel:C}),(0,b.jsx)(i,{rows:D.distLeaderboard,unit:B,volumeShort:H,rangeLabel:C}),(0,b.jsxs)("div",{className:"v3-row-2col",children:[(0,b.jsx)(j,{rows:D.dropSize,rangeLabel:C}),(0,b.jsx)(k,{items:D.newCustomers.items,totalYeniMusteri:D.newCustomers.totalYeniMusteri,totalYeniCiro:D.newCustomers.totalYeniCiro})]}),(0,b.jsx)(l,{points:D.avgOrderTrend})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .v3-page { padding: 4px 0 24px; }
        .v3-controls-row {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          flex-wrap: wrap;
          margin-bottom: 4px;
        }
        .v3-controls-row .satis-date-range { margin-bottom: 0; flex: 1; min-width: 320px; }
        .v3-kpi-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
          gap: 12px;
          margin-bottom: 20px;
        }
        .v3-content-stack {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .v3-row-2col {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
        }
        @media (min-width: 1080px) {
          .v3-row-2col {
            grid-template-columns: 1fr 1fr;
            align-items: start;
          }
        }
        .v3-error {
          background: var(--color-bad-bg, rgba(220, 38, 38, 0.05));
          border: 1px solid var(--color-bad, #dc2626);
          border-radius: 8px;
          padding: 14px 16px;
          margin-bottom: 20px;
          font-size: 13px;
          color: var(--color-fg);
        }
        .v3-error-hint {
          margin-top: 4px;
          font-size: 12px;
          color: var(--color-muted);
        }
      `}})]})}function w({label:a,value:c,sub:d,tone:e}){return(0,b.jsxs)("div",{style:{background:"var(--color-surface)",border:"1px solid var(--color-border)",borderRadius:10,padding:"14px 16px",display:"flex",flexDirection:"column",gap:4},children:[(0,b.jsx)("div",{style:{fontSize:10.5,color:"var(--color-muted)",textTransform:"uppercase",letterSpacing:"0.05em",fontWeight:600},children:a}),(0,b.jsx)("div",{style:{fontSize:24,fontWeight:700,color:"warn"===e?"var(--color-bad)":"accent"===e?"var(--color-accent)":"var(--color-fg)",letterSpacing:"-0.02em",fontVariantNumeric:"tabular-nums",lineHeight:1.1},children:c}),(0,b.jsx)("div",{style:{fontSize:11,color:"var(--color-muted-2)"},children:d})]})}a.s(["default",0,v,"metadata",0,{title:"Satış Performansı · V3 · Insider"}],62128)},59951,a=>{a.n(a.i(62128))}];

//# sourceMappingURL=apps_dashboard_10jfvio._.js.map