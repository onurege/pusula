module.exports=[33910,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_saha-operasyon_page_actions_12ixyi1.js.map