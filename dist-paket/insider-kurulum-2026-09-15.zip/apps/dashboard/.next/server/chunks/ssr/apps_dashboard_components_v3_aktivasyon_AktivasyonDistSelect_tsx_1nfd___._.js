module.exports=[81059,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);a.s(["AktivasyonDistSelect",0,function({distributors:a,selectedDistId:e}){let f=(0,c.useRouter)(),g=(0,c.usePathname)(),h=(0,c.useSearchParams)(),[i,j]=(0,d.useTransition)();return 0===a.length?null:(0,b.jsxs)("div",{className:"aktivasyon-dist-select",children:[(0,b.jsx)("label",{htmlFor:"aktivasyon-dist-select",className:"lbl",children:"Distribütör"}),(0,b.jsxs)("select",{id:"aktivasyon-dist-select",value:e??"all",onChange:function(a){let b=a.target.value,c=new URLSearchParams(h?.toString()??"");""===b||"all"===b?c.delete("distId"):c.set("distId",b);let d=c.toString();j(()=>{f.push(`${g}${d?`?${d}`:""}`)})},disabled:i,className:"sel",children:[(0,b.jsx)("option",{value:"all",children:"Tümü — portföy toplamı"}),a.map(a=>(0,b.jsx)("option",{value:a.id,children:a.ad},a.id))]}),i&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .aktivasyon-dist-select {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }
        .aktivasyon-dist-select .lbl {
          font-size: 11px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .aktivasyon-dist-select .sel {
          flex: 1;
          min-width: 260px;
          padding: 8px 12px;
          font-size: 13px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
          cursor: pointer;
        }
        .aktivasyon-dist-select .sel:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .aktivasyon-dist-select .sel:focus {
          outline: 2px solid var(--color-accent);
          outline-offset: 2px;
        }
        .aktivasyon-dist-select .loading {
          font-size: 11px;
          color: var(--color-muted);
          font-style: italic;
        }
      `}})]})}])}];

//# sourceMappingURL=apps_dashboard_components_v3_aktivasyon_AktivasyonDistSelect_tsx_1nfd___._.js.map