module.exports=[5124,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_page_actions_0aq2l71.js.map