module.exports=[12755,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_cockpit_page_actions_0_0_4nx.js.map