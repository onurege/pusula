module.exports=[59562,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_v3_ticari-yatirim_page_actions_0n5orz2.js.map