module.exports=[73478,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);let e=/^\d{4}-\d{2}-\d{2}$/,f=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];a.s(["GlobalDonemFilter",0,function(){let a=(0,c.useRouter)(),g=(0,c.usePathname)(),h=(0,c.useSearchParams)(),[i,j]=(0,d.useTransition)(),k=h?.get("from")??"",l=h?.get("to")??"",m=(h?.get("donem")??"").toLowerCase(),n=e.test(k)&&e.test(l),o=n?"serbest":m&&"son30g"!==m?m:"son30g",[p,q]=(0,d.useState)(n),[r,s]=(0,d.useState)(k),[t,u]=(0,d.useState)(l),v=e.test(r),w=e.test(t),x=v&&w&&r>t,y=v&&w&&!x;function z(b){let c=new URLSearchParams(h?.toString()??"");b(c);let d=c.toString();j(()=>a.push(`${g}${d?`?${d}`:""}`))}return(0,b.jsxs)("div",{className:"donem-filter",children:[(0,b.jsx)("span",{className:"lbl",children:"Dönem"}),(0,b.jsxs)("div",{className:"chips",children:[f.map(a=>(0,b.jsx)("button",{type:"button",className:`chip ${o===a.key?"on":""}`,onClick:()=>{var b;return b=a.key,void(q(!1),z(a=>{a.delete("from"),a.delete("to"),"son30g"===b?a.delete("donem"):a.set("donem",b)}))},disabled:i,children:a.label},a.key)),(0,b.jsx)("button",{type:"button",className:`chip ${"serbest"===o||p?"on":""}`,onClick:()=>q(a=>!a),disabled:i,children:"Serbest"})]}),(p||"serbest"===o)&&(0,b.jsxs)("div",{className:"range",children:[(0,b.jsx)("input",{type:"date",value:r,max:t||void 0,onChange:a=>s(a.target.value),disabled:i,className:"inp","aria-label":"Başlangıç tarihi"}),(0,b.jsx)("span",{className:"sep",children:"–"}),(0,b.jsx)("input",{type:"date",value:t,min:r||void 0,onChange:a=>u(a.target.value),disabled:i,className:"inp","aria-label":"Bitiş tarihi"}),(0,b.jsx)("button",{type:"button",className:"apply",onClick:function(){y&&z(a=>{a.delete("donem"),a.set("from",r),a.set("to",t)})},disabled:i||!y,children:"Uygula"}),x&&(0,b.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),i&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},19878,a=>{"use strict";a.i(87924),a.s(["formatCompact",0,function(a){return Number.isFinite(a)?Math.abs(a)>=1e9?(a/1e9).toFixed(1)+"Mr":Math.abs(a)>=1e6?(a/1e6).toFixed(1)+"M":Math.abs(a)>=1e3?(a/1e3).toFixed(1)+"K":Math.round(a).toString():"0"},"truncate",0,function(a,b){return a.length>b?a.slice(0,b-1)+"…":a}])},72443,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(72131);a.s(["StokDistSelect",0,function({distributors:a,selectedDistId:e}){let f=(0,c.useRouter)(),g=(0,c.usePathname)(),h=(0,c.useSearchParams)(),[i,j]=(0,d.useTransition)(),k=a.reduce((a,b)=>a+b.criticalCount+b.riskCount,0);return(0,b.jsxs)("div",{className:"stok-dist-select",children:[(0,b.jsx)("label",{htmlFor:"dist-select",className:"lbl",children:"Distribütör"}),(0,b.jsxs)("select",{id:"dist-select",value:e??"all",onChange:function(a){let b=a.target.value,c=new URLSearchParams(h?.toString()??"");""===b||"all"===b?c.delete("distId"):c.set("distId",b);let d=c.toString();j(()=>{f.push(`${g}${d?`?${d}`:""}`)})},disabled:i,className:"sel",children:[(0,b.jsxs)("option",{value:"all",children:["Tümü — portföy toplamı (",k," kritik+risk)"]}),a.map(a=>{let c=a.criticalCount+a.riskCount,d=a.region?` \xb7 ${a.region}`:"";return(0,b.jsxs)("option",{value:a.distId,children:[a.distName,d," — ",c>0?`${c} kritik+risk`:"sağlıklı"," · ",a.skuCount," SKU"]},a.distId)})]}),i&&(0,b.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .stok-dist-select {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }
        .stok-dist-select .lbl {
          font-size: 11px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .stok-dist-select .sel {
          flex: 1;
          min-width: 260px;
          padding: 8px 12px;
          font-size: 13px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
          cursor: pointer;
        }
        .stok-dist-select .sel:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .stok-dist-select .sel:focus {
          outline: 2px solid var(--color-accent);
          outline-offset: 2px;
        }
        .stok-dist-select .loading {
          font-size: 11px;
          color: var(--color-muted);
          font-style: italic;
        }
      `}})]})}])},20050,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(19878);let e=[25,50];function f({tier:a}){return(0,b.jsx)("span",{className:`risk-badge risk-${a}`,children:{critical:"Kritik",risk:"Risk",watch:"İzle",healthy:"Sağlıklı",unknown:"Belirsiz"}[a]})}function g(a){return Math.abs(a)>=1e4?(0,d.formatCompact)(a):a.toLocaleString("tr-TR",{maximumFractionDigits:+(a!==Math.trunc(a))})}a.s(["StokSkuTable",0,function({rows:a}){let[d,h]=(0,c.useState)(0),[i,j]=(0,c.useState)(25),k=Math.max(1,Math.ceil(a.length/i)),l=Math.min(d,k-1),m=(0,c.useMemo)(()=>a.slice(l*i,l*i+i),[a,l,i]),n=0===a.length?0:l*i+1,o=Math.min(a.length,l*i+m.length);function p(a){h(Math.min(Math.max(a,0),k-1))}return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("div",{className:"stok-table-wrap",children:(0,b.jsxs)("table",{className:"stok-table",children:[(0,b.jsx)("thead",{children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{children:"SKU"}),(0,b.jsx)("th",{children:"Distribütör"}),(0,b.jsx)("th",{children:"Marka"}),(0,b.jsx)("th",{children:"Risk"}),(0,b.jsx)("th",{className:"num",children:"Kalan"}),(0,b.jsx)("th",{children:"Tükenme"}),(0,b.jsx)("th",{className:"num",children:"Stok"}),(0,b.jsx)("th",{className:"num",children:"90g Satış"}),(0,b.jsx)("th",{className:"num",children:"Tahmin/gün"}),(0,b.jsx)("th",{className:"num",children:"Devir"}),(0,b.jsx)("th",{className:"num",children:"ROP"}),(0,b.jsx)("th",{className:"num",children:"Eksik"})]})}),(0,b.jsxs)("tbody",{children:[0===m.length&&(0,b.jsx)("tr",{children:(0,b.jsx)("td",{colSpan:12,className:"stok-empty",children:"Kayıt yok."})}),m.map(a=>{var c,d;return(0,b.jsxs)("tr",{children:[(0,b.jsx)("td",{children:(0,b.jsxs)("div",{className:"stok-sku",children:[(0,b.jsx)("span",{className:"stok-sku-name",children:a.skuName}),(0,b.jsx)("span",{className:"stok-sku-code",children:a.skuCode||`#${a.skuId}`})]})}),(0,b.jsx)("td",{children:a.distName}),(0,b.jsx)("td",{children:a.brand??"-"}),(0,b.jsx)("td",{children:(0,b.jsxs)("div",{className:"stok-risk-cell",children:[(0,b.jsx)(f,{tier:a.riskTier}),a.lowConfidence&&(0,b.jsx)("span",{className:"stok-lowconf",title:`D\xfcş\xfck g\xfcven: eldeki stok toplam hareketin yalnızca %${a.netSignalPct??"?"}'i — b\xfcy\xfck giriş/\xe7ıkış akışının k\xfc\xe7\xfck farkı. Tek kaydedilmemiş giriş bu sonucu tersine \xe7evirebilir. Fiziksel stok sayımıyla doğrulanmalı.`,children:"düşük güven"}),(0,b.jsxs)("span",{className:`confidence confidence-${a.stockConfidence}`,children:[{high:"yüksek",medium:"orta",low:"düşük"}[a.stockConfidence]," · ",a.stockConfidenceScore]})]})}),(0,b.jsx)("td",{className:"num",children:null!=(c=a.daysLeft)&&Number.isFinite(c)?c<1?"<1 gün":`${c<10?c.toFixed(1):Math.round(c).toLocaleString("tr-TR")} g\xfcn`:"-"}),(0,b.jsx)("td",{children:a.estimatedStockoutDate?(d=a.estimatedStockoutDate,new Date(`${d}T12:00:00`).toLocaleDateString("tr-TR",{day:"2-digit",month:"short"})):"-"}),(0,b.jsx)("td",{className:"num",children:g(a.onHandQty)}),(0,b.jsx)("td",{className:"num",children:g(a.soldQty90d)}),(0,b.jsx)("td",{className:"num",children:(0,b.jsx)("span",{title:`Croston 180g: ${g(a.crostonDailyQty)} \xb7 trend x${a.trendFactor.toFixed(2)} \xb7 mevsim x${a.seasonalityFactor.toFixed(2)}${a.seasonalityReason?` (${a.seasonalityReason})`:""}`,children:g(a.forecastDailyQty)})}),(0,b.jsx)("td",{className:"num",children:null==a.turnover90d?"-":a.turnover90d.toFixed(2)}),(0,b.jsx)("td",{className:"num",children:(0,b.jsx)("span",{title:`Lead time: ${a.leadTimeDays} g\xfcn (${"dist-table"===a.leadTimeSource?"distribütör tanımı":"varsayılan"}) \xb7 emniyet stok: ${g(a.safetyStockQty)}`,children:g(a.reorderPointQty)})}),(0,b.jsx)("td",{className:"num",children:(0,b.jsx)("span",{title:`ROP - envanter pozisyonu. Pozisyon: stok ${g(a.onHandQty)} + yolda ${g(a.openOrderQty)} = ${g(a.inventoryPositionQty)}`,children:a.reorderGapQty>0?g(a.reorderGapQty):"-"})})]},`${a.distId}-${a.skuId}`)})]})]})}),(0,b.jsxs)("div",{className:"stok-pagination",children:[(0,b.jsxs)("span",{className:"stok-pagination-count",children:[n.toLocaleString("tr-TR"),"-",o.toLocaleString("tr-TR")," / ",a.length.toLocaleString("tr-TR")," SKU"]}),(0,b.jsxs)("div",{className:"stok-pagination-controls",children:[(0,b.jsxs)("label",{className:"stok-pagination-size",children:["Sayfa başına",(0,b.jsx)("select",{value:i,onChange:function(a){let b=Number(a.target.value),c=l*i;j(b),h(Math.floor(c/b))},children:e.map(a=>(0,b.jsx)("option",{value:a,children:a},a))})]}),(0,b.jsx)("button",{type:"button",className:"stok-pagination-btn",onClick:()=>p(l-1),disabled:l<=0,children:"‹ Geri"}),(0,b.jsxs)("span",{className:"stok-pagination-page",children:["Sayfa ",l+1," / ",k]}),(0,b.jsx)("button",{type:"button",className:"stok-pagination-btn",onClick:()=>p(l+1),disabled:l>=k-1,children:"İleri ›"})]})]}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .stok-empty {
          text-align: center;
          color: var(--color-muted);
          padding: 24px 12px;
        }
        .stok-pagination {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          flex-wrap: wrap;
          padding: 10px 16px;
          border-top: 1px solid var(--color-border);
          font-size: 12px;
        }
        .stok-pagination-count {
          color: var(--color-muted);
          font-variant-numeric: tabular-nums;
        }
        .stok-pagination-controls {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .stok-pagination-size {
          display: flex;
          align-items: center;
          gap: 6px;
          color: var(--color-muted);
          font-size: 11.5px;
        }
        .stok-pagination-size select {
          padding: 4px 6px;
          font-size: 12px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 5px;
          color: var(--color-fg);
          font-family: inherit;
        }
        .stok-pagination-btn {
          padding: 5px 10px;
          font-size: 12px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 5px;
          color: var(--color-fg);
          cursor: pointer;
          font-family: inherit;
        }
        .stok-pagination-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }
        .stok-pagination-btn:not(:disabled):hover {
          background: var(--color-surface-2);
        }
        .stok-pagination-page {
          color: var(--color-fg);
          font-variant-numeric: tabular-nums;
          white-space: nowrap;
        }
      `}})]})}])}];

//# sourceMappingURL=apps_dashboard_components_0xgm52h._.js.map