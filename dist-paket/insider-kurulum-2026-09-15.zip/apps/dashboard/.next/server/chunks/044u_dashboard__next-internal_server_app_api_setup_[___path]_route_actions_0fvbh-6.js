module.exports=[5560,s=>{"use strict";s.s([])}];

//# sourceMappingURL=044u_dashboard__next-internal_server_app_api_setup_%5B___path%5D_route_actions_0fvbh-6.js.map