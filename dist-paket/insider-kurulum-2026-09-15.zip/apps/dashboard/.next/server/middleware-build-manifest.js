globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/tz3dlNN-7w94mcdrymPbW/_buildManifest.js",
    "static/tz3dlNN-7w94mcdrymPbW/_ssgManifest.js",
    "static/tz3dlNN-7w94mcdrymPbW/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/33em8nvf7pgp5.js",
    "static/chunks/25vlqm6-j07f_.js",
    "static/chunks/1avjgpdr5f6pf.js",
    "static/chunks/1y8cydman_po2.js",
    "static/chunks/2w6dec4xrihh4.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/turbopack-30hew1v0jlon4.js"
  ]
};
