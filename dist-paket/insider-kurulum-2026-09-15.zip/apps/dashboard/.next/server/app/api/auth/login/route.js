var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__1c5z602._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/apps_dashboard__next-internal_server_app_api_auth_login_route_actions_0cqj66c.js")
R.m(34387)
module.exports=R.m(34387).exports
