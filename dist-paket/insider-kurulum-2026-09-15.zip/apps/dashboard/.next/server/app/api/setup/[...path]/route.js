var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/setup/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1x_s33s._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/044u_dashboard__next-internal_server_app_api_setup_[___path]_route_actions_0fvbh-6.js")
R.m(13904)
module.exports=R.m(13904).exports
