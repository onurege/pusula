var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/distributors/route.js")
R.c("server/chunks/[root-of-the-server]__1mb-f-3._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1ednx_e._.js")
R.c("server/chunks/044u_dashboard__next-internal_server_app_api_auth_distributors_route_actions_0vi74xc.js")
R.m(60363)
module.exports=R.m(60363).exports
