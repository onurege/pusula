var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__1atqann._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/apps_dashboard__next-internal_server_app_api_auth_logout_route_actions_0zt-q41.js")
R.m(96233)
module.exports=R.m(96233).exports
