var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__0dnemsi._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1ednx_e._.js")
R.c("server/chunks/044u_dashboard__next-internal_server_app_api_admin_[___path]_route_actions_0fo3v-k.js")
R.m(56281)
module.exports=R.m(56281).exports
