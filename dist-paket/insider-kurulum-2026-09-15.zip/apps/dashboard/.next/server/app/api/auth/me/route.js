var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__1fsdf37._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1ednx_e._.js")
R.c("server/chunks/apps_dashboard__next-internal_server_app_api_auth_me_route_actions_02xyex0.js")
R.m(90626)
module.exports=R.m(90626).exports
