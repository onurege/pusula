(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,29924,e=>{"use strict";var r=e.i(43476),o=e.i(18566),t=e.i(71645);let a=/^\d{4}-\d{2}-\d{2}$/,l=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];e.s(["GlobalDonemFilter",0,function(){let e=(0,o.useRouter)(),i=(0,o.usePathname)(),n=(0,o.useSearchParams)(),[s,c]=(0,t.useTransition)(),d=n?.get("from")??"",p=n?.get("to")??"",u=(n?.get("donem")??"").toLowerCase(),g=a.test(d)&&a.test(p),m=g?"serbest":u&&"son30g"!==u?u:"son30g",[f,b]=(0,t.useState)(g),[x,h]=(0,t.useState)(d),[v,y]=(0,t.useState)(p),k=a.test(x),j=a.test(v),S=k&&j&&x>v,w=k&&j&&!S;function N(r){let o=new URLSearchParams(n?.toString()??"");r(o);let t=o.toString();c(()=>e.push(`${i}${t?`?${t}`:""}`))}return(0,r.jsxs)("div",{className:"donem-filter",children:[(0,r.jsx)("span",{className:"lbl",children:"Dönem"}),(0,r.jsxs)("div",{className:"chips",children:[l.map(e=>(0,r.jsx)("button",{type:"button",className:`chip ${m===e.key?"on":""}`,onClick:()=>{var r;return r=e.key,void(b(!1),N(e=>{e.delete("from"),e.delete("to"),"son30g"===r?e.delete("donem"):e.set("donem",r)}))},disabled:s,children:e.label},e.key)),(0,r.jsx)("button",{type:"button",className:`chip ${"serbest"===m||f?"on":""}`,onClick:()=>b(e=>!e),disabled:s,children:"Serbest"})]}),(f||"serbest"===m)&&(0,r.jsxs)("div",{className:"range",children:[(0,r.jsx)("input",{type:"date",value:x,max:v||void 0,onChange:e=>h(e.target.value),disabled:s,className:"inp","aria-label":"Başlangıç tarihi"}),(0,r.jsx)("span",{className:"sep",children:"–"}),(0,r.jsx)("input",{type:"date",value:v,min:x||void 0,onChange:e=>y(e.target.value),disabled:s,className:"inp","aria-label":"Bitiş tarihi"}),(0,r.jsx)("button",{type:"button",className:"apply",onClick:function(){w&&N(e=>{e.delete("donem"),e.set("from",x),e.set("to",v)})},disabled:s||!w,children:"Uygula"}),S&&(0,r.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),s&&(0,r.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,r.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},197,e=>{"use strict";var r=e.i(43476),o=e.i(22016),t=e.i(18566),a=e.i(12362);e.s(["SatisUnitToggle",0,function(){let e=(0,t.usePathname)()??"/",l=(0,t.useSearchParams)(),i=(0,a.useTenant)(),n=i.volume.key,s=l.get("unit")===n?n:"tl",c=[{id:"tl",label:`${i.currencySymbol} TL`,hint:"Ciro (net tutar) bazlı görünüm"},{id:n,label:i.volume.short,hint:i.volume.hint}];return(0,r.jsxs)("div",{role:"tablist","aria-label":"Birim",className:"satis-unit-toggle",title:`TL ↔ ${i.volume.short} g\xf6r\xfcn\xfcm anahtarı — sunucu sorgusu değişmez, yalnızca g\xf6sterim.`,children:[(0,r.jsx)("span",{className:"lbl",children:"Birim"}),c.map(t=>{var a;let i,n,c=s===t.id;return(0,r.jsx)(o.default,{href:(a=t.id,i=new URLSearchParams(l.toString()),"tl"===a?i.delete("unit"):i.set("unit",a),(n=i.toString())?`${e}?${n}`:e),role:"tab","aria-selected":c,title:t.hint,className:`opt${c?" active":""}`,children:t.label},t.id)}),(0,r.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .satis-unit-toggle {
          display: inline-flex; align-items: center; gap: 4px;
          padding: 4px;
          border-radius: 8px;
          background: var(--color-surface-2);
          border: 1px solid var(--color-border);
        }
        .satis-unit-toggle .lbl {
          padding: 0 8px;
          font-size: 10.5px;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--color-muted);
          font-weight: 600;
        }
        .satis-unit-toggle .opt {
          display: inline-flex; align-items: center;
          height: 28px; padding: 0 12px;
          border-radius: 6px;
          font-size: 12px; font-weight: 600;
          color: var(--color-muted);
          text-decoration: none;
          transition: background-color 0.15s ease, color 0.15s ease;
        }
        .satis-unit-toggle .opt:hover { color: var(--color-fg); }
        .satis-unit-toggle .opt.active {
          background: var(--color-surface);
          color: var(--color-fg);
          border: 1px solid var(--color-border);
          box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        }
      `}})]})}])}]);