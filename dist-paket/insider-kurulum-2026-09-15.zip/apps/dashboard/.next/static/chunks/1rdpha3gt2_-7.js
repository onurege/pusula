(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,29924,e=>{"use strict";var t=e.i(43476),a=e.i(18566),r=e.i(71645);let o=/^\d{4}-\d{2}-\d{2}$/,s=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];e.s(["GlobalDonemFilter",0,function(){let e=(0,a.useRouter)(),n=(0,a.usePathname)(),i=(0,a.useSearchParams)(),[l,c]=(0,r.useTransition)(),d=i?.get("from")??"",p=i?.get("to")??"",u=(i?.get("donem")??"").toLowerCase(),x=o.test(d)&&o.test(p),m=x?"serbest":u&&"son30g"!==u?u:"son30g",[h,g]=(0,r.useState)(x),[f,b]=(0,r.useState)(d),[k,y]=(0,r.useState)(p),v=o.test(f),j=o.test(k),N=v&&j&&f>k,S=v&&j&&!N;function w(t){let a=new URLSearchParams(i?.toString()??"");t(a);let r=a.toString();c(()=>e.push(`${n}${r?`?${r}`:""}`))}return(0,t.jsxs)("div",{className:"donem-filter",children:[(0,t.jsx)("span",{className:"lbl",children:"Dönem"}),(0,t.jsxs)("div",{className:"chips",children:[s.map(e=>(0,t.jsx)("button",{type:"button",className:`chip ${m===e.key?"on":""}`,onClick:()=>{var t;return t=e.key,void(g(!1),w(e=>{e.delete("from"),e.delete("to"),"son30g"===t?e.delete("donem"):e.set("donem",t)}))},disabled:l,children:e.label},e.key)),(0,t.jsx)("button",{type:"button",className:`chip ${"serbest"===m||h?"on":""}`,onClick:()=>g(e=>!e),disabled:l,children:"Serbest"})]}),(h||"serbest"===m)&&(0,t.jsxs)("div",{className:"range",children:[(0,t.jsx)("input",{type:"date",value:f,max:k||void 0,onChange:e=>b(e.target.value),disabled:l,className:"inp","aria-label":"Başlangıç tarihi"}),(0,t.jsx)("span",{className:"sep",children:"–"}),(0,t.jsx)("input",{type:"date",value:k,min:f||void 0,onChange:e=>y(e.target.value),disabled:l,className:"inp","aria-label":"Bitiş tarihi"}),(0,t.jsx)("button",{type:"button",className:"apply",onClick:function(){S&&w(e=>{e.delete("donem"),e.set("from",f),e.set("to",k)})},disabled:l||!S,children:"Uygula"}),N&&(0,t.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),l&&(0,t.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,t.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},54198,e=>{"use strict";e.i(43476),e.s(["formatCompact",0,function(e){return Number.isFinite(e)?Math.abs(e)>=1e9?(e/1e9).toFixed(1)+"Mr":Math.abs(e)>=1e6?(e/1e6).toFixed(1)+"M":Math.abs(e)>=1e3?(e/1e3).toFixed(1)+"K":Math.round(e).toString():"0"},"truncate",0,function(e,t){return e.length>t?e.slice(0,t-1)+"…":e}])},3830,e=>{"use strict";var t=e.i(43476),a=e.i(18566),r=e.i(71645);e.s(["StokDistSelect",0,function({distributors:e,selectedDistId:o}){let s=(0,a.useRouter)(),n=(0,a.usePathname)(),i=(0,a.useSearchParams)(),[l,c]=(0,r.useTransition)(),d=e.reduce((e,t)=>e+t.criticalCount+t.riskCount,0);return(0,t.jsxs)("div",{className:"stok-dist-select",children:[(0,t.jsx)("label",{htmlFor:"dist-select",className:"lbl",children:"Distribütör"}),(0,t.jsxs)("select",{id:"dist-select",value:o??"all",onChange:function(e){let t=e.target.value,a=new URLSearchParams(i?.toString()??"");""===t||"all"===t?a.delete("distId"):a.set("distId",t);let r=a.toString();c(()=>{s.push(`${n}${r?`?${r}`:""}`)})},disabled:l,className:"sel",children:[(0,t.jsxs)("option",{value:"all",children:["Tümü — portföy toplamı (",d," kritik+risk)"]}),e.map(e=>{let a=e.criticalCount+e.riskCount,r=e.region?` \xb7 ${e.region}`:"";return(0,t.jsxs)("option",{value:e.distId,children:[e.distName,r," — ",a>0?`${a} kritik+risk`:"sağlıklı"," · ",e.skuCount," SKU"]},e.distId)})]}),l&&(0,t.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,t.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .stok-dist-select {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }
        .stok-dist-select .lbl {
          font-size: 11px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .stok-dist-select .sel {
          flex: 1;
          min-width: 260px;
          padding: 8px 12px;
          font-size: 13px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
          cursor: pointer;
        }
        .stok-dist-select .sel:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .stok-dist-select .sel:focus {
          outline: 2px solid var(--color-accent);
          outline-offset: 2px;
        }
        .stok-dist-select .loading {
          font-size: 11px;
          color: var(--color-muted);
          font-style: italic;
        }
      `}})]})}])},81757,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(54198);let o=[25,50];function s({tier:e}){return(0,t.jsx)("span",{className:`risk-badge risk-${e}`,children:{critical:"Kritik",risk:"Risk",watch:"İzle",healthy:"Sağlıklı",unknown:"Belirsiz"}[e]})}function n(e){return Math.abs(e)>=1e4?(0,r.formatCompact)(e):e.toLocaleString("tr-TR",{maximumFractionDigits:+(e!==Math.trunc(e))})}e.s(["StokSkuTable",0,function({rows:e}){let[r,i]=(0,a.useState)(0),[l,c]=(0,a.useState)(25),d=Math.max(1,Math.ceil(e.length/l)),p=Math.min(r,d-1),u=(0,a.useMemo)(()=>e.slice(p*l,p*l+l),[e,p,l]),x=0===e.length?0:p*l+1,m=Math.min(e.length,p*l+u.length);function h(e){i(Math.min(Math.max(e,0),d-1))}return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"stok-table-wrap",children:(0,t.jsxs)("table",{className:"stok-table",children:[(0,t.jsx)("thead",{children:(0,t.jsxs)("tr",{children:[(0,t.jsx)("th",{children:"SKU"}),(0,t.jsx)("th",{children:"Distribütör"}),(0,t.jsx)("th",{children:"Marka"}),(0,t.jsx)("th",{children:"Risk"}),(0,t.jsx)("th",{className:"num",children:"Kalan"}),(0,t.jsx)("th",{children:"Tükenme"}),(0,t.jsx)("th",{className:"num",children:"Stok"}),(0,t.jsx)("th",{className:"num",children:"90g Satış"}),(0,t.jsx)("th",{className:"num",children:"Tahmin/gün"}),(0,t.jsx)("th",{className:"num",children:"Devir"}),(0,t.jsx)("th",{className:"num",children:"ROP"}),(0,t.jsx)("th",{className:"num",children:"Eksik"})]})}),(0,t.jsxs)("tbody",{children:[0===u.length&&(0,t.jsx)("tr",{children:(0,t.jsx)("td",{colSpan:12,className:"stok-empty",children:"Kayıt yok."})}),u.map(e=>{var a,r;return(0,t.jsxs)("tr",{children:[(0,t.jsx)("td",{children:(0,t.jsxs)("div",{className:"stok-sku",children:[(0,t.jsx)("span",{className:"stok-sku-name",children:e.skuName}),(0,t.jsx)("span",{className:"stok-sku-code",children:e.skuCode||`#${e.skuId}`})]})}),(0,t.jsx)("td",{children:e.distName}),(0,t.jsx)("td",{children:e.brand??"-"}),(0,t.jsx)("td",{children:(0,t.jsxs)("div",{className:"stok-risk-cell",children:[(0,t.jsx)(s,{tier:e.riskTier}),e.lowConfidence&&(0,t.jsx)("span",{className:"stok-lowconf",title:`D\xfcş\xfck g\xfcven: eldeki stok toplam hareketin yalnızca %${e.netSignalPct??"?"}'i — b\xfcy\xfck giriş/\xe7ıkış akışının k\xfc\xe7\xfck farkı. Tek kaydedilmemiş giriş bu sonucu tersine \xe7evirebilir. Fiziksel stok sayımıyla doğrulanmalı.`,children:"düşük güven"}),(0,t.jsxs)("span",{className:`confidence confidence-${e.stockConfidence}`,children:[{high:"yüksek",medium:"orta",low:"düşük"}[e.stockConfidence]," · ",e.stockConfidenceScore]})]})}),(0,t.jsx)("td",{className:"num",children:null!=(a=e.daysLeft)&&Number.isFinite(a)?a<1?"<1 gün":`${a<10?a.toFixed(1):Math.round(a).toLocaleString("tr-TR")} g\xfcn`:"-"}),(0,t.jsx)("td",{children:e.estimatedStockoutDate?(r=e.estimatedStockoutDate,new Date(`${r}T12:00:00`).toLocaleDateString("tr-TR",{day:"2-digit",month:"short"})):"-"}),(0,t.jsx)("td",{className:"num",children:n(e.onHandQty)}),(0,t.jsx)("td",{className:"num",children:n(e.soldQty90d)}),(0,t.jsx)("td",{className:"num",children:(0,t.jsx)("span",{title:`Croston 180g: ${n(e.crostonDailyQty)} \xb7 trend x${e.trendFactor.toFixed(2)} \xb7 mevsim x${e.seasonalityFactor.toFixed(2)}${e.seasonalityReason?` (${e.seasonalityReason})`:""}`,children:n(e.forecastDailyQty)})}),(0,t.jsx)("td",{className:"num",children:null==e.turnover90d?"-":e.turnover90d.toFixed(2)}),(0,t.jsx)("td",{className:"num",children:(0,t.jsx)("span",{title:`Lead time: ${e.leadTimeDays} g\xfcn (${"dist-table"===e.leadTimeSource?"distribütör tanımı":"varsayılan"}) \xb7 emniyet stok: ${n(e.safetyStockQty)}`,children:n(e.reorderPointQty)})}),(0,t.jsx)("td",{className:"num",children:(0,t.jsx)("span",{title:`ROP - envanter pozisyonu. Pozisyon: stok ${n(e.onHandQty)} + yolda ${n(e.openOrderQty)} = ${n(e.inventoryPositionQty)}`,children:e.reorderGapQty>0?n(e.reorderGapQty):"-"})})]},`${e.distId}-${e.skuId}`)})]})]})}),(0,t.jsxs)("div",{className:"stok-pagination",children:[(0,t.jsxs)("span",{className:"stok-pagination-count",children:[x.toLocaleString("tr-TR"),"-",m.toLocaleString("tr-TR")," / ",e.length.toLocaleString("tr-TR")," SKU"]}),(0,t.jsxs)("div",{className:"stok-pagination-controls",children:[(0,t.jsxs)("label",{className:"stok-pagination-size",children:["Sayfa başına",(0,t.jsx)("select",{value:l,onChange:function(e){let t=Number(e.target.value),a=p*l;c(t),i(Math.floor(a/t))},children:o.map(e=>(0,t.jsx)("option",{value:e,children:e},e))})]}),(0,t.jsx)("button",{type:"button",className:"stok-pagination-btn",onClick:()=>h(p-1),disabled:p<=0,children:"‹ Geri"}),(0,t.jsxs)("span",{className:"stok-pagination-page",children:["Sayfa ",p+1," / ",d]}),(0,t.jsx)("button",{type:"button",className:"stok-pagination-btn",onClick:()=>h(p+1),disabled:p>=d-1,children:"İleri ›"})]})]}),(0,t.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .stok-empty {
          text-align: center;
          color: var(--color-muted);
          padding: 24px 12px;
        }
        .stok-pagination {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          flex-wrap: wrap;
          padding: 10px 16px;
          border-top: 1px solid var(--color-border);
          font-size: 12px;
        }
        .stok-pagination-count {
          color: var(--color-muted);
          font-variant-numeric: tabular-nums;
        }
        .stok-pagination-controls {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .stok-pagination-size {
          display: flex;
          align-items: center;
          gap: 6px;
          color: var(--color-muted);
          font-size: 11.5px;
        }
        .stok-pagination-size select {
          padding: 4px 6px;
          font-size: 12px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 5px;
          color: var(--color-fg);
          font-family: inherit;
        }
        .stok-pagination-btn {
          padding: 5px 10px;
          font-size: 12px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 5px;
          color: var(--color-fg);
          cursor: pointer;
          font-family: inherit;
        }
        .stok-pagination-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }
        .stok-pagination-btn:not(:disabled):hover {
          background: var(--color-surface-2);
        }
        .stok-pagination-page {
          color: var(--color-fg);
          font-variant-numeric: tabular-nums;
          white-space: nowrap;
        }
      `}})]})}])}]);