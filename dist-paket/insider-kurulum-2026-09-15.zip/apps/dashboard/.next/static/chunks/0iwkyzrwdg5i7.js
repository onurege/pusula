(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,52862,e=>{"use strict";var t=e.i(43476),s=e.i(18566),a=e.i(71645);e.s(["AktivasyonDistSelect",0,function({distributors:e,selectedDistId:l}){let o=(0,s.useRouter)(),i=(0,s.usePathname)(),r=(0,s.useSearchParams)(),[n,c]=(0,a.useTransition)();return 0===e.length?null:(0,t.jsxs)("div",{className:"aktivasyon-dist-select",children:[(0,t.jsx)("label",{htmlFor:"aktivasyon-dist-select",className:"lbl",children:"Distribütör"}),(0,t.jsxs)("select",{id:"aktivasyon-dist-select",value:l??"all",onChange:function(e){let t=e.target.value,s=new URLSearchParams(r?.toString()??"");""===t||"all"===t?s.delete("distId"):s.set("distId",t);let a=s.toString();c(()=>{o.push(`${i}${a?`?${a}`:""}`)})},disabled:n,className:"sel",children:[(0,t.jsx)("option",{value:"all",children:"Tümü — portföy toplamı"}),e.map(e=>(0,t.jsx)("option",{value:e.id,children:e.ad},e.id))]}),n&&(0,t.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,t.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .aktivasyon-dist-select {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }
        .aktivasyon-dist-select .lbl {
          font-size: 11px;
          font-weight: 600;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .aktivasyon-dist-select .sel {
          flex: 1;
          min-width: 260px;
          padding: 8px 12px;
          font-size: 13px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
          cursor: pointer;
        }
        .aktivasyon-dist-select .sel:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .aktivasyon-dist-select .sel:focus {
          outline: 2px solid var(--color-accent);
          outline-offset: 2px;
        }
        .aktivasyon-dist-select .loading {
          font-size: 11px;
          color: var(--color-muted);
          font-style: italic;
        }
      `}})]})}])}]);