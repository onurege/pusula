(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,29924,e=>{"use strict";var o=e.i(43476),r=e.i(18566),a=e.i(71645);let l=/^\d{4}-\d{2}-\d{2}$/,t=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];e.s(["GlobalDonemFilter",0,function(){let e=(0,r.useRouter)(),n=(0,r.usePathname)(),i=(0,r.useSearchParams)(),[s,c]=(0,a.useTransition)(),d=i?.get("from")??"",p=i?.get("to")??"",f=(i?.get("donem")??"").toLowerCase(),m=l.test(d)&&l.test(p),u=m?"serbest":f&&"son30g"!==f?f:"son30g",[b,g]=(0,a.useState)(m),[x,h]=(0,a.useState)(d),[v,y]=(0,a.useState)(p),k=l.test(x),j=l.test(v),w=k&&j&&x>v,N=k&&j&&!w;function S(o){let r=new URLSearchParams(i?.toString()??"");o(r);let a=r.toString();c(()=>e.push(`${n}${a?`?${a}`:""}`))}return(0,o.jsxs)("div",{className:"donem-filter",children:[(0,o.jsx)("span",{className:"lbl",children:"Dönem"}),(0,o.jsxs)("div",{className:"chips",children:[t.map(e=>(0,o.jsx)("button",{type:"button",className:`chip ${u===e.key?"on":""}`,onClick:()=>{var o;return o=e.key,void(g(!1),S(e=>{e.delete("from"),e.delete("to"),"son30g"===o?e.delete("donem"):e.set("donem",o)}))},disabled:s,children:e.label},e.key)),(0,o.jsx)("button",{type:"button",className:`chip ${"serbest"===u||b?"on":""}`,onClick:()=>g(e=>!e),disabled:s,children:"Serbest"})]}),(b||"serbest"===u)&&(0,o.jsxs)("div",{className:"range",children:[(0,o.jsx)("input",{type:"date",value:x,max:v||void 0,onChange:e=>h(e.target.value),disabled:s,className:"inp","aria-label":"Başlangıç tarihi"}),(0,o.jsx)("span",{className:"sep",children:"–"}),(0,o.jsx)("input",{type:"date",value:v,min:x||void 0,onChange:e=>y(e.target.value),disabled:s,className:"inp","aria-label":"Bitiş tarihi"}),(0,o.jsx)("button",{type:"button",className:"apply",onClick:function(){N&&S(e=>{e.delete("donem"),e.set("from",x),e.set("to",v)})},disabled:s||!N,children:"Uygula"}),w&&(0,o.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),s&&(0,o.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,o.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])}]);