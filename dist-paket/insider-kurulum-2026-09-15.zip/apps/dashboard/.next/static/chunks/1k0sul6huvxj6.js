(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,29924,e=>{"use strict";var r=e.i(43476),t=e.i(18566),a=e.i(71645);let o=/^\d{4}-\d{2}-\d{2}$/,n=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];e.s(["GlobalDonemFilter",0,function(){let e=(0,t.useRouter)(),i=(0,t.usePathname)(),l=(0,t.useSearchParams)(),[s,c]=(0,a.useTransition)(),d=l?.get("from")??"",p=l?.get("to")??"",u=(l?.get("donem")??"").toLowerCase(),m=o.test(d)&&o.test(p),f=m?"serbest":u&&"son30g"!==u?u:"son30g",[h,b]=(0,a.useState)(m),[g,x]=(0,a.useState)(d),[y,k]=(0,a.useState)(p),v=o.test(g),S=o.test(y),j=v&&S&&g>y,M=v&&S&&!j;function T(r){let t=new URLSearchParams(l?.toString()??"");r(t);let a=t.toString();c(()=>e.push(`${i}${a?`?${a}`:""}`))}return(0,r.jsxs)("div",{className:"donem-filter",children:[(0,r.jsx)("span",{className:"lbl",children:"Dönem"}),(0,r.jsxs)("div",{className:"chips",children:[n.map(e=>(0,r.jsx)("button",{type:"button",className:`chip ${f===e.key?"on":""}`,onClick:()=>{var r;return r=e.key,void(b(!1),T(e=>{e.delete("from"),e.delete("to"),"son30g"===r?e.delete("donem"):e.set("donem",r)}))},disabled:s,children:e.label},e.key)),(0,r.jsx)("button",{type:"button",className:`chip ${"serbest"===f||h?"on":""}`,onClick:()=>b(e=>!e),disabled:s,children:"Serbest"})]}),(h||"serbest"===f)&&(0,r.jsxs)("div",{className:"range",children:[(0,r.jsx)("input",{type:"date",value:g,max:y||void 0,onChange:e=>x(e.target.value),disabled:s,className:"inp","aria-label":"Başlangıç tarihi"}),(0,r.jsx)("span",{className:"sep",children:"–"}),(0,r.jsx)("input",{type:"date",value:y,min:g||void 0,onChange:e=>k(e.target.value),disabled:s,className:"inp","aria-label":"Bitiş tarihi"}),(0,r.jsx)("button",{type:"button",className:"apply",onClick:function(){M&&T(e=>{e.delete("donem"),e.set("from",g),e.set("to",y)})},disabled:s||!M,children:"Uygula"}),j&&(0,r.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),s&&(0,r.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,r.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},25055,e=>{"use strict";var r=e.i(43476);let t=(0,e.i(56420).default)("file-spreadsheet",[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]]);function a(e){let r=String(e);return/[;"\r\n]/.test(r)?`"${r.replace(/"/g,'""')}"`:r}function o(e){return e.map(a).join(";")}function n(e,r=0){return e.toLocaleString("tr-TR",{minimumFractionDigits:r,maximumFractionDigits:r})}e.s(["MarkaSkuExportButton",0,function({portfolio:e,topSkus:a}){return(0,r.jsxs)("button",{type:"button",onClick:function(){let r,t,i=new Blob(["\uFEFF"+function(e,r){let t=[];for(let r of(t.push(o(["Marka & SKU Performansı — dışa aktarım"])),t.push(o(["Oluşturulma",new Date().toLocaleString("tr-TR")])),t.push(""),t.push(o(["MARKA PORTFÖYÜ (son 30 gün net ciro)"])),t.push(o(["Sıra","Marka","Marka Kodu","Ciro (TL)","Pay (%)","Müşteri Sayısı","Fatura Sayısı","Stratejik Marka"])),e)){let e=r.isOther||r.isTotal;t.push(o([e?"":r.rank,r.isTotal?"TOPLAM":r.isOther?"Diğer":r.marka,e?"":r.markaKod,n(r.ciro,2),n(r.payPct,1),n(r.musteriSayi),n(r.faturaSayisi),e?"":r.isStratejik?"Evet":"Hayır"]))}for(let e of(t.push(""),t.push(o(["TOP SKU (son 30 gün net ciro)"])),t.push(o(["Sıra","Ürün Kodu","Ürün Adı","Marka","Ciro (TL)","Miktar","Müşteri Sayısı","Pay (%)","Stratejik Marka"])),r)){let r=e.isOther||e.isTotal;t.push(o([r?"":e.rank,r?"":e.urunKod,e.isTotal?"TOPLAM":e.isOther?"Diğer":e.ad,r?"":e.marka,n(e.ciro,2),n(e.miktar),n(e.musteriSayi),n(e.payPct,2),r?"":e.isStratejik?"Evet":"Hayır"]))}return t.join("\r\n")}(e,a)],{type:"text/csv;charset=utf-8;"}),l=URL.createObjectURL(i),s=document.createElement("a");s.href=l,s.download=`marka-sku-${r=new Date,t=e=>String(e).padStart(2,"0"),`${r.getFullYear()}${t(r.getMonth()+1)}${t(r.getDate())}`}.csv`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(l)},title:"Marka portföyü ve Top SKU tablolarını CSV olarak indir (Excel'de doğrudan açılır)",className:"inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md text-[11px] font-semibold border bg-surface-2 text-fg-2 border-border transition-colors hover:border-accent/40 hover:text-accent",children:[(0,r.jsx)(t,{size:12}),"Excel’e Aktar"]})}],25055)}]);