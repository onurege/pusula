(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,68703,e=>{"use strict";var o=e.i(43476),r=e.i(71645),t=e.i(18566),a=e.i(87194),n=e.i(12362);function i(){let[e,i]=(0,r.useState)(""),[l,s]=(0,r.useState)(""),[c,d]=(0,r.useState)(null),[p,u]=(0,r.useState)(!1),{login:g}=(0,a.useAuth)(),x=(0,t.useRouter)(),f=(0,t.useSearchParams)(),b=(0,n.useTenant)();async function m(o){if(o.preventDefault(),!e.trim()||!l.trim())return;u(!0),d(null);let r=await g(e,l);if(r)d(r),u(!1);else{let e=f?.get("next"),o=b.ui?.defaultLanding??"/";x.push(e&&e.startsWith("/")?e:o),x.refresh()}}let h=b?.displayName??"Insider";return(0,o.jsxs)("div",{className:"login-wrap",children:[(0,o.jsxs)("form",{className:"login-card",onSubmit:m,children:[(0,o.jsx)("div",{className:"login-badge",children:(h[0]??"E").toUpperCase()}),(0,o.jsx)("h1",{className:"login-title",children:h}),(0,o.jsx)("p",{className:"login-sub",children:"Hesabınıza giriş yapın"}),(0,o.jsx)("label",{className:"login-label",htmlFor:"username",children:"Kullanıcı Adı"}),(0,o.jsx)("input",{id:"username",className:"login-input",type:"text",value:e,onChange:e=>i(e.target.value),placeholder:"Kullanıcı adınız",autoComplete:"username",autoFocus:!0}),(0,o.jsx)("label",{className:"login-label",htmlFor:"password",children:"Şifre"}),(0,o.jsx)("input",{id:"password",className:"login-input",type:"password",value:l,onChange:e=>s(e.target.value),placeholder:"Şifreniz",autoComplete:"current-password"}),c&&(0,o.jsx)("p",{className:"login-error",children:c}),(0,o.jsx)("button",{className:"login-btn",type:"submit",disabled:p||!e.trim()||!l.trim(),children:p?"Giriş yapılıyor…":"Giriş Yap"})]}),(0,o.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .login-wrap { min-height: 70dvh; display: flex; align-items: center; justify-content: center; padding: 24px; }
        .login-card {
          width: 100%; max-width: 360px;
          display: flex; flex-direction: column;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 14px;
          padding: 32px 28px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.06);
        }
        .login-badge {
          width: 52px; height: 52px; border-radius: 14px;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          display: flex; align-items: center; justify-content: center;
          font-size: 22px; font-weight: 700; margin: 0 auto 16px;
        }
        .login-title { font-size: 20px; font-weight: 700; text-align: center; color: var(--color-fg); letter-spacing: -0.01em; }
        .login-sub { font-size: 13px; color: var(--color-muted); text-align: center; margin: 4px 0 22px; }
        .login-label { font-size: 12px; font-weight: 600; color: var(--color-fg); margin-bottom: 6px; }
        .login-input {
          width: 100%; box-sizing: border-box;
          padding: 10px 12px; margin-bottom: 16px;
          font-size: 14px; color: var(--color-fg);
          background: var(--color-bg, var(--color-surface));
          border: 1px solid var(--color-border); border-radius: 8px;
          font-family: inherit;
        }
        .login-input:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; border-color: transparent; }
        .login-error { font-size: 13px; color: var(--color-bad, #dc2626); margin: 0 0 14px; }
        .login-btn {
          width: 100%; padding: 11px 16px;
          font-size: 14px; font-weight: 600;
          color: var(--color-accent-fg, #fff); background: var(--color-accent);
          border: none; border-radius: 8px; cursor: pointer;
          transition: opacity 0.15s;
        }
        .login-btn:hover:not(:disabled) { opacity: 0.9; }
        .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      `}})]})}e.s(["default",0,function(){return(0,o.jsx)(r.Suspense,{fallback:null,children:(0,o.jsx)(i,{})})}])}]);