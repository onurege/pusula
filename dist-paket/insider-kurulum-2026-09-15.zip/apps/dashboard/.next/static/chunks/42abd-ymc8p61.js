(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,29924,e=>{"use strict";var o=e.i(43476),r=e.i(18566),t=e.i(71645);let a=/^\d{4}-\d{2}-\d{2}$/,l=[{key:"son30g",label:"Son 30g"},{key:"mtd",label:"Bu Ay"},{key:"ytd",label:"Bu Yıl"},{key:"q1",label:"Ç1"},{key:"q2",label:"Ç2"},{key:"q3",label:"Ç3"}];e.s(["GlobalDonemFilter",0,function(){let e=(0,r.useRouter)(),i=(0,r.usePathname)(),n=(0,r.useSearchParams)(),[s,d]=(0,t.useTransition)(),c=n?.get("from")??"",p=n?.get("to")??"",f=(n?.get("donem")??"").toLowerCase(),u=a.test(c)&&a.test(p),b=u?"serbest":f&&"son30g"!==f?f:"son30g",[m,x]=(0,t.useState)(u),[g,h]=(0,t.useState)(c),[v,y]=(0,t.useState)(p),k=a.test(g),j=a.test(v),w=k&&j&&g>v,N=k&&j&&!w;function S(o){let r=new URLSearchParams(n?.toString()??"");o(r);let t=r.toString();d(()=>e.push(`${i}${t?`?${t}`:""}`))}return(0,o.jsxs)("div",{className:"donem-filter",children:[(0,o.jsx)("span",{className:"lbl",children:"Dönem"}),(0,o.jsxs)("div",{className:"chips",children:[l.map(e=>(0,o.jsx)("button",{type:"button",className:`chip ${b===e.key?"on":""}`,onClick:()=>{var o;return o=e.key,void(x(!1),S(e=>{e.delete("from"),e.delete("to"),"son30g"===o?e.delete("donem"):e.set("donem",o)}))},disabled:s,children:e.label},e.key)),(0,o.jsx)("button",{type:"button",className:`chip ${"serbest"===b||m?"on":""}`,onClick:()=>x(e=>!e),disabled:s,children:"Serbest"})]}),(m||"serbest"===b)&&(0,o.jsxs)("div",{className:"range",children:[(0,o.jsx)("input",{type:"date",value:g,max:v||void 0,onChange:e=>h(e.target.value),disabled:s,className:"inp","aria-label":"Başlangıç tarihi"}),(0,o.jsx)("span",{className:"sep",children:"–"}),(0,o.jsx)("input",{type:"date",value:v,min:g||void 0,onChange:e=>y(e.target.value),disabled:s,className:"inp","aria-label":"Bitiş tarihi"}),(0,o.jsx)("button",{type:"button",className:"apply",onClick:function(){N&&S(e=>{e.delete("donem"),e.set("from",g),e.set("to",v)})},disabled:s||!N,children:"Uygula"}),w&&(0,o.jsx)("span",{className:"err",children:"Başlangıç, bitişten sonra olamaz."})]}),s&&(0,o.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,o.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .donem-filter {
          display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
          padding: 10px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .donem-filter .lbl {
          font-size: 11px; font-weight: 600; color: var(--color-muted);
          text-transform: uppercase; letter-spacing: 0.04em;
        }
        .donem-filter .chips { display: inline-flex; gap: 4px; flex-wrap: wrap; }
        .donem-filter .chip {
          padding: 6px 12px; font-size: 12.5px; font-weight: 500;
          background: var(--color-surface-2); color: var(--color-fg-2, var(--color-fg));
          border: 1px solid var(--color-border); border-radius: 999px;
          cursor: pointer; transition: background .12s, color .12s, border-color .12s;
          font-family: inherit;
        }
        .donem-filter .chip:hover:not(:disabled) { border-color: var(--color-accent); }
        .donem-filter .chip.on {
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border-color: var(--color-accent);
        }
        .donem-filter .chip:disabled { opacity: 0.55; cursor: wait; }
        .donem-filter .range { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .donem-filter .inp {
          padding: 6px 9px; font-size: 12.5px;
          background: var(--color-surface); border: 1px solid var(--color-border);
          border-radius: 6px; color: var(--color-fg); font-family: inherit;
        }
        .donem-filter .inp:focus { outline: 2px solid var(--color-accent); outline-offset: 1px; }
        .donem-filter .sep { color: var(--color-muted-2); }
        .donem-filter .apply {
          padding: 6px 12px; font-size: 12px; font-weight: 600;
          background: var(--color-accent); color: var(--color-accent-fg, #fff);
          border: 1px solid var(--color-accent); border-radius: 6px; cursor: pointer;
        }
        .donem-filter .apply:disabled { opacity: 0.5; cursor: not-allowed; }
        .donem-filter .err { font-size: 11.5px; color: var(--color-bad, #dc2626); }
        .donem-filter .loading { font-size: 11px; color: var(--color-muted); font-style: italic; }
      `}})]})}])},9577,e=>{"use strict";var o=e.i(43476),r=e.i(18566),t=e.i(71645);e.s(["IskontoFilterBar",0,function({distributors:e,selectedDistId:a,dateFrom:l,dateTo:i,showDateRange:n=!0}){let s=(0,r.useRouter)(),d=(0,r.usePathname)(),c=(0,r.useSearchParams)(),[p,f]=(0,t.useTransition)(),[u,b]=(0,t.useState)(l??""),[m,x]=(0,t.useState)(i??"");function g(e){let o=new URLSearchParams(c?.toString()??"");e(o);let r=o.toString();f(()=>{s.push(`${d}${r?`?${r}`:""}`)})}let h=!!(l&&i),v=!!(u&&m&&u<=m);return(0,o.jsxs)("div",{className:"iskonto-filterbar",children:[(0,o.jsxs)("div",{className:"iskonto-filter-field",children:[(0,o.jsx)("label",{htmlFor:"iskonto-dist-select",className:"lbl",children:"Distribütör"}),(0,o.jsxs)("select",{id:"iskonto-dist-select",value:a??"all",onChange:function(e){let o=e.target.value;g(e=>{""===o||"all"===o?e.delete("distId"):e.set("distId",o)})},disabled:p,className:"sel",children:[(0,o.jsx)("option",{value:"all",children:"Tümü — portföy toplamı"}),e.map(e=>(0,o.jsx)("option",{value:e.id,children:e.ad},e.id))]})]}),n&&(0,o.jsxs)("form",{className:"iskonto-filter-field iskonto-date-field",onSubmit:function(e){e.preventDefault();let o=u.trim(),r=m.trim();g(e=>{o&&r?(e.set("from",o),e.set("to",r)):(e.delete("from"),e.delete("to"))})},children:[(0,o.jsx)("label",{htmlFor:"iskonto-from",className:"lbl",children:"Tarih Aralığı"}),(0,o.jsxs)("div",{className:"iskonto-date-row",children:[(0,o.jsx)("input",{id:"iskonto-from",type:"date",value:u,max:m||void 0,onChange:e=>b(e.target.value),className:"date-input","aria-label":"Başlangıç tarihi"}),(0,o.jsx)("span",{className:"sep",children:"–"}),(0,o.jsx)("input",{id:"iskonto-to",type:"date",value:m,min:u||void 0,onChange:e=>x(e.target.value),className:"date-input","aria-label":"Bitiş tarihi"}),(0,o.jsx)("button",{type:"submit",className:"btn-apply",disabled:p||!v,children:"Uygula"}),h&&(0,o.jsx)("button",{type:"button",className:"btn-clear",onClick:function(){b(""),x(""),g(e=>{e.delete("from"),e.delete("to")})},disabled:p,children:"Varsayılana dön"})]})]}),p&&(0,o.jsx)("span",{className:"loading",children:"yükleniyor…"}),(0,o.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .iskonto-filterbar {
          display: flex;
          align-items: flex-end;
          gap: 20px;
          flex-wrap: wrap;
          padding: 12px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 8px;
          margin-bottom: 16px;
        }
        .iskonto-filter-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .iskonto-filterbar .lbl {
          font-size: 10.5px;
          font-weight: 650;
          color: var(--color-muted);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .iskonto-filterbar .sel {
          min-width: 240px;
          padding: 7px 10px;
          font-size: 13px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
          cursor: pointer;
        }
        .iskonto-date-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .iskonto-filterbar .date-input {
          padding: 6px 8px;
          font-size: 12.5px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 6px;
          color: var(--color-fg);
          font-family: inherit;
        }
        .iskonto-filterbar .sep { color: var(--color-muted); font-size: 12px; }
        .iskonto-filterbar .btn-apply,
        .iskonto-filterbar .btn-clear {
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 600;
          border-radius: 6px;
          cursor: pointer;
          font-family: inherit;
          white-space: nowrap;
        }
        .iskonto-filterbar .btn-apply {
          background: var(--color-accent);
          color: var(--color-on-accent, #fff);
          border: 1px solid var(--color-accent);
        }
        .iskonto-filterbar .btn-apply:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .iskonto-filterbar .btn-clear {
          background: var(--color-surface);
          color: var(--color-muted);
          border: 1px solid var(--color-border);
        }
        .iskonto-filterbar .sel:disabled,
        .iskonto-filterbar .date-input:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .iskonto-filterbar .sel:focus,
        .iskonto-filterbar .date-input:focus {
          outline: 2px solid var(--color-accent);
          outline-offset: 2px;
        }
        .iskonto-filterbar .loading {
          font-size: 11px;
          color: var(--color-muted);
          font-style: italic;
        }
      `}})]})}])}]);