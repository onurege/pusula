import {
  FunctionCallingMode,
  GoogleGenerativeAI,
  SchemaType,
  type Content,
  type Part,
  type Tool,
} from "@google/generative-ai";
import { runReadOnly } from "./db.js";
import { geminiAttempts, generate, isTransientGeminiError } from "./gemini.js";
import { formatRetrievalForPrompt, retrieve } from "./retrieve.js";
import { loadSnapshot } from "./snapshot.js";

let client: GoogleGenerativeAI | null = null;
function getClient(): GoogleGenerativeAI {
  if (client) return client;
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("Missing GEMINI_API_KEY");
  client = new GoogleGenerativeAI(key);
  return client;
}

export type AgentStep =
  | { kind: "tool_call"; tool: string; args: Record<string, unknown> }
  | { kind: "tool_result"; tool: string; ok: boolean; summary: string }
  | { kind: "final"; sql: string; brief: string }
  | { kind: "give_up"; reason: string };

export type AgentResult = {
  steps: AgentStep[];
  final?: { sql: string; brief: string };
  retrievedTables: string[];
  /** Sample rows from the final successful SQL execution. */
  rows: Record<string, unknown>[];
  rowCount: number;
  truncated: boolean;
  durationMs: number;
};

const AGENT_SYSTEM = `
Sen Univera ERP veritabanı üzerinde Türkçe iş soruları için rapor üreten bir
veri-analizi ajanısın. Halüsinasyona kesinlikle yer yok — şema bilgisi ancak
\`retrieve_schema\` çağrısıyla, sorgu doğrulaması ancak \`run_sql\` çağrısıyla
gelir. Tablo veya kolon adı uydurma; bağlamda yoksa o yoktur.

UNIVERA KURALLARI (her sorguda uygula):

1. **TBLMSDFATURA hem satış hem alış hem iade içerir.** Belge türü ayrımı
   \`BYTTUR\` kolonundadır:
   - 0 = Satış (Satış cirosu için TEK kullanılması gereken)
   - 1 = Alış · 2-4 = Müşteri/Tedarikçi İade · 5-6 = Hizmet
   - 98 = Alış İade · 99 = Satış İade
   "Satış" / "ciro" sorularında **mutlaka \`BYTTUR = 0\`** koy.
2. **\`BYTDURUM = 0\` onaylı/aktif belge.** İptal edilmiş belgeleri saymak için
   her satış sorgusunda da bu filtre olur. Distribütör tarafında da \`TBLDIST.BYTDURUM = 0\`
   aktif distribütörü temsil eder.
3. **Tutar kolonları:** TBLMSDFATURA.DBLNETTUTAR (fatura net tutarı). Ürün bazlı
   detayda TBLMSDBELGEDETAY.DBLNETFIYAT × DBLMIKTAR. TBLMSDBELGEDETAY'da
   DBLNETTUTAR YOKTUR.
4. **JOIN yolları:**
   - Fatura → Distribütör: \`TBLMSDFATURA.LNGDISTKOD = TBLDIST.LNGKOD\`
   - Fatura → Müşteri: \`TBLMSDFATURA.LNGMUSTERIKOD = TBLMUSTERI.LNGKOD\`
   - Fatura → Detay: TBLMSDBELGEDETAY üç kolonla bağlanır:
     \`LNGYIL, LNGFATURAKOD = TBLMSDFATURA.LNGBELGEKOD, LNGDISTKOD\`
   - Detay → Ürün: \`TBLMSDBELGEDETAY.LNGURUNKOD = TBLURUN.LNGKOD\`
5. **Ad sütunları:** Distribütör \`TBLDIST.TXTAD\`, müşteri \`TBLMUSTERI.TXTUNVAN\`
   veya \`TXTKISAAD\`, ürün \`TBLURUN.TXTAD\`. Asla sadece kod döndürme.
6. **Ürün GRUBU adı için TBLURUN tek başına yetmez.** \`TXTURUNGRUPADI\` kolonu
   YOKTUR. TBLURUN'da yalnızca \`TXTURUNGRUPKOD\` (varchar) var; grubun adı
   TBLURUNGRUP'tedir:
   \`\`\`sql
   INNER JOIN TBLURUNGRUP g
     ON g.TXTKOD = TBLURUN.TXTURUNGRUPKOD
    AND g.LNGDISTKOD = TBLURUN.LNGDISTKOD
   -- ürün grubunun adı: g.TXTAD
   \`\`\`
7. **TBLMSDBELGEDETAY tutar kolonları:** \`DBLFATURANETFIYAT\` YOKTUR.
   Mevcut olanlar: \`DBLNETFIYAT\` (satır net toplamı — iskonto/KDV/ÖTV
   sonrası, miktar HARİÇ değil DAHİL), \`DBLBIRIMFIYAT\` (birim brüt fiyat),
   \`DBLMIKTAR\` (adet). Ürün bazlı NET ciro: \`SUM(DBLNETFIYAT)\` (zaten
   satır toplamı — miktarla çarpma! brüt ciro için \`SUM(DBLBIRIMFIYAT *
   DBLMIKTAR)\` kullan).

HAZIR SORGU TARİFLERİ (kullanıcı talebine göre uyarla, kolon adlarını
değiştirme):

A) Müşterinin son N gün **ürün grubu kırılımı**:
   \`\`\`sql
   SELECT TOP 5
     g.TXTAD AS UrunGrubu,
     SUM(d.DBLNETFIYAT) AS Ciro,
     SUM(d.DBLMIKTAR) AS Miktar
   FROM dbo.TBLMSDFATURA f
   INNER JOIN dbo.TBLMSDBELGEDETAY d
     ON d.LNGYIL = f.LNGYIL
    AND d.LNGFATURAKOD = f.LNGBELGEKOD
    AND d.LNGDISTKOD = f.LNGDISTKOD
   INNER JOIN dbo.TBLURUN u
     ON u.LNGKOD = d.LNGURUNKOD
   INNER JOIN dbo.TBLURUNGRUP g
     ON g.TXTKOD = u.TXTURUNGRUPKOD
    AND g.LNGDISTKOD = u.LNGDISTKOD
   WHERE f.LNGMUSTERIKOD = <KOD>
     AND f.BYTTUR = 0 AND f.BYTDURUM = 0
     AND f.TRHISLEMTARIHI >= DATEADD(day, -<GUN>, GETDATE())
   GROUP BY g.TXTAD
   ORDER BY Ciro DESC;
   \`\`\`

B) Müşterinin son N gün **ürün** kırılımı:
   Aynı join yolu, GROUP BY u.TXTAD ile.

ÖNEMLİ — boş sonuç düşüş kuralı:
- "Ürün grubu kırılımı" sorulduğunda A şıkkını çalıştır.
- A şıkkı 0 satır dönerse (müşterinin TBLURUNGRUP eşleşmesi yoksa), pes etme.
  Otomatik olarak B şıkkına (ürün adı kırılımı) düş ve onu çalıştır.
- B de 0 satır dönerse, en azından TBLMSDBELGEDETAY üzerinden TOP 3 ürün koduyla
  brüt kırılım denenebilir. En son çare olarak finalize'da "kırılım çıkarılamadı"
  yaz — ama önce A→B düşüşünü mutlaka dene.

ÇALIŞMA YÖNTEMİN:

1. Önce \`retrieve_schema\` ile kullanıcının talebine uygun tablo(ları) bul.
   Gerekirse farklı sözcüklerle birden fazla kez çağır (ör. "satış", "fatura",
   "distribütör"). Her çağrıda en fazla 8-10 tablo iste.
2. Bağlamdan uygun tabloları seç. _YEDEK / _OLD / _BAK / _BIRLESTIRME(DETAY) /
   _<tarih> ile biten tablolardan KAÇIN — bunlar yedek/arşiv'tir, ana tablo değil.
3. \`run_sql\` ile sorguyu çalıştır. Sorgu kuralları:
   - Yalnızca SELECT. INSERT/UPDATE/DELETE/DDL yasak.
   - \`SELECT TOP\` ile satır sayısını sınırla (default 100, en fazla 1000).
   - Distribütör/müşteri/ürün sorgularında **kod yanında ad döndür** —
     gerekirse bağlamdaki ana entity tablosuna INNER JOIN yap (TXTAD/TXTUNVAN).
   - "Satış / ciro / hasılat" sorgularında COUNT yerine SUM(DBLNETTUTAR /
     DBLBRUTTUTAR / DBLTUTAR) kullan. Sadece kayıt sayısı istenmişse COUNT.
   - Aktiflik filtresi gerekirse \`BYTDURUM = 0\` (aktif) ekle.
4. Hata gelirse (Invalid object name / Invalid column name): hatayı oku,
   bağlamı tekrar gözden geçir, gerekirse \`retrieve_schema\` ile yeni tablo ara,
   sorguyu düzelt ve \`run_sql\`'i tekrar çağır. En fazla 4 kez dene.
5. Sonuç boş döndü mü? Tarih aralığını veya filtreleri gevşet, farklı bir
   tablo dene. Yine de boşsa finalize çağır ve brief'te "veri çıkmadı" de.
6. SQL çalışıp anlamlı sonuç dönünce \`finalize\` çağır:
   - \`sql\`: çalıştığı son SELECT.
   - \`brief\`: 3-5 cümlelik Türkçe iş özeti. Sonuç boşsa "veri çıkmadı"
     diyerek dürüstçe belirt; doluysa **en üst 1-2 satırı SOMUT adlarıyla
     ve sayılarıyla zikret**. Generic ifadeler ("en yüksek katkıyı sağlayan
     ürün grupları belirlenmiştir") kabul edilmez — gerçek ad ve rakam yaz.

   Brief örneği — KÖTÜ (yasak, sayılar/adlar yok):
   > "Müşterinin son 30 günlük cirosu incelendiğinde, en yüksek katkıyı
   > sağlayan ürün grupları belirlenmiştir."

   Brief örneği — İYİ (somut adlar + rakamlar):
   > "Mustafa Paydaş'ın son 30 günde 142.300 ₺ olan cirosunun büyük kısmı
   > Whisky grubundan (89.500 ₺, %63) gelmiş; ikinci sırada Vodka (28.700 ₺)
   > yer alıyor. 18.100 ₺'lik Şarap üçüncü kalem."

   SQL veya teknik jargon yok; iş dilinde yaz.

ÇOK ÖNEMLİ — VAZGEÇME:
- Her turda **mutlaka** bir tool çağırırsın: retrieve_schema, run_sql veya finalize.
- Asla kullanıcıya soru sorma, asla "yardım edemiyorum" deme, asla text mesajı dönme.
- Kolon adı yanlışsa: hata mesajını oku, retrieve_schema ile aynı tabloyu yeniden iste,
  detayda kolon listesini gör, doğru kolonla run_sql'i tekrar dene.
- 6 tool çağrısından sonra hâlâ bitmediyse \`finalize\` ile elindeki en iyi durumu sun.
`.trim();

const TOOLS: Tool[] = [
  {
    functionDeclarations: [
      {
        name: "retrieve_schema",
        description:
          "Univera şemasından tablo bilgisi getirir. Tablo açıklamaları, kolonlar (tipleriyle), birincil anahtarlar ve 1-hop FK komşuları döner. İki kullanım: (a) `query` ile semantik arama, (b) `tables` parametresine tam isim listesi (örn. ['TBLMSDFATURA','TBLURUN']) verirsen o tabloları doğrudan getirir — kullanıcı promptu zaten tablo adlarını söylediyse bu yolu tercih et.",
        parameters: {
          type: SchemaType.OBJECT,
          properties: {
            query: {
              type: SchemaType.STRING,
              description: "Türkçe veya İngilizce bir iş sorusu / anahtar sözcükler",
            },
            tables: {
              type: SchemaType.ARRAY,
              items: { type: SchemaType.STRING },
              description:
                "Tam tablo adları. Verilirse query yok sayılır ve liste birebir getirilir (case-insensitive eşleşme).",
            },
            topK: {
              type: SchemaType.NUMBER,
              description: "Semantik arama için döndürülecek tablo sayısı (default 8, en fazla 20)",
            },
          },
        },
      },
      {
        name: "run_sql",
        description:
          "MSSQL Univera üzerinde tek bir SELECT çalıştırır. Read-only — INSERT/UPDATE/DELETE/DDL reddedilir. Default 500 satır, 60s timeout.",
        parameters: {
          type: SchemaType.OBJECT,
          properties: {
            sql: { type: SchemaType.STRING },
          },
          required: ["sql"],
        },
      },
      {
        name: "finalize",
        description:
          "Çalışan SQL ve Türkçe brifing hazır olduğunda son sonucu sun. Bu çağrıdan sonra tool döngüsü biter.",
        parameters: {
          type: SchemaType.OBJECT,
          properties: {
            sql: { type: SchemaType.STRING },
            brief: { type: SchemaType.STRING },
          },
          required: ["sql", "brief"],
        },
      },
    ],
  },
];

const MAX_ITERATIONS = 8;
const RETRIEVE_TOPK_CAP = 20;

// ---------------------------------------------------------------------------
// GUV-04 — sunucu-tarafı tablo erişim politikası (koda gömülü, LLM'e değil)
//
// `run_sql` tool'u önceden yalnızca "agent'ın bu oturumda retrieve_schema ile
// gördüğü tablolar" kümesine karşı doğrulanıyordu (`allowedUpper`, aşağıda).
// Bu kontrol prompt-injection'a karşı yetersiz: model kullanıcı isteğiyle ikna
// edilip TBLKULLANICI gibi hassas bir tabloyu retrieve_schema ile arayıp
// (örn. "kullanıcı" sorgusuyla) sonra run_sql'e verebilir — retrieve_schema
// şema snapshot'ında görünen HER tabloyu döndürür, semantik alaka dışında bir
// filtre yoktur.
//
// Bu yüzden run_sql'de iki BAĞIMSIZ, LLM'in kontrol edemeyeceği kapı var:
//   1. DENYLIST — parola/login/kimlik içeren tablolar kesin yasak. Bu liste
//      retrieve_schema'nın döndürdüğü hiçbir şeyden etkilenmez; regex ile
//      FROM/JOIN sonrası tablo adı bu listeyle eşleşirse run_sql SQL'i MSSQL'e
//      hiç göndermeden reddeder.
//   2. ALLOWLIST — analitik/dashboard tabloları (mevcut Wietnauer/Komuta
//      panellerinin kullandığı kümeyle aynı). Prefiks bazlı: yeni TBLMSD*,
//      TBLURUN*, TBLDIST*, TBLMUSTERI*, TBLPMP* türevleri elle güncelleme
//      olmadan geçer, ama listede olmayan bambaşka bir alan (örn. TBLLOG,
//      TBLPARAMETRE, sistem/konfig tabloları) reddedilir.
//
// DENYLIST, ALLOWLIST'ten önce kontrol edilir ve her zaman kazanır — bir
// tablo hem allow-prefix'e uysa bile denylist'teyse reddedilir.
// ---------------------------------------------------------------------------

/** Tam tablo adı (case-insensitive) — kesin yasak, prompt-injection'a karşı ilk kapı. */
const TABLE_DENYLIST_EXACT = new Set<string>(
  [
    "TBLKULLANICI",
    "TBLKULLANICIGRUP",
    "TBLKULLANICIYETKI",
    "TBLKULLANICILOG",
    "TBLKULLANICIROL",
  ].map((s) => s.toUpperCase()),
);

/** Ad kalıbı — parola/login/kimlik/yetki içeren her şeyi prefiks/substring ile yakala. */
const TABLE_DENYLIST_PATTERNS: RegExp[] = [
  /KULLANICI/i, // TBLKULLANICI* ve ERCVIEWTBLKULLANICIDIST* dahil
  /PAROLA/i,
  /SIFRE/i, // şifre (login secret) — normal tabloda TXTSIFRE gibi kolonlar da olabilir, tablo adında ise reddet
  /PASSWORD/i,
  /^ERCVIEW.*KULLANICI/i,
  /LOGIN/i,
  /YETKI/i, // yetki/rol tabloları
];

// Analitik/dashboard tablo prefiksleri — mevcut Wietnauer/Komuta panellerinin
// (packages/core/src/wietnauer-*.ts, komuta.ts, finance-agent.ts) kullandığı
// küme ile birebir. Prefiks eşleşmesi (startsWith) kullanıldığı için
// TBLURUN → TBLURUNGRUP/TBLURUNEKGRUP, TBLDIST → TBLDISTGRUP/TBLDISTEKGRUP/
// TBLDISTPERSONEL/TBLDISTGUNLUKSTOK, TBLMUSTERI → TBLMUSTERIGRUP gibi
// türevleri ayrıca listelemeye gerek kalmadan kapsar.
const TABLE_ALLOWLIST_PREFIXES = [
  "TBLMSDFATURA",
  "TBLMSDBELGEDETAY",
  "TBLURUN",
  "TBLDIST",
  "TBLMUSTERI",
  "TBLPMP",
];

/** Tablo adı (schema.table veya bare table) kara listede mi? Substring/pattern eşleşmesi de kapsar. */
function isDenylisted(tableRef: string): boolean {
  const bare = (tableRef.split(".").pop() ?? tableRef).toUpperCase();
  if (TABLE_DENYLIST_EXACT.has(bare)) return true;
  return TABLE_DENYLIST_PATTERNS.some((rx) => rx.test(bare));
}

/** Tablo adı analitik allowlist prefiksleriyle başlıyor mu? */
function isAllowlisted(tableRef: string): boolean {
  const bare = (tableRef.split(".").pop() ?? tableRef).toUpperCase();
  return TABLE_ALLOWLIST_PREFIXES.some((prefix) => bare.startsWith(prefix));
}

/**
 * GUV-04 sunucu-tarafı politika kapısı. `run_sql`'e giden SQL'deki her
 * FROM/JOIN tablosunu denetler. Denylist her zaman kazanır; ardından
 * allowlist'te olmayan HERHANGİ bir tablo da reddedilir (yalnızca
 * retrieve_schema'nın gösterdiği tablolara güvenmek yeterli değil — bkz.
 * yukarıdaki blok açıklaması).
 *
 * Döner: `{ ok: true }` veya `{ ok: false, reason, table }`.
 *
 * `export`: birim testler (Vitest) bu saf fonksiyonu Gemini'ye hiç
 * dokunmadan doğrudan çağırabilsin diye — güvenlik-kritik mantık network
 * bağımlılığı olmadan test edilebilir olmalı.
 */
export function checkTablePolicy(referenced: string[]): { ok: true } | { ok: false; reason: string; table: string } {
  for (const ref of referenced) {
    if (isDenylisted(ref)) {
      return {
        ok: false,
        table: ref,
        reason: `Bu tabloya erişim yok: ${ref}`,
      };
    }
  }
  for (const ref of referenced) {
    if (!isAllowlisted(ref)) {
      return {
        ok: false,
        table: ref,
        reason: `Bu tabloya erişim yok: ${ref} (analitik allowlist dışında)`,
      };
    }
  }
  return { ok: true };
}

export async function runAgent(userPrompt: string): Promise<AgentResult> {
  const contents: Content[] = [
    { role: "user", parts: [{ text: userPrompt }] },
  ];
  const steps: AgentStep[] = [];
  const retrievedTables = new Set<string>();
  // Tracks every table the agent has seen across all retrieve_schema calls,
  // upper-cased for case-insensitive comparison against generated SQL.
  const allowedUpper = new Set<string>();
  let lastSuccessfulSql: string | null = null;
  let lastRunRows: Record<string, unknown>[] = [];
  let lastRunRowCount = 0;
  let lastRunTruncated = false;
  let lastRunDuration = 0;

  // Pre-seed schema for any TBL... names the user prompt mentions explicitly.
  // Without this the model has to guess which retrieve_schema query word will
  // surface them via embedding/keyword matching — and gives up if it doesn't.
  // We feed it the schema for those exact tables in the very first user turn.
  const mentionedTables = Array.from(
    new Set((userPrompt.match(/\bTBL[A-Z0-9_]+/gi) ?? []).map((s) => s.toUpperCase())),
  );
  if (mentionedTables.length > 0) {
    try {
      const snap = await loadSnapshot();
      const wanted = new Set(mentionedTables);
      const seeded = snap.tables.filter((t) => {
        const u = t.fullName.toUpperCase();
        const bare = t.name.toUpperCase();
        return wanted.has(u) || wanted.has(bare);
      });
      if (seeded.length > 0) {
        for (const t of seeded) {
          retrievedTables.add(t.fullName);
          allowedUpper.add(t.fullName.toUpperCase());
        }
        const seedResults = seeded.map((t) => ({
          table: t,
          score: 100,
          reasons: ["pre-seed (mentioned in prompt)"],
          fkNeighbors: [] as Array<{ table: string; via: string }>,
        }));
        steps.push({
          kind: "tool_result",
          tool: "retrieve_schema",
          ok: true,
          summary: `pre-seed: ${seeded.length} table(s)`,
        });
        // Inject as a fake first model turn → tool result so the model has
        // the schema in context from turn 1 without burning a tool call.
        contents.push({
          role: "model",
          parts: [
            {
              text:
                `Kullanıcı prompt'unda şu tabloları gördüm, şemalarını ön yükledim: ${seeded
                  .map((t) => t.fullName)
                  .join(", ")}. Şimdi run_sql ile sorguyu çalıştırıyorum.`,
            },
          ],
        });
        contents.push({
          role: "user",
          parts: [
            {
              text:
                `Schema (önyüklendi):\nALLOWED_TABLES = [${[...allowedUpper]
                  .sort()
                  .join(", ")}]\n\n${formatRetrievalForPrompt(seedResults)}`,
            },
          ],
        });
      }
    } catch (err) {
      console.error("[runAgent] pre-seed failed:", err);
    }
  }

  for (let iter = 0; iter < MAX_ITERATIONS; iter++) {
    // Retry / fallback inside each agent turn the same way the standalone
    // generate() helper does — Gemini 503/429 in the middle of an agent loop
    // would otherwise kill the whole explain flow with no retry.
    let result: Awaited<ReturnType<ReturnType<GoogleGenerativeAI["getGenerativeModel"]>["generateContent"]>> | null = null;
    let lastErr: unknown = null;
    for await (const { model: modelName } of geminiAttempts()) {
      try {
        const model = getClient().getGenerativeModel({
          model: modelName,
          systemInstruction: AGENT_SYSTEM,
          tools: TOOLS,
        });
        result = await model.generateContent({
          contents,
          generationConfig: { temperature: 0.1, maxOutputTokens: 2048 },
          // Force the model to emit a function call every turn. Without this it
          // tends to bail out with apologetic Turkish text after one tool error,
          // which collapses the agent loop. With ANY it must call retrieve_schema,
          // run_sql, or finalize — never give up by chatting back.
          toolConfig: {
            functionCallingConfig: { mode: FunctionCallingMode.ANY },
          },
        });
        break;
      } catch (err) {
        lastErr = err;
        if (!isTransientGeminiError(err)) throw err;
      }
    }
    if (!result) {
      throw lastErr ?? new Error("Gemini agent turn failed without an error");
    }

    const candidate = result.response.candidates?.[0];
    const parts = candidate?.content?.parts ?? [];
    contents.push({ role: "model", parts });

    const functionCalls = parts.filter(
      (p): p is Part & { functionCall: { name: string; args: Record<string, unknown> } } =>
        Boolean((p as Part).functionCall),
    );

    if (functionCalls.length === 0) {
      const text = parts.map((p) => ("text" in p ? p.text : "")).join("").trim();
      steps.push({ kind: "give_up", reason: text || "model returned no tool call and no text" });
      break;
    }

    const responseParts: Part[] = [];
    let finalized = false;

    for (const call of functionCalls) {
      const { name, args } = call.functionCall;
      steps.push({ kind: "tool_call", tool: name, args });

      try {
        if (name === "retrieve_schema") {
          const query = String(args.query ?? "");
          const topK = Math.min(Number(args.topK ?? 8), RETRIEVE_TOPK_CAP);
          const snap = await loadSnapshot();
          const exactNames = Array.isArray(args.tables)
            ? (args.tables as unknown[])
                .map((x) => String(x ?? "").trim())
                .filter(Boolean)
            : [];
          let results;
          if (exactNames.length > 0) {
            // Direct table-name lookup. Case-insensitive match against either
            // bare name (TBLMSDFATURA) or full name (dbo.TBLMSDFATURA).
            const wanted = new Set(exactNames.map((n) => n.toUpperCase()));
            const found = snap.tables.filter((t) => {
              const u = t.fullName.toUpperCase();
              const bare = t.name.toUpperCase();
              return wanted.has(u) || wanted.has(bare);
            });
            results = found.map((t) => ({
              table: t,
              score: 100,
              reasons: ["exact-name lookup"],
              fkNeighbors: [],
            }));
          } else {
            results = retrieve(query, snap, { topK, expandFkNeighbors: true });
          }
          for (const r of results) {
            retrievedTables.add(r.table.fullName);
            allowedUpper.add(r.table.fullName.toUpperCase());
          }
          const allowedSoFar = [...allowedUpper].sort();
          steps.push({
            kind: "tool_result",
            tool: name,
            ok: true,
            summary: `${results.length} table(s)`,
          });
          responseParts.push({
            functionResponse: {
              name,
              response: {
                criticalRule:
                  "Aşağıdaki ALLOWED_TABLES listesi dışındaki bir tabloyu run_sql'e koyma — uydurma sayılır ve reddedilir.",
                allowedTablesThisCall: results.map((r) => r.table.fullName),
                allowedTablesCumulative: allowedSoFar,
                detailedContext: formatRetrievalForPrompt(results),
              },
            },
          });
        } else if (name === "run_sql") {
          const sql = String(args.sql ?? "");
          const referenced = extractTableRefs(sql);

          // GUV-04 — sunucu-tarafı, koda gömülü tablo politikası. Bu kontrol
          // retrieve_schema'nın bu oturumda ne döndürdüğünden TAMAMEN
          // bağımsızdır: model prompt-injection ile ikna edilip TBLKULLANICI
          // gibi bir tabloyu retrieve_schema ile görmüş ve `allowedUpper`'a
          // eklenmiş olsa bile, burada denylist/allowlist yine de reddeder.
          // Aşağıdaki `allowedUpper` kontrolü (retrieve-schema pre-validation)
          // hâlâ ayrıca çalışır — bu sadece halüsinasyon tablolarını yakalar,
          // güvenlik sınırı DEĞİLDİR.
          const policy = checkTablePolicy(referenced);
          if (!policy.ok) {
            steps.push({
              kind: "tool_result",
              tool: name,
              ok: false,
              summary: `Policy: ${policy.reason}`,
            });
            responseParts.push({
              functionResponse: {
                name,
                response: {
                  error: policy.reason,
                  hint:
                    "Bu tablo güvenlik politikası gereği kapalı. Başka bir analitik tablo (satış/ürün/distribütör/müşteri) ile devam et.",
                },
              },
            });
            continue;
          }

          // Pre-validate referenced tables against everything the agent has
          // retrieved so far. This catches hallucinated names without paying
          // a MSSQL round-trip (and prevents the model from trying random
          // table names like TBLSATIS / TBLSATISFATURADETAY on every loop).
          const unknown = referenced.filter((t) => !allowedUpper.has(t.toUpperCase()));
          if (unknown.length > 0) {
            steps.push({
              kind: "tool_result",
              tool: name,
              ok: false,
              summary: `Pre-validation: bilinmeyen tablo(lar) ${unknown.join(", ")}`,
            });
            responseParts.push({
              functionResponse: {
                name,
                response: {
                  error: `Sorgu retrieve_schema'dan dönmemiş tablo(ları) içeriyor: ${unknown.join(", ")}. Bu tablolar uydurma; var olduğundan emin değilsin.`,
                  allowedTablesCumulative: [...allowedUpper].sort(),
                  hint:
                    "İki yol: (1) yine de bu konuda tablo aramak istersen retrieve_schema'yı farklı bir Türkçe terimle çağır; (2) elindeki listeden uygun tabloyu seçip SQL'i yeniden yaz.",
                },
              },
            });
            continue;
          }

          const startedAt = Date.now();
          try {
            const out = await runReadOnly(sql, { limit: 500, timeoutMs: 60_000 });
            lastSuccessfulSql = sql;
            lastRunRows = out.rows;
            lastRunRowCount = out.rowCount;
            lastRunTruncated = out.truncated;
            lastRunDuration = Date.now() - startedAt;
            const sample = out.rows
              .slice(0, 10)
              .map((r) => Object.entries(r).map(([k, v]) => `${k}=${formatVal(v)}`).join(", "))
              .join("\n");
            steps.push({
              kind: "tool_result",
              tool: name,
              ok: true,
              summary: `${out.rowCount} satır, ${lastRunDuration}ms`,
            });
            responseParts.push({
              functionResponse: {
                name,
                response: {
                  rowCount: out.rowCount,
                  truncated: out.truncated,
                  durationMs: lastRunDuration,
                  sampleRows: sample || "(boş sonuç)",
                  hint:
                    out.rowCount === 0
                      ? "Sonuç boş. Tarih aralığını veya filtreleri gevşetmeyi, farklı bir tablo denemeyi düşün."
                      : "Sorgu çalıştı. Sonuç anlamlıysa finalize çağır.",
                },
              },
            });
          } catch (err) {
            const errMsg = (err as Error).message;
            lastRunDuration = Date.now() - startedAt;
            steps.push({
              kind: "tool_result",
              tool: name,
              ok: false,
              summary: errMsg.slice(0, 200),
            });
            responseParts.push({
              functionResponse: {
                name,
                response: {
                  error: errMsg,
                  hint:
                    "Hatadan ders çıkar. Tablo/kolon adı bağlamda var mıydı? Gerekirse retrieve_schema ile yeniden ara, sonra düzeltilmiş SELECT ile tekrar dene.",
                },
              },
            });
          }
        } else if (name === "finalize") {
          const sql = String(args.sql ?? "");
          let brief = String(args.brief ?? "");

          // Detect "I give up" briefs — model finalizing with an excuse rather
          // than answering. If we have NO successful SQL, refuse to accept the
          // finalize and force one more iteration. This catches "şema bilgisine
          // erişilemedi" / "veri çekilemedi" etc. when the agent never even
          // called run_sql.
          const giveUpRx =
            /(şem[ae] bilgi|şem[ae]ya eriş|veri çek|veri bulunam|tablo bulunam|sorgulanamad[ıi])/i;
          if (lastRunRowCount === 0 && !lastSuccessfulSql && giveUpRx.test(brief)) {
            console.warn(
              "[runAgent] model tried to finalize with a give-up brief but never ran SQL — forcing retry",
            );
            steps.push({
              kind: "tool_result",
              tool: "finalize",
              ok: false,
              summary: "rejected: give-up brief without any successful run_sql",
            });
            responseParts.push({
              functionResponse: {
                name,
                response: {
                  error:
                    "Henüz hiç run_sql çağırmadın. Pre-seed'de yüklenmiş şemayı kullan ve doğrudan run_sql ile ÜRÜN GRUBU kırılım sorgusunu (sistem promptu A şıkkı) çalıştır. Tablolar ALLOWED_TABLES içinde — uydurma değil.",
                  allowedTablesCumulative: [...allowedUpper].sort(),
                },
              },
            });
            continue;
          }

          // The model's brief is just a signal that work is done — we don't
          // trust the prose. When the SQL returned rows, ALWAYS rewrite the
          // brief deterministically from those rows so it cites real names
          // and numbers instead of generic filler.
          if (lastRunRowCount > 0 && lastRunRows.length > 0) {
            try {
              const sample = lastRunRows
                .slice(0, 8)
                .map((r) =>
                  Object.entries(r)
                    .map(([k, v]) => `${k}=${formatVal(v)}`)
                    .join(", "),
                )
                .join("\n");
              const rewritten = await generate(
                [
                  "Sen Türkçe bir kıdemli satış analisti asistanısın.",
                  "Sana KULLANICI TALEBİ ve SORGU SONUÇ SATIRLARI verilecek.",
                  "Görev: 3-4 cümlelik somut Türkçe yönetici özeti yaz.",
                  "",
                  "ZORUNLU:",
                  "- Satırlardaki adları (ürün grubu, marka, müşteri, vs.) BİREBİR yaz.",
                  "- Sayıları Türkçe formatta zikret (89.500 ₺, 1.234 adet).",
                  "- Mümkünse en üstteki satırın toplam içindeki yüzdesini hesapla.",
                  "- Düşüş/kayıp anlatımında doğru fiiller seç: 'düşüşün büyük kısmı X'ten geliyor', 'kayıp X müşterisinden kaynaklanıyor', 'eskiden X alıyordu, şimdi 0'.",
                  "",
                  "YASAK:",
                  "- 'Belirlenmiştir', 'önemlidir', 'değerlendirilmiştir' gibi içi boş ifadeler.",
                  "- 'En yüksek katkıyı sağlayan ürün grupları' gibi adsız genellemeler.",
                  "- ÖZELLİKLE: 'düşüşe katkı sağladı/sağlamıştır' YASAK — 'katkı sağlamak' pozitif anlamlıdır, düşüş için kullanılmaz.",
                  "  Onun yerine: 'düşüşün ana kaynağı X', 'kayıp ikinci olarak X'ten', 'X müşterisi eskiden Y ₺ alıyordu, son dönemde 0' yaz.",
                  "- SQL/teknik jargon, 'rapor', 'sorgu', 'tablo' gibi sözcükler.",
                ].join("\n"),
                `KULLANICI TALEBİ:\n${userPrompt}\n\nSORGU SONUCU (toplam ${lastRunRowCount} satır):\n${sample}\n\nBrief:`,
                { temperature: 0.2, maxOutputTokens: 1024 },
              );
              const trimmed = rewritten.trim();
              if (trimmed) {
                console.log("[runAgent] brief rewritten from rows");
                // Last-line defense: model occasionally still produces
                // "düşüşe katkı sağlamıştır" despite the prompt. Replace
                // with the natural Turkish alternative inline.
                brief = trimmed
                  .replace(/düşüşe katkı sağla(?:dı|mış(?:tır)?|nmış)/gi, "kayba ikinci sırada eklendi")
                  .replace(/düşüşün ana kaynağına katkı sağla\w*/gi, "düşüşün ana kaynağı")
                  .replace(/düşüşe katkı\w*/gi, "düşüşün kaynaklarından");
              }
            } catch (err) {
              console.error("[runAgent] brief rewrite failed, keeping model's brief:", err);
            }
          }

          steps.push({ kind: "final", sql, brief });
          finalized = true;
          responseParts.push({
            functionResponse: { name, response: { ok: true } },
          });
          return {
            steps,
            final: { sql, brief },
            retrievedTables: [...retrievedTables],
            rows: lastRunRows,
            rowCount: lastRunRowCount,
            truncated: lastRunTruncated,
            durationMs: lastRunDuration,
          };
        } else {
          steps.push({
            kind: "tool_result",
            tool: name,
            ok: false,
            summary: `unknown tool: ${name}`,
          });
          responseParts.push({
            functionResponse: { name, response: { error: `unknown tool: ${name}` } },
          });
        }
      } catch (err) {
        const errMsg = (err as Error).message;
        steps.push({ kind: "tool_result", tool: name, ok: false, summary: errMsg });
        responseParts.push({
          functionResponse: { name, response: { error: errMsg } },
        });
      }
    }

    if (finalized) break;

    contents.push({ role: "function", parts: responseParts });
  }

  // Loop ended without an explicit finalize. If we have a successful SQL on
  // record, treat its result as the answer and synthesize a brief — it is
  // strictly better than throwing away a working query just because the
  // model forgot to call finalize at the end.
  if (lastSuccessfulSql) {
    const sample =
      lastRunRows.length === 0
        ? "(SONUÇ BOŞ — 0 satır)"
        : lastRunRows
            .slice(0, 10)
            .map((r) =>
              Object.entries(r)
                .map(([k, v]) => `${k}=${formatVal(v)}`)
                .join(", "),
            )
            .join("\n");
    let brief: string;
    try {
      brief = await generate(
        `Sen Türkçe bir analiz asistanısın. Sana bir kullanıcı talebi ve sorgu sonucundan örnek satırlar verilecek. 3-5 cümle Türkçe iş özeti yaz. 0 satırsa "veri çıkmadı" de, halüsinasyon yapma. Veri varsa en üst 1-2 satırı somut adlarıyla zikret. Teknik jargon yok.`,
        `Talep: ${userPrompt}\n\nSonuç (toplam ${lastRunRowCount} satır):\n${sample}\n\nKısa Türkçe özet:`,
        { temperature: 0.3, maxOutputTokens: 512 },
      );
    } catch {
      brief = lastRunRowCount === 0
        ? "Sorgu çalıştı ancak 0 satır döndü. Veri yok ya da filtreler çok dar."
        : `Sorgu çalıştı, ${lastRunRowCount} satır döndü.`;
    }
    steps.push({ kind: "final", sql: lastSuccessfulSql, brief });
    return {
      steps,
      final: { sql: lastSuccessfulSql, brief: brief.trim() },
      retrievedTables: [...retrievedTables],
      rows: lastRunRows,
      rowCount: lastRunRowCount,
      truncated: lastRunTruncated,
      durationMs: lastRunDuration,
    };
  }

  return {
    steps,
    retrievedTables: [...retrievedTables],
    rows: lastRunRows,
    rowCount: lastRunRowCount,
    truncated: lastRunTruncated,
    durationMs: lastRunDuration,
  };
}

function formatVal(v: unknown): string {
  if (v === null || v === undefined) return "null";
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  const s = String(v);
  return s.length > 30 ? s.slice(0, 30) + "…" : s;
}

/**
 * Pull table names out of FROM / JOIN clauses. Naive but enough for our
 * pre-validation: matches `[schema].[table]`, `schema.table`, or `table`,
 * with optional aliases. Nested parens (subqueries) are tolerated because
 * the regex matches occurrences anywhere in the string.
 */
export function extractTableRefs(sql: string): string[] {
  const stripped = sql.replace(/--[^\n]*/g, "").replace(/\/\*[\s\S]*?\*\//g, "");

  // CTE names declared in WITH ... AS (...) — must not be flagged as tables.
  // Pattern: any `<ident> AS (` we see; the trailing paren-open is what
  // distinguishes a CTE name from a column alias (`SELECT x AS y` has no paren).
  const cteNames = new Set<string>();
  const cteRe = /\b(\w+)\s+AS\s*\(/gi;
  let cm: RegExpExecArray | null;
  while ((cm = cteRe.exec(stripped)) !== null) {
    if (cm[1]) cteNames.add(cm[1].toUpperCase());
  }

  const out = new Set<string>();
  const re = /\b(?:FROM|JOIN)\s+\[?(\w+)\]?(?:\s*\.\s*\[?(\w+)\]?)?/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(stripped)) !== null) {
    const a = m[1];
    const b = m[2];
    if (b) {
      // schema.table — keep schema only if it's not "dbo" CTE-shadowing
      if (!cteNames.has(b.toUpperCase())) out.add(`${a}.${b}`);
    } else if (a && !cteNames.has(a.toUpperCase())) {
      out.add(`dbo.${a}`);
    }
  }
  return [...out];
}
